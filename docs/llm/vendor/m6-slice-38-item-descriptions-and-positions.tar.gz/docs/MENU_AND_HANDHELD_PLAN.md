# Menu modernization and the handheld contract — staged plan

**Opened 2026-08-11, at the close of M6 Slice 30. Last moved 2026-08-12, at the close of Slice 34.** This
is the execution plan for the first enhancement request the project has received from a person who was
shown the running application, together with the defect that request arrived beside. It is a working
document: a stage is struck through when it lands, and the ruling paragraphs are the part worth keeping
afterwards.

**Where Stage 2 stands, and the boundary correction below has itself been corrected.** Slice 37 landed
`menu_section`, `menu_section_event`, `MenuSectionDirectory`, `MenuSectionAdministration`, their DI
registration and twenty integration facts against a real database — and it landed **no surface and no
change to `menu_item`**. The stage is cut between the two tables rather than between the schema and the
surfaces, which is not what the correction further down this file proposed. That correction was right about
the problem and picked the more expensive answer: `menu_item.menu_section_identifier NOT NULL` breaks
`CreateMenuItem.razor` the moment migration `0003` applies, and `AdministrationJourneys.CreateMenuItemAsync`
drives that real form in six of the sixteen §16.3 scenarios, so a slice landing both tables has to pull
three surfaces forward to ship green. Cutting between the tables costs one extra migration script — DbUp
journals by name, so nothing — and buys a slice that touches nothing existing at all. **The rejected
nullable-then-tighten alternative is still rejected** and for its original reason: `menu_section_identifier`
goes straight from non-existent to `NOT NULL` in `0004`, so no reading surface ever sees an item under no
heading, and no "Uncategorized" state exists for even one slice. What Stage 2 has left is exactly `0004`
and the three pulled-forward surfaces.

**One obligation is deliberately deferred and is recorded here so it cannot be lost.** The five section
writes are **not** behind `IMenuWorkflow`, so nothing publishes `MenuChanged` when a section moves. That is
correct today — no surface reads a section, and a workflow verb with no caller is a code path no test can
reach through the interface meant to protect it — and it becomes a defect the moment Stage 3's guest menu
groups by section, because a renamed heading would then stay stale in every open picker until the page
happened to reload. **Stage 3 brings the workflow verbs in with the surfaces that call them.**

**Where Stage 1 stands.** 1a landed in Slice 30 (the vocabulary and the four administration indexes). 1c
landed in Slice 32 and ahead of 1b (the 375px end-to-end barrier), for the reason F-62 records. **1b closed
for the whole `/administration` area in Slice 34**: every §11.4 surface is on the shared vocabulary, the
retired names are gone from the tree rather than tracked in a list, and nine of the ten reachable surfaces
are measured at 375px by a browser. What remains of 1b is the counter, kitchen and table surfaces, which
were never record lists and were never the subject of F-59. **Stage 2 is next**, and its boundary
correction is below.

The specification governs. Where a stage below and `TECHNICAL_SPECIFICATION.md` disagree, the
specification is right and this file is stale — with one deliberate exception, marked per stage: a decision
that has been *taken* here and not yet written into §7 or §8.2 is recorded here first, because the
atomic-documentation rule (R§10 · S§18) binds a behaviour change to its specification edit and says
nothing about planning ahead of one.

---

## What was asked for, in the words it was asked in

> We need to enhance and modernize the menu. At the very least we need menu sections: drinks section,
> entrees, breakfast options, etc. However, I think we can do better — each menu item should come with a
> description field, so please rethink the UI/UX of the menu. In the future we might even have images for
> each menu item; perhaps the users might even want to leave comments and likes on menu items. I am not
> sure if it is doable right now but just something to keep in mind, because the application has not gone
> into production yet — I think we can make drastic changes to our models.
>
> Also I have found that some of the administration pages were not so mobile friendly. For example the
> Manage button was on the right side as the user was trying to manage a table. Because the users are very
> likely to use the website from a mobile phone, and most people don't bring a desktop computer with an
> ultrawide monitor to a restaurant, we need to make the website work well on mobile for all screens.

Two things, and the order they are done in is not the order they were asked in. The reason is in Stage 1.

---

## Why the layout comes before the menu

The menu work adds four surfaces: a section index, a section editor, a rewritten item editor, and a guest
menu that is a grouped list of described items rather than one `<select>`. Every one of those is read from
a phone at a table.

If the responsive vocabulary does not exist when they are written, they are written against the shape that
produced F-59 — a wide table with its only affordance in a right-hand column — and then need a second pass
that touches the same four files again. Building the foundation first is the cheaper order, and it is the
only argument for it: the enhancement request is not being deferred for its own good.

There is a second reason, and it is the one that decided it. **F-59 blocks user testing and the menu does
not.** The application was shown to somebody, and what came back was one enhancement request and one
report of a control they could not reach. A menu without sections is a menu somebody can still order from;
a Manage button off the right-hand edge of the screen is a page an operator cannot use.

---

## Stage 1 — the handheld contract

### 1a — the vocabulary and the four index pages — **landed, M6 Slice 30**

Normative in new **S§11.12**. `REQUIREMENTS.md` rev 6 carries the §8 principle it embodies.

- `app.css` rewritten handheld-first through exactly one `min-width: 48rem` query.
- One shared record-list vocabulary (`.record-*`, `.page-head*`), replacing four inline copies of the same
  eighty lines. Each row is a card below the breakpoint and a table row above it; every cell states its
  own label from `data-label`, because overriding a table's `display` drops the header association that
  would otherwise say what a cell holds.
- `.chip`, `.muted` and `.visually-hidden` are declared once, in `app.css`, with `clip-path` rather than
  the deprecated `clip`.
- Touch targets are `--touch-target` (2.75rem) on every control, and every text input has a 16px floor so
  iOS Safari does not zoom the viewport on focus and leave it there.
- `AdministrationHome`, `AdministrationTables`, `AdministrationMenu` and `AdministrationSittings`
  restructured; all four lost their inline `<style>` blocks entirely.
- New `AdministrationAreaLinks` + `AdministrationArea`: the six area links were copy-pasted into six pages
  and each copy omitted a different one — its own — so no page was reachable from every other. Rendered
  once now, self-link included and marked `aria-current="page"`.
- `HandheldLayoutContractTests`, four facts, each proven sensitive.

### 1b — the remaining surfaces — **the administration half landed, M6 Slice 34**

Four pages carried the retired per-page table vocabulary when this stage opened. All four are gone, and the
assertion that used to name the survivors is an emptiness assertion now that there are none.

| Page | What it holds that a record list does not | Roughly | State |
|---|---|---|---|
| ~~`EventExplorer.razor`~~ | a filter form over three event vocabularies | 570 lines | **landed, Slice 33** |
| ~~`HiddenRecords.razor`~~ | every hidden order system-wide, unprojected | 910 lines | **landed, Slice 33** |
| ~~`TableDisplays.razor`~~ | a device roster with revoke actions and a pair-code panel | 440 lines | **landed, Slice 34** |
| ~~`ManageSitting.razor`~~ | one sitting's complete record: lines, events, corrections | 1120 lines | **landed, Slice 34** |

Slice 34 also took the three pages that were never record lists but shared one vocabulary anyway, because
`SharedSelectorPrefixes` could not be extended until every holder was empty (F-46) — and because the
vocabulary they shared turned out to be the fifth copy of F-59, with the drift and the missing touch
targets F-66 records.

| Page | What it declared inline | State |
|---|---|---|
| ~~`ManageMenuItem.razor`~~ | `.manage-*`, a chip set, `.visually-hidden`, and its own history table | **landed, Slice 34** |
| ~~`ManagePerson.razor`~~ | the same, plus `.chip-role` | **landed, Slice 34** |
| ~~`ManageTable.razor`~~ | the same | **landed, Slice 34** |

**Why those two went together, and it is the ruling rather than the order they appear in.** They were the
last two pages carrying a hand-rolled copy of §11.4's row of area links — five `<a class="button-secondary">`
elements inside a `.admin-header-actions` div, each copy omitting its own page. That is the F-59 defect
that `AdministrationAreaLinks` was written to end, and it was two-thirds ended: Slice 30 converted four
pages and left two, so the strip was still a different strip on a third of the administration area. They
were also the two copies of one filter form — `.event-filter` and `.hidden-filter`, the same twelve lines
of `display: flex; flex-wrap: wrap; align-items: flex-end` with no column fallback, which on a 375px screen
wrapped five fields into five rows of unequal width with the submit button wherever the wrap left it. One
shared `.filter-form` / `.filter-actions` vocabulary in `app.css` replaces both.

**Both are now in the §16.3 scenario 16 barrier**, which took it from four surfaces to six, and the barrier's
reach selector grew to cover `.filter-actions` — because §11.4 makes both explorers read-only, so a filter's
submit is the only control either page has and a barrier that measured only record actions would have
visited two pages and measured nothing. `/administration/hidden-records` is measured **empty**, on the same
terms sittings already was and stated the same way: putting a row on it needs a guest, a token, a join, an
order and a close, which is scenario 11's arrangement.

**Two findings came out of doing it**, and both were rules that were already true and not enforced.
**F-63:** §11.12's *exactly one breakpoint* was asserted against `app.css` and nothing else, while the same
section grants twenty-one components an inline `<style>` — so a width query in any of them was a second
breakpoint nothing could see. Found by needing to write one. **F-64:** five custom properties were read
fifty-five times across eight components and declared nowhere, and an undeclared property in CSS renders
its fallback in silence, so eight surfaces had been drawing a palette nobody chose. Fixed across all eight
files in the same slice rather than deferred, on F-47's reasoning — the repair is a name substitution and a
list that exists to defer that is a list this project has ruled against writing.

`HandheldLayoutContractTests` goes from four facts to six: the breakpoint fact is renamed and widened, and
two are new — every custom property the tree reads is declared, and §11.4's area row is rendered once. That
last one had no assertion at all until now, which is worth naming: the sentence has been in the ledger, in
§11.12 and in the component's own doc comment since Slice 30 while nothing in the tree had an opinion about
a seventh administration page.

**What Slice 34 turned out to be, which is not what this paragraph used to predict.** It predicted a
conversion plus an extension of `SharedSelectorPrefixes`, and said that the extension *is* the stage rather
than a tidy-up afterwards (F-46). Both happened. What it did not predict is that the extension was
**blocked, and by the gate rather than by the pages**: the fact behind it matched a prefix against the
*text* of a `<style>` block, and three counter and kitchen components name `.chip` and `.muted` in CSS
comments explaining what they lean on — so adding those two prefixes reported findings on three correct
pages. That is **F-67**, and it makes three slices running whose finding was discovered by attempting the
work the previous slice had scheduled. Two more came with it: **F-65**, two control rules in `app.css` eight
pixels under the number §11.12 states, one of them beneath a comment asserting that it complied; and
**F-66**, the four `.manage-*` copies, whose overlaps with the stylesheet were a deprecated `clip` on four
pages, two chip colours off the palette, and inline form controls with no touch-target height at all.

**What is left of 1b.** The surfaces that were never record lists and were never the subject of F-59:
`CounterBoard`, `CounterSitting`, `KitchenBoard`, `TableHistory`, `TableJoinCode`, `CounterJoinCode`. Each
keeps its own `<style>` for rules only it reads — this project's standing arrangement for a statically
linked stylesheet — and **none of them re-declares a shared name any more**, so the prefix list already
covers them and there is nothing left to extend. What remains is a judgement per surface about whether its
own layout works at 375px, which is a different kind of work from a migration and is not tracked as one.

**The fallbacks are gone, and the paragraph that used to stand here is F-69.** It said *around a hundred
still, harmless where the name exists*, and it repeated a figure §11.12, §16.4 and F-64's ledger row all
carried: over a hundred, across sixteen components. By the time it was written the last time, Slice 34 had
emptied nine of the sixteen blocks and the truth was **fifty, across seven** — so the number that was the
entire argument for the rule being a *should* had been made wrong by the work in the same slice that cited
it. Fifty is an afternoon. All fifty are removed, §11.12 states the rule as a **must**, and no document
carries the count any more, because a count that can be derived from the tree must not be written into
prose beside it (F-47).

**And opening those seven blocks to do it turned up the slice's actual subject.** The first file read —
`TableHistory` — had the guest's irreversible-hide warning drawn in `#fdecea` on `#f5c2c0`, which is the
palette's `--danger-surface` and `--danger-hairline` copied and then drifted: **the same pair of values
Slice 34 removed from four `.chip-warn` copies, in a fifth place, one area over from where that sweep was
looking.** The class turned out to be ninety-five colour values written outside `:root`, twenty of them
byte-identical to a property declared there, three of those *inside `app.css` itself*, and three more
written as `rgba(22, 32, 43, …)`, which is `--ink` in decimal and the one form no scan for `#hex` could
have found. That is **F-68**, and it makes four slices running whose finding was discovered by attempting
the work the previous slice had scheduled. Every colour in the tree is now a property, and a ninth fact in
`HandheldLayoutContractTests` says so.

**One honest gap, recorded rather than glossed.** `/administration/sittings/{sitting}` is converted and is
the one §11.4 surface the barrier does not measure. Reaching a sitting needs a guest, a table token and a
join before there is an identifier to put in the route — scenario 3's arrangement, three scenarios of setup
for one measurement — and navigating to an invented identifier meets the not-found panel, which has no page
head, so the barrier would fail on arrival rather than measure anything. Its conversion rests on the
contract test and on reading `app.css`. That is the trade `/administration/hidden-records` is already
measured with, one route deeper.

`KitchenBoard` needs its own judgement rather than the same treatment. It is the one surface in this
system that is *not* read from a phone — §11.2 and §10.3 describe a wall-mounted kiosk with a wake lock —
so it is the one page where a wide layout is the primary case. The rule in §11.12 is that the handheld
layout is the *default*, not that every surface is optimised for a handset; the kitchen board satisfies it
by being legible at 375px, not by being designed for it.

### ~~1c — an end-to-end barrier at 375px~~ — **landed, M6 Slice 32, and ahead of 1b**

Nothing in this project had ever asserted anything about layout at any width, which is exactly why F-59
survived four milestones with every gate green. `HandheldLayoutContractTests` asserts the *structure* of
the rule — one breakpoint, one vocabulary, every cell labelled — and by construction cannot assert that a
control is reachable.

Normative in **S§16.4**; the scenario is **S§16.3's sixteenth**. An administrator walks all four
administration indexes in a context laid out at 375×667, and three numbers the page computes are asserted
against the viewport: `documentElement.scrollWidth` against `clientWidth`, every action's
`getBoundingClientRect` against the same, and every control's height against the 44px `--touch-target`
resolves to. `Harness/HandheldReach.cs` takes all of it in one `EvaluateAsync` round trip, so every number
describes the same moment rather than a dozen consecutive ones.

Three things about it are rulings rather than implementation, and each answers a way this could have been
a barrier that asserts nothing:

- **The viewport is asserted first**, and read back from the document rather than from the option that set
  it. At Playwright's default 1280 every other assertion in the scenario passes (F-41). It is compared as
  a ceiling with twenty pixels of allowance under it, because `clientWidth` excludes a classic scrollbar
  and headless Chromium draws one on every page here.
- **The count of measured controls is asserted.** Seven when it was written and nine since Slice 33 — two
  rows and a create button on people, one and one on tables, one and one on menu, nothing on sittings, and
  one filter submit on each explorer. A renamed `.record-actions` leaves five, a renamed
  `.page-head-action` leaves six and a renamed `.filter-actions` leaves seven, so the floor of eight
  catches all three.
- **The widest element is collected and may never fail a run.** An element wider than the viewport inside
  its own scroll container is correct — `.page-head-areas` is exactly that — so the walk skips anything
  inside a scroller and even then only writes the sentence that explains a failure. The two numbers decide.

The set of surfaces it visits is a list — four when it was written, six since Slice 33 — and it grows a
line per page 1b converts, which is the same arrangement `StillExpectedToCarryRetiredTableVocabulary`
already has and for the same reason (F-47). Slice 33 also widened its reach selector to cover a filter's
own submit, because §11.4's two explorers are read-only and have no other control at all.

**Why this ran before 1b, and the correction that decided it.** Slice 30 deferred this on the stated
ground that *the fifteen §16.3 scenarios all run in one default context*, so a second viewport meant
either an extra context per run or a resize every later scenario inherits. **That is not true of this
harness and never was.** `RestaurantHarness` holds one *browser*; `StartInstanceAsync` calls
`browser.NewContextAsync` per instance and `OpenIsolatedPageAsync` mints further ones on request. A
viewport belongs to a context, so there was nothing to share. The sentence was written once here and then
copied into S§16.4, into F-59's ledger row and into the Slice 30 BUILD_PROGRESS entry — three documents
asserting a property of a file none of them had read. It is **F-62**, and it is F-50's shape applied to
something that was never true rather than to something that stopped being true.

Given that, the order swapped. 1b is roughly 2,400 further lines of Razor; converting them before the
barrier existed would have meant converting them exactly the way the four pages in F-59 were written — by
hand, with nothing in the tree able to decide whether the result is reachable. Building the barrier first
also retro-proves Slice 30's four pages, which nothing until now could.

*(The previous version of this section closed by calling itself "the first item in Stage 6", noted at the
time as a typo for "the first open item". The sentence is gone with the gap it described.)*


---

## Stage 2 — sections and descriptions: schema and data access

**The section half landed in M6 Slice 37 (`0003`). Two of the item's three columns landed in M6 Slice 38
(`0004`). What remains is `menu_item.menu_section_identifier` and the three surfaces it forces (`0005`).**
This is the schema half of the enhancement request. It was written as one stage on its own because every
decision below is a `CREATE TABLE` or an `ALTER TABLE`, none of it is visible to anybody, and it is the half
that a surface cannot be written against until it exists.

The decisions here are **taken, not proposed**. §7 and §8.2 are edited in the same commit that implements
each of them.

### `menu_section`

```
menu_section
    menu_section_identifier  uuid PRIMARY KEY          -- application-generated UUIDv7 (ADR-0011)
    name                     citext NOT NULL UNIQUE    -- CHECK char_length BETWEEN 1 AND 80
    description              text NOT NULL DEFAULT ''  -- "Served until 11am" — optional, never NULL
    display_order            integer NOT NULL          -- CHECK >= 0; ties broken by name
    is_active                boolean NOT NULL DEFAULT true
    created_at               timestamptz NOT NULL
```

**`name` is `citext` and UNIQUE, and `menu_item.name` is neither.** That asymmetry is the ruling, not an
oversight. §7 already records why an item name carries no UNIQUE constraint — a kitchen runs "Soup" as a
rotating special, and two rows called the same thing is a real menu. Two sections called "Drinks" is never
a real menu; it is a mis-tap, and the guest sees the consequence as a heading that appears twice with the
items split arbitrarily between them. `citext` because "drinks" and "Drinks" are the same mistake.

**`display_order` is not UNIQUE.** A unique ordering column has to be reordered in two phases or with a
deferred constraint, for a menu with perhaps eight sections in it. Reads order by
`(display_order, name, menu_section_identifier)`, so ties are stable and never arbitrary.

**`description` is `NOT NULL DEFAULT ''` rather than nullable**, and so is `menu_item.description` below.
The reason is the paired CHECK on the event log: an *optional* payload column cannot be tied to its event
type by `(new_description IS NOT NULL) = (event_type = 'description_changed')`, because clearing a
description would then have to write NULL and break the constraint. With `''` as "none", clearing is a
value like any other and the CHECK is total. This project has both idioms already — `person.display_name`
is nullable and read through `NULLIF(btrim(…), '')` — and the tie-breaker is the constraint.

### `menu_section_event`

Append-only, mirroring every mutation in the same transaction, exactly as `menu_item_event` does (R§6.8 ·
S§7 · ADR-0002). Vocabulary: `created | renamed | described | reordered | activated | deactivated`. Typed
nullable payload columns `new_name`, `new_description`, `new_display_order`, each CHECK-bound to the types
that carry it. Actor and `occurred_at` NOT NULL.

### `menu_item` gains three columns

```
menu_item
    …
    menu_section_identifier  uuid NOT NULL REFERENCES menu_section   -- every item is in exactly one
    description              text NOT NULL DEFAULT ''
    display_order            integer NOT NULL DEFAULT 0              -- within its section
```

**Every item is in exactly one section, and the column is NOT NULL.** The alternative — nullable, with an
"Uncategorized" bucket rendered when it is not — is a second code path on every reading surface for a state
that exists only because the schema permitted it. A restaurant menu has headings; an item under no heading
is an item nobody decided about. The cost is that the first menu item cannot be created until a section
exists, which is one extra step on the very first use and is where the create-item form sends the
administrator when there are none.

**`display_order` on the item, not just the section.** Alphabetical is wrong on a real menu — "Fries"
before "Truffle Fries" is an ordering somebody chose, and `ORDER BY name` cannot express it. Same
non-unique treatment, same stable tiebreak.

### `menu_item_event` gains three types and three payload columns

New types: `description_changed`, `section_changed`, `reordered`. New payload columns `new_description`,
`new_menu_section_identifier`, `new_display_order`, each CHECK-bound.

**The `created` event keeps carrying name and price only.** An item created with a description and a
section writes `created`, then `description_changed`, then `section_changed`, in one transaction. The
alternative — widening `created` to carry all five — breaks the two existing paired CHECKs against every
`created` row already in the database, because a description is optional and those CHECKs are equalities.
The log reads *"Created as "Soup" at $4.50 / Description set / Filed under Starters"*, which is three lines
where one would do and is honest about it.

**The existing CHECK constraints are replaced by name, and the names are new.** `0001` declared them
inline, so PostgreSQL generated `menu_item_event_event_type_check`, `menu_item_event_check` and
`menu_item_event_check1` — deterministic, undocumented, and not a thing to depend on in a migration that
runs at startup on somebody else's box. `0003` drops every CHECK constraint on the table by querying
`pg_constraint` inside a `DO` block and adds back explicitly named ones. DbUp's PostgreSQL statement
splitter handles dollar-quoting correctly (verified against `PostgresqlQueryParser.ParseRawQuery` in
`DbUp/dbup-postgresql` — the `DollarQuoted` state machine consumes the whole tagged block, so a `;` inside
the `DO` body does not split the statement), so the block is safe in an embedded script.

### The boundary has now moved twice, and the second move is Slice 38's

**Slice 37 cut between the two tables.** The correction below explains why the stage as first written could
not ship green, and its answer was to pull three surfaces forward. Slice 37 declined that and cut between
`menu_section` and `menu_item` instead, so that `0003` touched nothing existing.

**Slice 38 cut again, between the item's own columns**, by the same test one register lower. `0004` adds
`menu_item.description` and `menu_item.display_order`, both `NOT NULL` with a `DEFAULT`, plus
`description_changed` and `reordered` with their payload columns and named CHECKs. **Nothing existing
changes meaning:** no backfill runs, no form is required to supply anything, and because `display_order`
defaults to 0 the new `ORDER BY (display_order, name, identifier)` *is* the `ORDER BY (name, identifier)`
every reader already had. The suite stays green by construction rather than by inspection.

`0005` is therefore the whole of what is left, and it is exactly the expensive part the correction below
identified: `menu_section_identifier uuid NOT NULL REFERENCES menu_section`, the conditional one-section
seed and the backfill beside it, `section_changed` with its payload column and a widened vocabulary CHECK —
droppable **by name** now, because `0004` replaced `0001`'s four generated names — and the three surfaces:
the section create page, the section picker on the item form, and a harness `CreateMenuSectionAsync` the
five ordering scenarios call before their first `CreateMenuItemAsync`. That last file is the one that decides
whether the ordering integration tests compile.

**Two rulings were settled by `0004` and are recorded here because they are not obvious from the schema.**
An item is created at position **0**, not appended at `MAX + 1` as a section is, because an item's position
is *within its section* and "the end of the menu" is undefined until `0005`. And the item's new event types
are spelled `description_changed` and `reordered` rather than `menu_section_event`'s `described` — each
table's vocabulary is internally consistent, and this one has said `name_changed` since `0001`.

### A correction to this stage's boundary, made before it was authored

**Stage 2 as written above cannot ship green, and the reason is one word in its own schema.**
`menu_section_identifier` is `NOT NULL`, so the moment migration `0003` applies, `CreateMenuItem.razor`
cannot create an item without naming a section — and `AdministrationJourneys.CreateMenuItemAsync` drives
that real form in six of the sixteen §16.3 scenarios — the five ordering scenarios and, since Slice 32,
the handheld barrier, which needs a row on `/administration/menu` to have anything to measure. A slice
that lands the schema and the data access
and leaves the surfaces for Stage 3 therefore lands a red suite, whatever the quality of the two halves.

So Stage 2 pulls three things forward out of Stage 3, and only three: the **section create page**, the
**section picker and description field on the item form**, and a harness `CreateMenuSectionAsync` the five
scenarios call before their first `CreateMenuItemAsync`. The section *index*, the section *editor* with its
event history, the rewritten guest menu and the kitchen panel's grouping all stay in Stage 3 — none of
them is on the path between `NOT NULL` and a green suite.

The alternative was considered and rejected: make the column nullable in `0003`, ship the surfaces in
Stage 3, and tighten it in `0004`. That is three migrations for two decisions, it puts an
"Uncategorized" state into the schema for exactly one slice, and every reading surface written during
that slice acquires a code path for it that then has to be removed. The ruling above — that an item under
no heading is an item nobody decided about — is worth more than the neatness of the stage boundary.

### The migration, in order

**As authored this was one script. It shipped as three.** `0003_menu_sections.sql` (Slice 37) is steps 1
below; `0004_menu_item_descriptions.sql` (Slice 38) is steps 3 and 6 for the two columns that carry
defaults; `0005` is steps 2, 4 and 5 plus the section half of step 6. `0001` and `0002` are **not** touched,
and neither are `0003` and `0004` now that they are applied: DbUp journals by script name, so editing an
applied script is a change that never runs (F-34's precedent, stated in its own row).

1. `CREATE TABLE menu_section`, `CREATE TABLE menu_section_event`, indexes.
2. Seed **one** section — and only if `menu_item` has rows. A fresh database gets no sections and the
   administrator names their own; an existing one gets a section to hold what is already there. The seed's
   identifier is a fixed UUIDv7 literal written into the script rather than `gen_random_uuid()`, because
   ADR-0011 puts identifier generation in the application and a migration is the one place with no
   application to ask — a literal is at least auditable and identical on every host.
3. `ALTER TABLE menu_item ADD COLUMN description`, `display_order`, and
   `menu_section_identifier uuid NULL`.
4. Backfill `menu_section_identifier` to the seed.
5. `ALTER COLUMN menu_section_identifier SET NOT NULL` and add the foreign key.
6. Replace `menu_item_event`'s CHECK constraints, add the three payload columns and their CHECKs.

Steps 3–5 are the standard safe sequence for adding a NOT NULL foreign key to a populated table, and the
order matters: `SET NOT NULL` before the backfill fails on the existing rows.

**No projection view changes.** `order_current_line` joins `menu_item` for its name and needs nothing
else; the kitchen groups tickets by table and person, not by menu section. That is worth stating because
it is the surprising half: the schema of record grows four columns and two tables, and §8.3 does not move.

### Data access

| File | Change |
|---|---|
| ~~`Menu/MenuSectionDirectory.cs`~~ | **new** — `MenuSectionSummary`, `IMenuSectionDirectory`, `DapperMenuSectionDirectory` — **landed, Slice 37** |
| ~~`Menu/MenuSectionAdministration.cs`~~ | **new** — create / rename / describe / reorder / set-active, one transaction each, `FOR UPDATE` before every comparison — **landed, Slice 37**; `display_order` is assigned by appending rather than supplied, and a rename is compared ordinally though the column is `citext` |
| `Menu/MenuDirectory.cs` | `MenuItemSummary` gained `Description` and `DisplayOrder` and the reads order by position then name — **landed, Slice 38**. `MenuSectionIdentifier`, `MenuSectionName` and `ListBySectionAsync` wait for `0005` |
| `Menu/MenuAdministration.cs` | `CreateMenuItemAsync` takes a description; `DescribeMenuItemAsync` and `ReorderMenuItemAsync` added — **landed, Slice 38**. `MoveMenuItemToSectionAsync` and the section argument wait for `0005` |
| `Menu/MenuEventLog.cs` | `new_description` and `new_display_order` — **landed, Slice 38**. `ListForSectionAsync` and the `UNION ALL` over both logs with a subject discriminator wait for Stage 3, which is the first surface that reads a section's history |
| `WebApplication/Menu/MenuWorkflow.cs` | a verb per write, `MenuChanged` published only when something actually moved — **the item verbs landed, Slice 38**. The five *section* writes are still not behind `IMenuWorkflow`, which is deliberate and is Stage 3's obligation |
| `WebApplication/Orders/OrdersServiceCollectionExtensions.cs` | registers the two new services, in the menu group, for the reason recorded there |

Tests that move with it: `MenuDirectoryTests`, `MenuAdministrationTests`, `MenuAvailabilityTests`,
`MenuEventLogTests`, `MenuWiringTests`, `SchemaMigrationRunnerTests`, and `OrderTestWorld` — which creates
menu items directly in SQL and is therefore the file that decides whether every ordering integration test
compiles.

Documentation in the same commit: **S§7** rewritten, **S§8.2** DDL, **S§16.4**, **S Appendix A**,
**S changelog v1.16**, **R§6.8**, **ADR-0014** (already written, marked accepted), **DOCUMENTATION_REVIEW**
(this is an enhancement, so it takes no F-number — enhancements are recorded in BUILD_PROGRESS and the
specification changelog, and the ledger is for findings).

---

## Stage 3 — sections and descriptions: the surfaces

**Not started.** The UI/UX half, on the Stage 1 foundation.

**`/administration/menu`** becomes sections-first: a record list of sections, each expandable to its items,
with the section's own order controls. The flat name-ordered list of every item goes away — it is what a
menu looks like when the model cannot express a menu.

**`/administration/menu/sections/new` and `/administration/menu/sections/{id}`**, matching the shape
`CreateTable`/`ManageTable` and `CreateMenuItem`/`ManageMenuItem` already have: static SSR, one form per
verb, post/redirect/get with a one-word outcome, and the section's complete uncapped event history at the
bottom (§11.4 — the complete stored record, never truncated for the administrator).

**`/administration/menu/new` and `/{id}`** gain a required section picker, a description `textarea`
(`app.css` already styles one — added in Slice 30 for this), and a position control. Reprice, rename and
the 86 toggle are unchanged.

**The guest menu is the part that was actually asked for.** Today it is one `<select>` with every item
flattened into it and the price glued onto the label — which is unreadable at eleven items and absurd at
sixty, and has nowhere to put a description. It becomes: a section heading, then a card per item with its
name, price, description, and an "Add" control; a section's own description under its heading; and
`disabled` items still present and marked *currently unavailable*, because §7 requires that and it is the
one thing about the current picker that is right. The basket, the Send button, the all-or-nothing rejection
panel and the party totals below it do not change — this is the picker, not the order surface.

**The kitchen 86 panel** groups by section, for the reason the guest menu does: a cook looking for the
salmon looks under the heading it is on.

**One new §16.3 scenario**: create a section, create an item in it with a description, and read both back
from the guest surface. Numbered 17, appended rather than inserted, because the harness names scenarios by
number in a great many places. It was numbered 16 when this was written; Slice 32's handheld barrier took
that number, which is what appending costs and is cheaper than renumbering sixteen of them.

---

## Stage 4 — images

**Not started, and the model consequence is recorded now because that is what was asked for.** "In the
future we might even have images" is a question about where bytes live, and the answer is much cheaper to
give before there is data than after.

**Recommendation: `bytea` in PostgreSQL, one image per item, hard size cap.**

The alternative is a volume on disk, and the argument against it is F-38's. §15 *defines* a recovery set as
exactly two files — the database dump and the Data Protection key ring — and `restore_drill.sh` gates both
on every push. A third artefact means editing that definition, both scripts, the drill, and the runbook;
and an operator who takes a backup the old way from then on has a set that restores an application whose
menu has no pictures in it. Object storage is worse: MinIO is a service, S3 is a paid dependency, and both
contradict R§1's self-hosted premise.

The cost of `bytea` is honest and small at this scale: sixty items at 200 KB is 12 MB, inside a `pg_dump
-Fc` that already compresses, on a database whose whole reason for existing is one restaurant.

```
menu_item_image
    menu_item_image_identifier  uuid PRIMARY KEY
    menu_item_identifier        uuid NOT NULL UNIQUE REFERENCES menu_item   -- one image per item, in v1
    content_type                text NOT NULL CHECK (content_type IN ('image/jpeg', 'image/png', 'image/webp'))
    byte_length                 integer NOT NULL CHECK (byte_length BETWEEN 1 AND 524288)
    pixel_width                 integer NOT NULL CHECK (pixel_width BETWEEN 1 AND 4096)
    pixel_height                integer NOT NULL CHECK (pixel_height BETWEEN 1 AND 4096)
    bytes                       bytea NOT NULL
    uploaded_by_person_identifier uuid NOT NULL REFERENCES person
    uploaded_at                 timestamptz NOT NULL
```

Plus `menu_item_image_event` (`attached | replaced | removed`), because every other mutation in this schema
leaves a log and an image is the one a guest sees.

Four consequences that have to be settled in the same slice:

1. **The route and its caching.** `GET /menu/image/{menu_item_image_identifier}` rather than
   `…/{menu_item_identifier}`, so the URL changes when the image does and `Cache-Control: public,
   max-age=31536000, immutable` is truthful. Keying on the item identifier would need an ETag and a
   revalidation round trip per image per page load, on phones.
2. **The content security policy.** F-49's whole lesson is that this is the one configuration that becomes
   wrong by editing a file it does not mention. §11.11 sets `default-src 'self'` and declares no
   `img-src`, so `'self'` already covers bytes this application serves — the policy needs **no** change,
   and `ContentSecurityPolicyContractTests` should be made to say so rather than left to be true by
   accident.
3. **No resizing, and say so.** There is no free-libre .NET image library in this stack — ImageSharp's
   licence is not AGPL-compatible for this use and SkiaSharp is a native dependency in a rootless
   container. So the server validates and stores what it is given, and the size cap is the whole defence.
   Whether a browser downscales before upload (a `<canvas>` round trip, perhaps 60 lines of
   `wwwroot/js/`) is the open question of this stage, and it is a real one: a phone camera produces 4 MB
   and the cap above is 512 KB, so without it the answer to most uploads is "too big".
4. **The 375px layout.** An image per card doubles the height of the guest menu. A thumbnail beside the
   name rather than a hero above it, and `loading="lazy"` on everything below the first section.

**Reversible if the recommendation is wrong.** `bytea` → volume is a migration that reads rows and writes
files; volume → `bytea` is a migration that cannot find the files. Choosing the reversible direction first
is the whole reason to choose now.

---

## Stage 5 — likes

**Not started.** Deliberately split from comments, and the split is the recommendation: a like is a
number, a comment is a person's words shown to strangers, and only one of those raises a question this
system has never answered.

The shape is already in the tree. §8.3's `order_visibility_event` + `order_visibility_current` is an
append-only per-person boolean folded by `DISTINCT ON`, which is exactly a like:

```
menu_item_reaction_event
    menu_item_reaction_event_identifier uuid PRIMARY KEY
    menu_item_identifier                uuid NOT NULL REFERENCES menu_item
    person_identifier                   uuid NOT NULL REFERENCES person
    event_type                          text NOT NULL CHECK (event_type IN ('liked', 'unliked'))
    occurred_at                         timestamptz NOT NULL
```

with `menu_item_reaction_current` as the `DISTINCT ON (menu_item_identifier, person_identifier)` fold and a
count per item on top of it. No new idiom, no moderation, no text, no rate-limit question worth the name —
a like and an unlike from one person is a row per press and the fold is the answer.

Two rulings needed before it ships. **Who sees the count** — a guest, or only staff? A count of 3 on a
menu of sixty items is noise that makes the restaurant look empty, so the honest answer is probably staff
until it is not, which makes this an administration read first and a guest-facing number later. And
**whether it requires having ordered the item**, which is the same question Stage 6 asks about comments
and is cheaper to answer here.

---

## Stage 6 — comments, and what has to be settled first

**Not started, and not startable.** This is the one item in the request that cannot be planned into a
slice yet, and it is worth being precise about why rather than calling it "future work".

A comment is the first **user-generated content** in this system. Every text field a guest can write today
— a display name, a customization note — is read by staff. A comment is read by other guests. Four things
follow, and three of them are edits to documents rather than to code.

1. **Rate limiting, and it is a known wall.** §17 records that `/register` has no rate limit and states the
   concrete reason it is not a two-line addition: a second naive `AddRateLimiter` policy hijacks §4.2's
   single-valued rejection handler, so a refused registration would answer *"too many pairing attempts"* —
   wrong, and deliberate-looking. Comments hit the identical wall. **This stage cannot land before that
   ruling is revisited**, and revisiting it is a slice of its own with no menu in it.
2. **Privacy, and it is new intent.** §5.3 gives absolute table-to-table privacy: a guest never learns who
   else is in the building. A comment signed with a display name is this system disclosing one person's
   name to strangers for the first time. Initials, an opt-in, a pseudonym, or "a guest" are all defensible;
   none of them is currently written down, and choosing means a `REQUIREMENTS.md` revision under rev 3's
   reasoning rather than rev 2's — new intent, not a mechanism catching up.
3. **Moderation is not optional, and §6.8 is the model.** The vocabulary already exists: hiding, never
   deletion, with an administration surface that can find what was hidden and unhide it. A comment gets
   `posted | edited | hidden | unhidden` and the hidden-records page gains a second kind of record.
4. **Rendering, and the second line of defence is already there.** Comment text goes through Razor's
   default HTML encoding and must never reach a `MarkupString`; §11.11's `script-src` carries no
   `'unsafe-inline'`, which is what F-49 built it for. `ContentSecurityPolicyContractTests` computes what
   the application loads by scanning the tree, so it will notice a new inline handler on its own.

**Recommendation: do Stage 5 and stop.** Likes answer "which of these is popular" with no new question
attached. Comments answer a question nobody has asked for yet at the cost of a rate-limiting slice, a
requirements revision about guest privacy, and a moderation surface — and the request itself says *"I am
not sure if it is doable right now"*, which is the correct instinct.

---

## Not in any stage, and recorded so it is not mistaken for an oversight

- **Allergens, dietary flags, and nutrition.** Not asked for, and a system that displays "gluten free"
  without a mechanism guaranteeing it is worse than one that says nothing. §7's existing sentence about
  customization notes — *"an impossible request is handled by a human walking to the table"* — is the
  project's position on this whole class, and it holds.
- **Per-section availability windows** ("Breakfast, served until 11am"). Tempting, because "breakfast
  options" was named in the request. It is a scheduling feature: it needs a time-of-day model, a decision
  about what happens to a basket at 11:00:01, and `RESTAURANT_TIME_ZONE` in a code path that currently only
  formats. A section *description* saying "served until 11am" costs nothing and is honest; the 86 toggle
  already exists for the rest. Revisit only if somebody asks twice.
- **Sub-sections.** "Drinks → Hot / Cold" is a tree, and a tree is a recursive query, a recursive renderer
  and an ordering question at every level, for a menu with eight headings on it. One level, and if a menu
  outgrows it that is evidence rather than a guess.
- **Menu item images in the kitchen ticket.** A cook does not need a picture of what they are cooking.
