using System.Security.Cryptography;
using Microsoft.Playwright;
using MyRestaurant.Domain.Security;
using MyRestaurant.EndToEnd.Tests.Harness;
using MyRestaurant.WebApplication.Displays;
using MyRestaurant.WebApplication.Identity;
using Xunit;

namespace MyRestaurant.EndToEnd.Tests;

/// <summary>
/// The §16.3 end-to-end scenario matrix (TECHNICAL_SPECIFICATION), version-controlled from M1 as
/// skipped placeholders and implemented against a real browser from M6 Slice 2 onwards.
///
/// <para>Five are live. M6 Slice 2 brought <b>1</b> (the first-administrator bootstrap, including a real
/// WebAuthn attestation and a real TOTP confirmation), <b>13</b> (a passkey sign-in of a TOTP-enrolled
/// person must not be challenged for a code) and <b>14</b> (the join-token window arithmetic as a guest
/// experiences it) — chosen because between them they exercise the whole harness. M6 Slice 3 adds
/// <b>2</b> (a display pairs and its QR advances across a window boundary) and <b>15</b> (rotating a
/// table's join secret kills every outstanding code and the paired display recovers by itself), which
/// are the two scenarios about the rotating code as a <em>screen</em> rather than as a URL.</para>
///
/// <para>Every scenario begins with <see cref="SkipUnlessHarnessAvailable"/>. The scenarios are opt-in
/// (<c>MYRESTAURANT_E2E=1</c>) and additionally need a container engine, a Chromium build and a
/// current build of the web application; each absence is a skip with the fix in its message. See
/// <see cref="RestaurantHarness"/>.</para>
/// </summary>
public sealed class EndToEndScenarios : IClassFixture<RestaurantHarness>
{
    private const string PendingHarnessExtension =
        "Awaiting a later M6 slice: the harness is in place (Harness/RestaurantHarness.cs), but this"
        + " scenario needs surface plumbing it does not have yet.";

    /// <summary>
    /// The rotation window for the two scenarios that must watch a boundary go past (§13's floor is ten
    /// seconds; the application's own default is sixty). Twenty is a compromise with a reason on each
    /// side: long enough that a paused container or a slow page load cannot push a two-step assertion
    /// across two boundaries, short enough that waiting for the §4.3 refresh is seconds rather than a
    /// minute. Everything either scenario asserts is expressed relative to the window index, so the
    /// exact number is not load-bearing — only its order of magnitude is.
    /// </summary>
    private const int BoundaryWatchingRotationSeconds = 20;

    private readonly RestaurantHarness _harness;

    public EndToEndScenarios(RestaurantHarness harness) => _harness = harness;

    // -------------------------------------------------------------------------------------------
    // 1. Fresh stack → /setup bootstrap (passkey via virtual authenticator, TOTP, admin granted)
    //    → /setup now 404.
    // -------------------------------------------------------------------------------------------
    [Fact]
    public async Task Setup_BootstrapsFirstAdministratorThenBecomes404()
    {
        SkipUnlessHarnessAvailable();
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;

        await using RestaurantInstance instance =
            await _harness.StartInstanceAsync(cancellationToken: cancellationToken);
        IPage page = instance.Page;

        // The gate is open on an empty database, and the wizard starts at step one.
        IResponse? open = await page.GotoAsync(AccountRoutes.Setup);
        Assert.NotNull(open);
        Assert.Equal(200, open.Status);
        Assert.Equal("Create the first administrator", await HeadingAsync(page));

        IReadOnlyList<string> recoveryCodes =
            await AccountJourneys.CompleteSetupAsync(page, AccountJourneys.DefaultAdministrator);

        Assert.Equal("You are the administrator", await HeadingAsync(page));
        Assert.Equal(AccountJourneys.ExpectedRecoveryCodeCount, recoveryCodes.Count);
        Assert.All(recoveryCodes, code => Assert.False(string.IsNullOrWhiteSpace(code)));

        // §3.6's own words: "the moment one does, this page returns 404". The panel still renders — a
        // person who bookmarked it deserves a sentence, not a blank error — so the status code is the
        // assertion, not the body.
        IResponse? closed = await page.GotoAsync(AccountRoutes.Setup);
        Assert.NotNull(closed);
        Assert.Equal(404, closed.Status);
    }

    // -------------------------------------------------------------------------------------------
    // 2. Admin creates table → pairing code → device pairs at /display/pair → /display/{table}
    //    shows a rotating QR that changes across a window boundary.
    // -------------------------------------------------------------------------------------------
    [Fact]
    public async Task Display_PairsAndShowsRotatingQrAcrossWindowBoundary()
    {
        SkipUnlessHarnessAvailable();
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;

        const string tableLabel = "E2E Two";

        await using RestaurantInstance instance =
            await _harness.StartInstanceAsync(BoundaryWatchingRotationSeconds, cancellationToken);

        // The whole scenario is an administrator's doing, so it needs an administrator; §3.6's wizard is
        // the only way one comes into existence and it signs them in on the same response.
        IPage administrator = instance.Page;
        await AccountJourneys.CompleteSetupAsync(administrator, AccountJourneys.DefaultAdministrator);

        Guid tableIdentifier = await AdministrationJourneys.CreateTableAsync(administrator, tableLabel);
        string pairingCode = await AdministrationJourneys.IssuePairingCodeAsync(administrator, tableIdentifier);

        // The tablet, in its own browser. Not hygiene: the display middleware ignores a device credential
        // on any request the Identity cookie already authenticated, so pairing inside the administrator's
        // browser would produce a screen that is the administrator and renders no code at all.
        IPage display = await instance.OpenIsolatedPageAsync();

        // §11.5's first rule, before anything is paired: an unpaired screen asking for a table display is
        // sent to the pairing surface rather than to a sign-in page a tablet could never satisfy.
        await display.GotoAsync(DisplayRoutes.ForTable(tableIdentifier));
        Assert.Equal("Pair this display", await HeadingAsync(display));

        Guid pairedTable = await DisplayJourneys.PairAsync(display, pairingCode, "E2E Window Tablet");

        // The code paired this device to the table it was issued for, and the surface is the table's own.
        Assert.Equal(tableIdentifier, pairedTable);
        Assert.Equal(tableLabel, await HeadingAsync(display));

        // §4.1 lets nothing render or return the join secret, so the row is the only place to learn what
        // the server is signing with — which is precisely what makes the next two assertions worth making
        // rather than tautological.
        byte[] joinSecret = await instance.ReadJoinSecretAsync(tableIdentifier, cancellationToken);

        // Read the screen first, then the clock: the server rendered at or before the read, so the window
        // sampled afterwards is the newest one the screen could possibly be showing.
        string firstCode = await DisplayJourneys.ReadJoinQrPathAsync(display);
        AssertShowingLiveJoinCode(firstCode, joinSecret, tableIdentifier, instance);

        // §16.3 scenario 2's actual demand: the QR *changes across a window boundary*. Waiting for a
        // different path is waiting for §4.3's window-aligned refresh; the assertion that follows is what
        // separates "the screen redrew" from "the screen advanced to the next window's code".
        string secondCode = await DisplayJourneys.WaitForJoinQrPathAsync(
            display,
            candidate => !string.Equals(candidate, firstCode, StringComparison.Ordinal),
            RefreshPatience(instance.TableJoinTokenRotationSeconds),
            "a join code different from the one it started on",
            cancellationToken);

        Assert.NotEqual(firstCode, secondCode);
        AssertShowingLiveJoinCode(secondCode, joinSecret, tableIdentifier, instance);
    }

    // -------------------------------------------------------------------------------------------
    // 13. Passkey sign-in of a TOTP-enrolled user → no TOTP challenge.
    // -------------------------------------------------------------------------------------------
    [Fact]
    public async Task PasskeySignIn_OfTotpUser_SkipsTotpChallenge()
    {
        SkipUnlessHarnessAvailable();
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;

        await using RestaurantInstance instance =
            await _harness.StartInstanceAsync(cancellationToken: cancellationToken);
        IPage page = instance.Page;
        AdministratorAccount account = AccountJourneys.DefaultAdministrator;

        // The §3.6 wizard registers a passkey AND enrolls TOTP in one pass, which is exactly the
        // account shape this scenario is about: a person who has both, signing in with one of them.
        await AccountJourneys.CompleteSetupAsync(page, account);
        await AccountJourneys.SignOutAsync(page);
        await AccountJourneys.SignInWithPasskeyAsync(page, account.Username);

        // The whole point (§3.5, ADR-0010): TOTP guards the password path only. PasskeySignInAsync
        // cannot return RequiresTwoFactor by construction, and this is the observable consequence.
        Assert.DoesNotContain(AccountRoutes.SignInTwoFactor, page.Url);
        Assert.DoesNotContain(AccountRoutes.SignInRecoveryCode, page.Url);

        // And it is a real session, not merely a page that failed to redirect.
        ILocator sessionName = page.Locator("span.session-name").First;
        await sessionName.WaitForAsync(new LocatorWaitForOptions { Timeout = 30_000 });
        Assert.Equal(account.Username, (await sessionName.InnerTextAsync()).Trim());
    }

    // -------------------------------------------------------------------------------------------
    // 14. Expired token URL → friendly expiry page; token from previous window → accepted.
    // -------------------------------------------------------------------------------------------
    [Fact]
    public async Task JoinToken_ExpiredShowsFriendlyPage_PreviousWindowAccepted()
    {
        SkipUnlessHarnessAvailable();
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;

        const int rotationSeconds = RestaurantInstance.DefaultTableJoinTokenRotationSeconds;

        await using RestaurantInstance instance =
            await _harness.StartInstanceAsync(rotationSeconds, cancellationToken);
        IPage page = instance.Page;

        // Real signing material, held only here and in the row — the server reads it back through
        // ITableJoinSecretReader, so a token computed here is a token it will genuinely verify.
        byte[] joinSecret = RandomNumberGenerator.GetBytes(32);
        Guid tableIdentifier = await instance.InsertActiveTableAsync(
            "E2E Fourteen", joinSecret, cancellationToken);

        long currentWindow = JoinTokenService.CurrentWindowIndex(DateTimeOffset.UtcNow, rotationSeconds);

        // (a) Four windows back is inside §4.3's bounded lookback, so it is classified Expired rather
        // than Invalid — and §4.4 renders one friendly page for every failure, with no oracle detail
        // about which thing went wrong. Deliberately first: it must write no grant.
        string staleToken = JoinTokenService.ComputeToken(joinSecret, tableIdentifier, currentWindow - 4);
        await page.GotoAsync(JoinPath(tableIdentifier, staleToken));

        Assert.Equal("That code has expired", await HeadingAsync(page));
        Assert.DoesNotContain(AccountRoutes.SignIn, page.Url);

        // (b) The immediately previous window is accepted (§4.3: "the current and previous window"), so
        // the grant is written and an anonymous scanner is sent to sign in with this table as the
        // return URL. That redirect IS the acceptance — it is what the guest flow does next (§4.4).
        string previousWindowToken =
            JoinTokenService.ComputeToken(joinSecret, tableIdentifier, currentWindow - 1);
        await page.GotoAsync(JoinPath(tableIdentifier, previousWindowToken));

        Assert.Contains(AccountRoutes.SignIn, page.Url);
        Assert.Contains(tableIdentifier.ToString("D"), page.Url);
    }

    // -------------------------------------------------------------------------------------------
    // 15. Admin rotates a table's join secret → in-flight token dies; display's next window works.
    // -------------------------------------------------------------------------------------------
    [Fact]
    public async Task Admin_RotatesJoinSecret_InFlightTokenDiesNextWindowWorks()
    {
        SkipUnlessHarnessAvailable();
        CancellationToken cancellationToken = TestContext.Current.CancellationToken;

        const string tableLabel = "E2E Fifteen";

        await using RestaurantInstance instance =
            await _harness.StartInstanceAsync(BoundaryWatchingRotationSeconds, cancellationToken);

        // Read back rather than restated: every window computation below is against the value the
        // application was actually configured with, not the value it was asked for.
        int rotationSeconds = instance.TableJoinTokenRotationSeconds;

        IPage administrator = instance.Page;
        await AccountJourneys.CompleteSetupAsync(administrator, AccountJourneys.DefaultAdministrator);

        Guid tableIdentifier = await AdministrationJourneys.CreateTableAsync(administrator, tableLabel);
        string pairingCode = await AdministrationJourneys.IssuePairingCodeAsync(administrator, tableIdentifier);

        IPage display = await instance.OpenIsolatedPageAsync();
        await DisplayJourneys.PairAsync(display, pairingCode, "E2E Rotation Tablet");

        byte[] originalSecret = await instance.ReadJoinSecretAsync(tableIdentifier, cancellationToken);
        string codeBeforeRotation = await DisplayJourneys.ReadJoinQrPathAsync(display);
        AssertShowingLiveJoinCode(codeBeforeRotation, originalSecret, tableIdentifier, instance);

        // Exactly what a guest holding a freshly scanned code has: this window's token under the secret
        // in force right now. §4.1's promise — "immediately invalidates every outstanding QR" — is a
        // promise about this string and nothing else.
        string inFlightToken = JoinTokenService.ComputeCurrentToken(
            originalSecret, tableIdentifier, DateTimeOffset.UtcNow, rotationSeconds);

        await AdministrationJourneys.RotateJoinSecretAsync(administrator, tableIdentifier);

        byte[] rotatedSecret = await instance.ReadJoinSecretAsync(tableIdentifier, cancellationToken);
        Assert.NotEqual(originalSecret, rotatedSecret);

        // (a) The in-flight token dies at once, not at the next boundary. Deliberately before the
        // acceptance half below, so that no grant cookie exists which could carry this browser past a
        // refusal and quietly turn a failure into a pass.
        IPage guest = await instance.OpenIsolatedPageAsync();
        await guest.GotoAsync(JoinPath(tableIdentifier, inFlightToken));

        Assert.Equal("That code has expired", await HeadingAsync(guest));
        Assert.DoesNotContain(AccountRoutes.SignIn, guest.Url);

        // (b) "The display's next window works": within one rotation the paired screen re-renders a code
        // the NEW secret signs, with nobody touching the tablet and nothing re-pairing it. The predicate
        // is the assertion here — waiting for merely *a different* path would also be satisfied by a
        // display that had drifted onto some other window of the old secret.
        string codeAfterRotation = await DisplayJourneys.WaitForJoinQrPathAsync(
            display,
            candidate => JoinQrCodes.IsLive(
                candidate,
                rotatedSecret,
                tableIdentifier,
                instance.PublicOrigin,
                DateTimeOffset.UtcNow,
                rotationSeconds),
            RefreshPatience(rotationSeconds),
            "a join code signed by the rotated secret",
            cancellationToken);

        Assert.NotEqual(codeBeforeRotation, codeAfterRotation);

        // ...and the new sequence is one a guest can actually use, which is what "works" has to mean.
        string freshToken = JoinTokenService.ComputeCurrentToken(
            rotatedSecret, tableIdentifier, DateTimeOffset.UtcNow, rotationSeconds);
        await guest.GotoAsync(JoinPath(tableIdentifier, freshToken));

        Assert.Contains(AccountRoutes.SignIn, guest.Url);
        Assert.Contains(tableIdentifier.ToString("D"), guest.Url);
    }

    // -------------------------------------------------------------------------------------------
    // Still to come. Each is one required §16.3 scenario, named so the matrix stays legible.
    // -------------------------------------------------------------------------------------------

    [Fact(Skip = PendingHarnessExtension)]
    public void Guest_ScansRegistersWithPasskeyAndJoins()
    {
        // 3. Guest scans (simulated URL from current token) → registers with passkey → joins; sitting
        //    created. Needs the guest registration journey, which is not the same page as /setup, and a
        //    virtual authenticator on the guest's own context rather than the administrator's.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Guest_StagesAddsAndSend_KitchenGetsOneAlert()
    {
        // 4. Guest stages 2 adds + note → Send → kitchen gets one loud alert → lines pending.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void SecondGuest_JoinsAndSeesOrderLiveWithRosterUpdate()
    {
        // 5. Second guest joins via fresh token → sees first guest's order live; first guest sees
        //    roster update. Needs two live circuits in two contexts at once.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Kitchen_FulfillsLine_GuestSeesFulfilledBadge()
    {
        // 6. Kitchen fulfills one line → guest sees fulfilled badge.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Guest_RemoveFulfilledLineRejected_RemovePendingSucceeds()
    {
        // 7. Guest removes fulfilled line → whole batch rejected with per-op reason; removing pending
        //    line succeeds.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Send_UnfulfilledPastThreshold_YieldsExactlyOneReminder()
    {
        // 8. A send sits unfulfilled 60 s → exactly one reminder alert. Wants a short
        //    KITCHEN_SUBMISSION_REMINDER_SECONDS rather than sixty seconds of waiting.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Counter_AdjustsPriceWithReason_GuestSeesOldToNew()
    {
        // 9. Counter adjusts a price with reason → guest sees old → new with reason.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Counter_ClosesSitting_TableFlipsToSettledAndTotalsMatch()
    {
        // 10. Counter closes (pending-line warning) → table flips to settled read-only; totals match.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Guest_HidesClosedOrder_AdminCanUnhide()
    {
        // 11. Guest hides a closed order → gone from own history (staff/admin unchanged); admin
        //     filters the hidden-records view by username → Unhide restores it.
    }

    [Fact(Skip = PendingHarnessExtension)]
    public void Admin_ResetsTotpUser_ForcesPasswordThenTotpReenrollment()
    {
        // 12. Admin resets TOTP-enrolled user → password sign-in → forced password change → forced
        //     TOTP re-enroll → lands home; the passkey path hits the pipeline too.
    }

    // --- helpers ---------------------------------------------------------------------------------

    private void SkipUnlessHarnessAvailable()
        => Assert.SkipUnless(
            _harness.SkipReason is null,
            _harness.SkipReason ?? "The end-to-end harness is unavailable.");

    /// <summary>
    /// The page's single <c>h1</c>, trimmed. Every surface has exactly one — <c>Routes.razor</c>'s
    /// <c>FocusOnNavigate</c> depends on that too — so this doubles as a check that it still holds.
    /// </summary>
    private static async Task<string> HeadingAsync(IPage page)
        => (await page.Locator("h1").First.InnerTextAsync()).Trim();

    private static string JoinPath(Guid tableIdentifier, string token)
        => $"/table/{tableIdentifier:D}?token={Uri.EscapeDataString(token)}";

    /// <summary>
    /// How long to wait for §4.3's window-aligned refresh. Two full rotations plus slack: one window
    /// because the display fires at the <em>next</em> boundary and the wait may have started just after
    /// the last one, a second because a container under load can lose a boundary, and twenty seconds
    /// because a timeout that fires while the thing was about to happen is the worst kind of flake.
    /// </summary>
    private static TimeSpan RefreshPatience(int rotationSeconds)
        => TimeSpan.FromSeconds((rotationSeconds * 2) + 20);

    /// <summary>
    /// Asserts that the QR on screen is the code this table's secret produces for the current or the
    /// previous window — §4.3's definition of one that still validates.
    ///
    /// <para>The comparison is deliberately reported as a phrase rather than as two thousand characters of
    /// SVG path: a display frozen on a stale code and a display showing a code from another table both
    /// fail this, and which of the two it was is the entire content of the failure.</para>
    /// </summary>
    private static void AssertShowingLiveJoinCode(
        string observedQrPath,
        byte[] joinSecret,
        Guid tableIdentifier,
        RestaurantInstance instance)
    {
        long newestWindowIndex = JoinTokenService.CurrentWindowIndex(
            DateTimeOffset.UtcNow, instance.TableJoinTokenRotationSeconds);

        string age = JoinQrCodes.Classify(
            observedQrPath,
            joinSecret,
            tableIdentifier,
            instance.PublicOrigin,
            newestWindowIndex);

        Assert.Contains(age, JoinQrCodes.LiveAges);
    }
}
