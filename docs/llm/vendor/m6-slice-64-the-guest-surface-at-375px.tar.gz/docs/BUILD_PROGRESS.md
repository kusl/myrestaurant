# Build progress

**This file is the second part of one log, and the log's name is `BUILD_PROGRESS`.** It holds **M6 Slice
40 onward** and is the file a new slice is appended to. Everything before it — M1 through **M6 Slice
39**, including the original *How this was produced*, *Staged plan* and *Known caveats* preamble — is in
[`docs/progress/BUILD_PROGRESS_THROUGH_M6_SLICE_39.md`](progress/BUILD_PROGRESS_THROUGH_M6_SLICE_39.md).

**A citation resolves by slice number, and there is exactly one rule.** Every row in
`docs/DOCUMENTATION_REVIEW.md` and in the specification's Appendix A ends with a reference of the form
*BUILD_PROGRESS M6 Slice N*. Those references are to the **log**, not to a file, and they were not
rewritten when the log was split — rewriting a hundred rows to record a filing decision would be a
hundred chances to introduce an error in service of nothing. Slices 1 to 39 are in the archive; 40 onward
are here.

**`export.sh` does not put the archive in `dump.txt`, and that is the point (F-96).** The log had reached
829 KiB, 13% of a 6.08 MiB context dump, nearly all of it slices closed months ago. `docs/progress/` is
therefore withheld from the dump by path, the way `docs/llm/` already was. **The consequence is a
hazard and is written down rather than left to be discovered:** a session working from `dump.txt` cannot
see the archive, so nothing in a session may reconstruct it, and **this file must never be delivered as
though it were the whole log.** `ContextDumpExclusionContractTests` holds the tree to the checkable half
of that — every withheld document is linked by path from a document the dump does contain, so history
that leaves the dump leaves a pointer behind.

**When this file gets long again, another tranche moves.** That is a deliberate manual decision each
time, not a rule a script applies: choosing where a log stops being working memory and starts being
archaeology is a judgement, and the last thing this project needs is a script that silently truncates its
own history on a size threshold.

---

# M6 Slice 40 — the heading every item has, and a vocabulary nobody could check

## Read this first: Slice 39 was green, and the number it predicted was finally tested

```
Test summary: total: 1124, failed: 0, succeeded: 1124, skipped: 0, duration: 147.5s
```

That number matters more than a green line usually does. **Slice 38 predicted 1124 and never reached a
count** — its migration threw at fixture initialisation, so the arithmetic went untested. Slice 39 re-predicted
1124 unchanged and shipped the F-78 repair. This run is the first time in three slices that a prediction
was compared against a run, and it matched exactly. The full local CI ran green as well: sixteen §16.3
scenarios in 147.6s, the boot smoke check, the restore drill, and a quick tunnel that served the
application over a public origin.

## The authoring environment has a database again, and it earned its keep in the first hour

Slice 39's "still open" ended on this, and it was the sharpest line in the file: *"No authoring-environment
database for a second consecutive slice… That is now a two-slice pattern rather than a one-off, and it is
the reason F-78 was found by a test run on your machine instead of by a migration in mine."*

PostgreSQL 16 was installed in the authoring environment before a line of `0005` was written, and **every
statement in this slice was executed rather than reasoned about**. What that bought, concretely:

- `0005` applied on an **empty** database (no seed section) and on a **populated** one (seed written, two
  items backfilled under it, `SET NOT NULL` and the foreign key applied, positions preserved). Both
  branches of the conditional seed were walked, which is the only way to walk them — a fresh container
  takes the first branch and can never take the second.
- `SELECT … FOR UPDATE` with a correlated `MAX + 1` subquery was run before it was written into
  `DapperMenuAdministration`. PostgreSQL rejects `FOR UPDATE` alongside aggregation in the *outer* query,
  and the shape that works is the one now in the file.
- The **three-event create** was executed as a transaction — `created`, `section_changed`,
  `description_changed` — and accepted.
- The new paired CHECK was **proven to bite**: an INSERT of a `created` event carrying a section is refused
  with `violates check constraint "menu_item_event_section_payload"`. That is the constraint doing its job
  under observation rather than a claim that it would.
- All five new `SchemaMigrationRunnerTests` probes were run against the live schema: `attnotnull` true, the
  named foreign key present, `menu_item_section_index` present, eight CHECK constraints on
  `menu_item_event`, and zero sections on a fresh database.

## F-80 — a vocabulary copied out of its own constraint, wrong for two migrations, with no symptom

`EventTypeCatalogue.MenuEventTypes` in `EventExplorerReads.cs` feeds §11.4's explorer dropdown. Its doc
comment said *"the five `menu_item_event.event_type` values"* and it listed five. `0004` added
`description_changed` and `reordered`. Neither the list nor the sentence was touched.

**Nothing broke, and that is the finding.** §11.4's explorer deliberately never *refuses* an unrecognised
type — `IsKnown` exists only to warn an administrator that a hand-edited `?type=` is not a word this build
catalogues, and the filter runs regardless, because a schema this build has not caught up with is exactly
the case where somebody most needs to see the rows. So a missing word has **no run-time symptom at all**.
It is two of the menu's verbs that cannot be chosen from the dropdown, on the page whose entire purpose is
choosing. Two slices, every gate green throughout.

**This is F-77 one register worse.** That row deleted a *count* of this same vocabulary, written in three
files and checkable in none. This is the vocabulary **itself**, copied into a second file, silently
drifting — in a file neither slice that widened the vocabulary had any reason to open.

**The repair is F-47's habit, and the three choices inside it are each deliberate.**
`MenuEventVocabularyContractTests` walks `Migrations/*.sql` in name order (which is DbUp's apply order),
takes the `event_type IN (…)` list from the last script declaring `menu_item_event_type_vocabulary`, and
compares the set against the C# list.

- **Not a count.** A count would have passed every version of this bug — which is precisely what F-77
  established about this exact vocabulary.
- **Non-vacuity is asserted.** A regex that matched the constraint and extracted no quoted words would
  otherwise pass against an empty list, which is F-41's failure mode.
- **SQL text, not a database.** `SchemaMigrationRunnerTests` owns "this constraint exists on a real
  PostgreSQL"; "the constraint and the C# list agree" is a different question and belongs in the fast suite,
  where a wrong answer is available in seconds.

Simulated against the real files before shipping: it identifies `0005` as the last declaration and derives
the same eight types the C# list now holds.

## `0005` needed no dollar-quoted block, and that is what `0004` bought

`0004` needed a `DO` block only because it had to query `pg_constraint` for names PostgreSQL had generated.
Since it replaced every one with a chosen name, the single CHECK that had to widen here was dropped **by
name** — two ordinary statements, nothing to query, nothing for dbup-core's variable substitution to
collide with. **F-78 was a one-migration problem rather than a recurring one because the previous slice paid
for the names.** The script says so in its header, so that a future migration does not reintroduce a block
it does not need.

## The seed carries two guards, and the plan specified one

`docs/MENU_AND_HANDHELD_PLAN.md` specified the seed as *one* section, *only if `menu_item` has rows*. That
is necessary and not sufficient. **"No surface calls `IMenuSectionAdministration`" is not the same claim as
"no row exists"** — Slice 37 shipped that write service and registered it, and a database where somebody
exercised it holds sections. Without a second guard the INSERT would trip `menu_section.name`'s `citext`
UNIQUE on any database holding a section called "Menu", and a migration that fails at startup takes the
whole application down.

So the seed is guarded by `EXISTS (SELECT 1 FROM menu_item) AND NOT EXISTS (SELECT 1 FROM menu_section)`,
and the backfill correspondingly targets the **first section in display order** rather than the seed's
literal identifier. Both paths converge: if the seed ran it *is* the first section; if it did not, the
orphans go under the earliest heading that already exists.

## Two decisions kept a mandatory column from reaching sixteen files

This is the transferable part of the slice, and it is worth stating as a rule rather than as two
implementation notes. **When a mandatory argument arrives late, give the arrangement helper a default rather
than threading the argument through every caller that does not care about it.**

- **`OrderTestWorld.AddMenuItemAsync` takes an optional section** and lazily creates a house heading named
  "Menu" when none is given, cleared by `TruncateAsync`. The dozen integration test files that put something
  on the menu — about ordering, settlement, the kitchen, visibility, none about headings — compile unchanged
  and mean exactly what they meant. The house section is created lazily rather than in `TruncateAsync`
  because several classes here count rows and should not carry one they did not ask for.
- **`AdministrationJourneys.CreateMenuItemAsync` arranges its own heading** through
  `EnsureMenuSectionAsync` before opening the form. **The sixteen existing §16.3 scenarios needed no edit at
  all.** `EnsureMenuSectionAsync` is idempotent by *looking first* rather than by submitting and swallowing
  a "name taken" failure — the latter would also pass on a form that reported the wrong error, and "taken"
  is a real outcome this project asserts elsewhere.

## Rulings inside `0005`, each of which could have gone the other way

**An item is appended at `MAX(display_order) + 1` within its section, reversing `0004`'s "created at
position 0".** The reason the rule could change is the reason it existed: "the end of the menu" was not a
defined place while an item had no heading, and it is defined now. `MAX + 1` rather than `COUNT(*)`, on the
rule `menu_section` has followed since `0003` — a count collides with an existing position as soon as
anything has been moved, and `AppendingUsesTheHighestPositionRatherThanTheCount` is the assertion.

**The lock is on the section row, not the item.** Locking the section is what serialises two administrators
creating an item under the same heading at the same moment: without it both read the same `MAX`, both write
the same position, and the menu has two dishes claiming one place — which the schema *permits*, positions
being deliberately non-unique, and which is therefore a defect nothing would ever report. It doubles as the
existence check, which is why a missing heading is a reported `MenuSectionNotFound` rather than PostgreSQL
error 23503 naming a constraint.

**`created` still carries the name and the price alone**, so an item created under a heading writes two
events and one with a description writes three. Widening it would relax an equality to an implication and
break every `created` row already written. **The position writes no event ever**, because
`new_display_order` is bound to `reordered` and a `created` row carrying a position would be false of every
row written before `0005`.

**One index, and it is not the one `0004` declined.** PostgreSQL does not index the referencing side of a
foreign key, so without `menu_item_section_index` every statement touching a `menu_section` row scans
`menu_item`. Its trailing columns are the tail of §11.1's `ORDER BY`, so one index answers both.

## §7's asymmetry, implemented, and it points two ways one sentence apart

An inactive **item** stays on the guest's menu, marked, unorderable. An inactive **section** is not rendered
to the guest at all. That is not a contradiction: switching off a heading is a decision about a whole part
of the menu ("no breakfast this evening"), where 86ing a dish is a decision about one thing a guest is still
entitled to know exists. Neither flag cascades to the other.

**Both are carried unfiltered by `IMenuDirectory` and the filtering is on the surface.** §11.4's
administrator must see every heading including the ones no guest can reach — that is precisely the row
somebody is looking for when they wonder why an available dish is not on the menu — so
`/administration/menu` and `ManageMenuItem` both carry a *Section hidden* chip.

## Two scope rulings, flagged for veto

**`MoveMenuItemToSectionAsync` is not in this slice.** The plan schedules it with Stage 2's data access. The
item editor that would call it is Stage 3, and this project's own rule — a verb with no caller is a code path
no test can reach through the interface meant to protect it — applies to it exactly as it applied to the
section verbs for three slices. **To reverse:** the verb is a `section_changed` event and an `UPDATE`
alongside `ReorderMenuItemAsync`, plus a picker on `ManageMenuItem.razor`; nothing in this slice blocks it.

**Only `CreateMenuSectionAsync` moved behind `IMenuWorkflow`.** The obligation carried four times **narrows
to four verbs rather than closing**. The create page is a caller, so that verb arrives and publishes
`MenuChanged` on a committed row; rename, describe, reorder and set-active have no surface. What changed is
the *cost* of leaving them: §11.1's guest menu groups by heading now, so a renamed section that announced
nothing would leave a stale heading in every open picker. That defect is real and merely **unreachable**.
`MenuWiringTests`' fake throws from all four with a message naming the obligation, so the next person to
wire one is told rather than left to notice.

## One assertion was cut from scenario 17, and the cut is recorded rather than quietly made

The scenario was drafted to deactivate a heading and watch it vanish from the guest's menu — §7's asymmetry,
and the one thing about it no unit test can see. That needs `SetMenuSectionActiveAsync` to have a surface,
which is the section editor this slice deliberately did not ship. Asserting it would have meant either a
harness reaching past the UI, which §16.3 refuses, or a verb wired for a test, which is worse.

It was replaced with an assertion this slice can actually make: a third item created under an existing
heading joins it rather than starting a new grouping, and lands at the end of it — `MAX + 1`-within-section
proven through a browser. The inactive-section rule is covered at the data layer by
`MenuDirectoryTests.AnInactiveSection_IsCarriedRatherThanFiltered` and is **unverified end to end**.

## What is in this slice

| Area | Change |
|---|---|
| Migration | `0005_menu_item_sections.sql` — **new**. Conditional two-guard seed, nullable column, backfill, `SET NOT NULL`, named foreign key, vocabulary widened by name, `new_menu_section_identifier` with its paired CHECK, one index |
| Data access | `MenuDirectory.cs` — three section members, INNER join, six-key ordering; `MenuAdministration.cs` — section on create, `MAX + 1` under a section lock, `CreateMenuItemOutcome`, widened result; `MenuEventLog.cs` — section payload and an aliased LEFT join |
| Web | `MenuWorkflow.cs` — `CreateMenuSectionAsync`, section on the item create, that publish made conditional; `OrdersServiceCollectionExtensions.cs` — the registration note rewritten |
| Surfaces | `CreateMenuSection.razor` — **new**; `CreateMenuItem.razor` — picker and first-use panel; `AdministrationMenu.razor` — Section column, Create section, `section_changed` arm; `ManageMenuItem.razor` — the heading and its arm; `TableOrderSurface.razor` — §11.1 grouped under headings |
| Stylesheet | `app.css` — `.order-menu-section` and its heading. No new breakpoint, no colour literal, no `var()` fallback |
| Explorer | `EventExplorerReads.cs` — the menu vocabulary corrected from five to eight (F-80) |
| Harness | `AdministrationJourneys.cs` — `CreateMenuSectionAsync`, `EnsureMenuSectionAsync`, `FindMenuSectionAsync`, a section on item creation; `TableOrderJourneys.cs` — `MenuCard.SectionName`, section-walking read, `ReadMenuSectionNamesAsync` |
| Tests | `MenuEventVocabularyContractTests.cs` — **new**, two facts; `MenuDirectoryTests` +2; `MenuAdministrationTests` +3; `SchemaMigrationRunnerTests` +2; `MenuWiringTests` +2; `MenuEventLogTests` counts corrected; `EndToEndScenarios.cs` — scenario 17; `OrderTestWorld.cs` — `AddMenuSectionAsync` and the optional section |
| Documents | S v1.25 (§7, §8.1, §8.2, §16.3, §16.4, Appendix A, changelog), ledger F-80, plan Stage 2 closed and Stage 3 partly struck, `_CHANGES.md` |

## What was verified

**Everything SQL, against a live PostgreSQL 16.** Listed in full at the top of this entry rather than
summarised here, because it is the difference between this slice and the two before it.

**The working tree was reconstructed from `dump.txt` and checked against the SHA-256 recorded for every
file: 341 of 341 byte-identical.** The only file the dump does not reproduce is `export.sh`, which
documents itself inside its own output. Every edit below was made against a verified tree.

**Three gates were simulated rather than assumed.** `MarkdownTableContractTests` was run in substance over
every Markdown file in the repository — fence-aware, escaped-pipe-aware — and reports **zero** mismatches,
including the two new four-cell rows. `SpecificationVersionTests`: header 1.25, newest entry 1.25, entries
descending. `MenuEventVocabularyContractTests`: derives eight types from `0005` and matches the C# list.

**Brace, paren and bracket balance** on every C# file touched, checked after each edit rather than at the
end. **Every `InsertEventAsync` call site** was enumerated after the signature change and each of the seven
confirmed to carry the new argument — by search, not by having written them.

**The contiguity assertion in `MenuDirectoryTests` was proven sensitive.** A grouped list of four returns 2
runs; a scattered list with the same set of names returns 4. An assertion that could not tell those apart
would be the whole fact rendered vacuous.

**Selector existence in both directions** for the new markup: `.order-menu-section` and
`.order-menu-section-name` exist in `app.css` and are read by both the surface and the harness;
`--hairline` and `--ink-soft` are declared in `:root`.

## What was NOT verified

**Nothing compiled.** No .NET SDK in the authoring environment. The likeliest sites of a complaint are named
rather than left to be found: **`InputSelect` bound to a `Guid`** on the item form, which this tree does
elsewhere for enums but not for `Guid`; **`_created is { Created: true } created`**, a property pattern with
a designation, on two Razor pages; and **`Assert.Single(menu, card => card.Name == …)`**, whose predicate
overload returns the element in xUnit v3 and returned `void` in some v2 lines.

**No test ran.** The SQL is executed and the C# is not. Every count below is arithmetic.

**No browser rendered the grouped menu.** Named consequences a first run may show: whether an uppercase
letter-spaced heading at 0.78rem is legible enough on a 375px handset; whether two headings with one item
each read as grouping or as clutter; and whether `aria-labelledby` on a per-section `<ul>` announces
sensibly when the same page has several, which only a screen reader decides.

**The `0005` backfill branch was walked by hand and cannot be walked by a test here.** A fresh container
takes the no-seed branch, which `Run_SeedsNoSectionOnAFreshDatabase` asserts. The populated branch is
recorded in this entry as manually exercised, and it is the branch that runs on your actual database.

**§7's inactive-section rendering rule is unverified end to end**, for the reason above.

## Test count

Last observed: **1124**, from Slice 39 — and, for the first time in three slices, a prediction that matched
its run.

Predicted here: **1136**. The arithmetic: `MenuEventVocabularyContractTests` +2, `MenuDirectoryTests` +2,
`MenuAdministrationTests` +3, `SchemaMigrationRunnerTests` +2, `MenuWiringTests` +2, §16.3 scenario 17 +1.
No fact was removed; several had their assertions corrected in place. §16.3 goes from **16** to **17**.

Per §18: if the run returns anything other than 1136, that difference is the next thing to chase.

## Still open

**The section editor, and it is now the highest-value thing outstanding.** A heading created with a typo can
only be worked around by creating another. It carries four workflow verbs, `MoveMenuItemToSectionAsync`, the
sections-first index, and the end-to-end assertion cut from scenario 17.

**A section's own description under its heading on the guest menu.** The surface groups from
`MenuItemSummary`, which carries the heading's name and not its description; showing it needs either a
second read or a widened record, and guessing between those was not this slice's business.

**The kitchen's "86" panel still groups by nothing.** Stage 3's remaining surface, and the last one.

**§16.3 scenario 17 does not deactivate a section.** Named above; lands with the editor.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Fifth slice carried. Still a decision rather than a repair.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a seventh time.

**A CI job that runs the canonical stack on the canonical engine.** Sixteenth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**The handheld barrier does not visit `/administration/menu/sections/new`.** Scenario 16 walks ten surfaces
and this slice added an eleventh administration page. It is a create form rather than a record list, so
none of the barrier's three reach selectors matches it and the control count would not move — which is
exactly why it would be easy to leave out permanently. Recorded so it is not.

# M6 Slice 41 — the section editor, a reserved word two files were named after (F-81), and the gate that never ran (F-82)

**Closes the deferred obligation this project has been counting down since `0003`.** All five of
`IMenuSectionAdministration`'s verbs now have a surface and all five are behind `IMenuWorkflow`. A heading
can be renamed, described, moved and switched off, and each of those announces `MenuChanged` on a committed
row and nothing on a write that committed nothing.

**And it unblocks the four things that were waiting on it**: `IMenuSectionEventLog`, without which §11.4's
"complete stored record" had nothing to read for a section; the menu index's Section column, which was a
column linking nowhere; the harness journey that had to recover a new section's identifier from a
neighbouring form; and §16.3 scenario 17's two cut steps.

## The two findings, and the order they were found in

**F-81 — two loop variables named after a Razor directive.** Slice 40 wrote
`@section.MenuSectionIdentifier` on the create-item form and `@section.MenuSectionName` on the guest
ordering surface. `@section` is MVC's **section directive**, reserved in Razor's own grammar, so the parser
read a directive with a malformed name and produced four errors across two files — `RZ9979`, `RZ2005`,
`RZ1011` — none of which mentions an identifier and none of which is about the markup. `RZ1011`'s column
lands on the `.` immediately after the seven characters of `section`, which is the only thing in the four
messages that points at the actual cause.

Two properties of it are worth keeping.

**It is invisible in review.** `@key="section.MenuSectionIdentifier"` one line above and
`@SectionHeadingId(section)` one line below compile perfectly, because neither puts the word directly after
an `@`. So the errors read as complaints about the `<option>` and the `<h4>`, and the identifier — which is
the whole cause — appears in none of them.

**It is blocking everywhere.** `MyRestaurant.WebApplication` is the project every other one references. The
unit suite, the integration suite and all seventeen §16.3 scenarios were unreachable together.

**F-82 — the gate against stale counts had gone stale, and said nothing, because it never ran.**
`TestingSectionContractTests` compares every assertion count §16.4 states against the file it names. It was
written after F-70, where exactly that drift concealed an undocumented gate for four slices. Slice 40 added
assertions to four classes §16.4 cites and moved none of the four numbers:

```
MenuAdministrationTests      §16.4 said 23   file holds 26
MenuDirectoryTests           §16.4 said  5   file holds  7
MenuWiringTests              §16.4 said 11   file holds 13
SchemaMigrationRunnerTests   §16.4 said  5   file holds  7
```

Slice 40's own delivery note predicted every one of those increments **by name**. The arithmetic was done,
written down, and never carried into the document.

**This is F-71 read from the other side.** That finding was a test project failing to compile behind a
summary line reading `total: 497, failed: 0`. This is a gate that never started, behind a build error
everybody was already looking at. The shared lesson: **a gate that cannot run is indistinguishable from a
gate that passed**, and nothing in this repository distinguishes them — `dotnet build` reports what failed
to compile and no artefact reports what consequently failed to *execute*.

No gate is added for F-82, deliberately. The gate that would have caught it is the gate that did not run,
and the repair for *that* is F-81's. What is added is the pairing, stated in §16.4 and in the class's own
summary: the first question about a red build is *what stopped being checked*, not only *what stopped
compiling*.

## What this slice does

- **`ManageMenuSection.razor`** at `/administration/menu/sections/{id}` — static SSR, four forms,
  post/redirect/get with a one-word outcome, a facts grid, the heading's items, and its complete uncapped
  event history. Declares no CSS: every class it uses is app.css's §11.12 vocabulary, checked in both
  directions.
- **`IMenuSectionEventLog` / `DapperMenuSectionEventLog`** — the per-heading history read.
- **Four verbs behind `IMenuWorkflow`**, each publishing `MenuChanged` only on a committed row.
- **Links into the editor** from the create panel, the menu index's Section column, and each item's page.
- **F-81's rule made executable** — `RazorDirectiveContractTests`, two facts.
- **F-82's four counts corrected**, and `MinimumCountedClasses` moved from sixteen to eighteen.
- **Scenario 17 regains its two cut steps**, and comes back larger than it was cut.

## Three rulings

**`IMenuSectionEventLog` is a second reader, not a widened `IMenuEventLog`.** Two tables, two vocabularies,
and the two share three type words while meaning different things by all three — a `renamed` section is not
a `name_changed` item, and neither log's payload columns exist on the other. A `UNION ALL` over both is a
real read §11.4's explorer may want one day; it is not this, and building one here would make the
per-section history pay for a merge it never uses.

**No cross-section activity feed.** `IMenuEventLog.ListRecentAsync` exists to fill a panel on
`/administration/menu`, which is an index over items. Sections have no such panel, and a read with no caller
is the same defect as a workflow verb with no caller — which is the rule this slice spent four verbs
discharging, so inventing a fifth instance of it in the same archive would be absurd.

**The editor reads the whole menu and filters in memory** rather than adding a per-section query with one
caller. `IMenuDirectory.ListAsync` already orders by section first and makes each heading's items
contiguous, so the filter preserves the order guests see without re-deciding it in a second file (§7). It is
a read that grows with the menu, on a database whose whole reason for existing is one restaurant. **Flagged
for veto**: the reversal is one method on `IMenuDirectory` and one call site.

## The four verbs' broadcasts, and why two of them are not optional

**A rename** is the one that had stopped being latent. §11.1 renders a heading above every card under it, so
a rename that committed and announced nothing leaves the old word on every open picker until that page
happens to reload.

**A visibility flip** is worse. §7 hides an inactive section from the guest *entirely* — the opposite of the
rule one paragraph away for an inactive item — so switching a heading off without a broadcast leaves a whole
part of the menu tappable on every phone already looking at it, until the send is refused server-side for a
reason the guest never saw coming (§6.5.9).

**A description** publishes and reaches no guest surface today, and that is the same ruling the item
description already carries: `MenuChanged` means *re-read the menu* and nothing else, and a workflow that
decided which columns were worth announcing must be edited again the moment a surface starts reading one.

**A move** publishes because §11.1 orders headings by `(display_order, name, identifier)`, so the whole menu
is in a different order even though no item moved.

## Scenario 17 came back larger than it was cut

Slice 40 drafted a deactivation assertion, cut it, and recorded the cut. The restored version does not only
watch the heading vanish. It asserts that the *other* heading's items stay present, in order, and orderable;
then switches the heading back on and checks the menu returns exactly as it was.

That second half is the only end-to-end proof that deactivating a section **does not cascade** to its items.
A cascade would come back with the pie marked unavailable. It was not in the draft — it became obvious once
the assertion was being written against a surface that existed, and it would not have been written at all if
the cut had been made silently.

## What was verified

**The working tree was reconstructed from `dump.txt` and checked against the SHA-256 recorded for every
file: 344 of 344 byte-identical.** Two files needed repair in the *reader* rather than the tree —
`export.sh` contains its own `# FILE:` banner as literal text, and the last file in the dump abuts the
`DUMP SUMMARY` footer — and both were confirmed against their recorded hashes after repair.

**`RazorDirectiveContractTests` was run in substance** over all 51 components: zero uses, and the
non-vacuity guard's floor of twenty is met four times over. Its five sensitivity cases were run and all five
behave as the second fact asserts.

**`TestingSectionContractTests` was run in substance**, before and after. Before: 16 counted classes, **4
disagreements** — which is F-82, found by simulation rather than by reading. After: 18 counted classes, 0
disagreements, 0 ambiguous, 0 uncited.

**`MarkdownTableContractTests`** over every Markdown file in the repository, fence-aware and
escaped-pipe-aware: 60 table runs, zero findings, including the three new four-cell Appendix A rows and the
two new ledger rows.

**`SpecificationVersionTests`**: header 1.26, newest changelog entry 1.26, 27 entries descending.

**`MenuEventVocabularyContractTests`**: eight types derived from `0005`, set-equal to the C# list. Unchanged
by this slice and re-run because the slice touches the menu.

**`HandheldLayoutContractTests`' data-label parity** across all 8 record-list components — up from 7,
because `ManageMenuSection` adds two lists — every one with cells equal to labels. Its palette fact was run
against the new page: zero `var()` references to undeclared properties, zero inline `<style>`, and every one
of the classes it names exists as a selector in `app.css`.

**Brace, paren and bracket balance** on all nine changed C# files, string- and comment-aware.

**The balance checker was itself proven, and it failed the proof first.** Its first run reported an
imbalance in the new `MenuSectionEventLog.cs`. Running it against two *untouched* sibling files —
`MenuEventLog.cs` and `MenuSectionDirectory.cs`, both byte-verified against the dump — produced the
identical report, which is what identified the checker rather than the file: it read `$"""` as an empty
interpolated string and parsed the SQL body as code. Fixed, re-run, all nine balanced. **A verification tool
that has not been run against a known-good input is a verification tool with no established false-positive
rate**, and this is the second slice in which that mattered.

**Byte hygiene** on every changed and new file: no CR, exactly one final newline, no whitespace-only line,
no context-dump separator.

## What was NOT verified

**Nothing compiled.** No .NET SDK in the authoring environment. The likeliest sites of a complaint are named
rather than left to be found: **`Assert.Single(restored, card => card.Name == pie.Name)`**, whose predicate
overload returns the element in xUnit v3; **`Assert.Equal(string.Empty, described.NewDescription)`** on a
`string?`, which is an equality rather than a null-flow narrowing precisely so it does not depend on how
xUnit annotates `Assert.NotNull`; and **the `foreach` over a `bool[]` inside a `[Fact]`** in
`ASectionVisibilityFlip_…`, which asserts twice in one loop and will report the first failure only.

**No test ran.** Every count below is arithmetic.

**No browser rendered the section editor.** Named consequences a first run may show: whether four forms plus
two record lists on one page reads as an editor or as a wall at 375px; whether *Hide from guests* as a
`link-button danger` is the right weight for an action that is fully reversible; and whether the two record
lists on one page need distinguishing headings for a screen reader, which only a screen reader decides.

**The `.manage-facts .chip` selector the new harness journey waits on is unexercised.** It is the first
harness read in this project that keys on a chip inside the facts grid rather than on a flash or a heading.
If scenario 17 times out at step (g), that selector is the first thing to check and the failure will name
it.

**§16.3 scenario 17 is longer than any scenario in the suite** and now spans two §9 broadcasts on an
already-open circuit. If it becomes flaky, the deactivation wait is the more likely half — it waits for an
*absence*, which `WaitForMenuAsync` expresses as a predicate over the whole menu.

**Nothing verified that F-82's four counts were the only stale ones.** The simulation compares what §16.4
states to what the files hold, which is exactly the gate's own reach; a class §16.4 never cites is invisible
to both, and that residual is stated in §16.4 rather than closed.

## Test count

Last predicted: **1136**, from Slice 40 — and **not observed**, because the build failed. The last observed
count is **1124**, from Slice 39.

**That gap is itself the finding.** §18's habit is that a predicted count the run contradicts is chased
before the slice closes; a predicted count that never meets a run cannot be chased at all, and F-82 is what
was sitting in it.

Predicted here: **1149**. The arithmetic, from 1136: `RazorDirectiveContractTests` +2,
`MenuSectionEventLogTests` +6, `MenuWiringTests` +5. Scenario 17 gains assertions and no new `[Fact]`, so
§16.3 stays at **17**. No fact is removed.

Per §18: if the run returns anything other than 1149, that difference is the next thing to chase — and this
slice is the first opportunity since Slice 39 to perform that check at all.

## Still open

**The sections-first index.** `/administration/menu` is still an item list with a Section column. The column
links now, which was the blocker; what remains is the restructure.

**`MoveMenuItemToSectionAsync`.** The last verb in the whole enhancement with no surface — `ManageMenuItem`
shows the heading, links to it, and cannot change it. It is now the only instance left of the rule this
slice spent four verbs discharging.

**A section's own description under its heading on the guest menu.** Unchanged from Slice 40: the surface
groups from `MenuItemSummary`, which carries the heading's name and not its description.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**The handheld barrier visits neither section surface.** Scenario 16 walks ten and this slice adds a twelfth
administration page. `ManageMenuSection` is a detail surface with `.manage-inline-form` buttons, so unlike
the create page it *would* move the control count — which makes leaving it out a real gap rather than a
neutral one. Carried, and now larger than when Slice 40 recorded it.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, stated rather than
resolved.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Sixth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred an eighth time.

**A CI job that runs the canonical stack on the canonical engine.** Seventeenth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

# M6 Slice 42 — seven defects behind one build failure, and a ruling reversed

**Nothing new ships.** This slice adds no surface, no verb, no migration and no gate. It makes the tree
build and the suite pass, and it writes down what was in the way — which turned out to be seven findings
rather than the two the build errors named.

## Read this first: the shape almost all of it shares

Six of the seven are the same mechanism, and naming it is worth more than any individual repair:

> **A schema widened by a migration reaches the test arrangement last**, because arrangement is the code
> nobody is looking at while implementing the thing being arranged for.

`0004` and `0005` between them added three columns to `menu_item`, three payload columns to
`menu_item_event`, three members to `MenuItemSummary`, and three types to the event vocabulary. Every one
of those landed correctly in `src/`. What did not land was: the INSERT the test world writes events with
(F-86), a positional stand-in in the unit suite (F-84), six assertions counting a create (F-87), and a
harness read that had never been about the schema at all (F-88). F-85 is the same slot — test arrangement
— reached from a different direction.

The seventh, F-83, is not that shape and is the one worth reading.

## F-83 — the repair for F-80 named a class that has never existed

`MenuEventVocabularyContractTests` referred to `EventTypeVocabulary` at four call sites and three `cref`s.
**There is no such type.** It is `EventTypeCatalogue`, declared in `EventExplorerReads.cs`, called by
`EventExplorerQuery.cs` and `EventExplorer.razor`, and spelled correctly in `BUILD_PROGRESS.md`'s own M5
file census.

Five occurrences spelled it wrongly, across three documents:

```
docs/TECHNICAL_SPECIFICATION.md   F-80's Appendix A row      x2
docs/DOCUMENTATION_REVIEW.md      F-80's ledger row          x2
docs/BUILD_PROGRESS.md            Slice 40's own narrative   x1
```

All five were written in the slice that wrote the test. **That is how an identifier gets copied wrong five
times without a reader noticing: the correct spelling and the incorrect spelling were never in one view.**
The test was written from the ledger rather than from the file the ledger describes.

**The consequence is the part to sit with.** `MyRestaurant.WebApplication.Tests` did not compile, so
F-80's repair did not run, so for a full slice the menu vocabulary was *correct in the source* and
*guarded by nothing* — precisely the state F-80 exists to prevent, arrived at through the fix for it.

**No gate is added**, on F-71's ruling in its second application: the compiler is the gate and it blocked.
A gate asserting that documentation names types the tree declares would be a gate about typography, and it
would not have found this any earlier than CSC did.

What is recorded instead is a pattern now on its third consecutive instance. **F-71, F-82, F-83**: three
build failures whose real cost was not the error everybody was reading but the gates downstream of it
reporting nothing.

## F-87 — six assertions, and the two that were reading the wrong row

`0005` makes a heading mandatory and always logged, so a create writes `created` then `section_changed` in
one transaction at one instant, and a create with a description writes a third row. Slice 40 moved five
counts in `MenuAdministrationTests` and left six behind.

Four were plain totals a row short:

```
DescribeWritesTheColumnAndItsEventTogether           2 -> 3
ClearingADescriptionIsAChangeAndStoresTheEmptyString 3 -> 4
ReorderWritesThePositionAndItsEvent...               2 -> 3   (both assertions)
ANegativePositionIsRefusedBeforeAnythingIsWritten    1 -> 2
```

**The other two are the failure worth reading.** They took a payload through the file's newest-event
helper, and after `0005` the newest event of a create is the section one — whose every payload column is
null by CHECK. So:

```
CreateTrimsTheName                     expected "Soup"  actual null
CreateRoundsToTheStoredScaleInBothRows expected 4.57    actual 0
```

Two value mismatches, in the one class whose entire subject is those two values, with nothing in either
message naming the event that had displaced them. A reader chasing that failure starts by suspecting
trimming and rounding — the two things the tests are named after — and neither is wrong.

**The evidence that the shape was understood and simply not carried across:**
`CreateWritesTheItemAndItsCreatedEventTogether`, in the same file, already reads its `created` payload by
explicit `event_type = 'created'`, under a comment saying the newest event is now the section one and that
this fact *"used to be reachable through EventTypeAsync and no longer is"*. The knowledge was in the file,
twenty lines up, in prose.

The repair hoists that query into `CreatedEventScalarAsync`. It carries no `ORDER BY`: a create writes
exactly one `created` row, and an ordering there would imply there might be two.

## F-86 — five of eight types were writable, and the constraint said so in constraint language

`OrderTestWorld.AddMenuItemEventAsync` listed `new_name` and `new_price_amount`. `menu_item_event` has five
payload columns, each tied to its type by a **named biconditional** — an equality, not a permission, so
`description_changed` without a description is refused by the same constraint that would refuse
`activated` *with* one.

So three of the eight admitted types were unwritable through the only helper the suite arranges menu
events with, and the failure surfaced as `menu_item_event_description_payload` two frames below the method
that caused it.

The three new payloads are **optional trailing parameters**, which keeps the five existing call sites
unchanged and expresses the biconditional in C#: a caller that says nothing about a description is a caller
writing a type that must not carry one.

## F-88 — a harness comparing a stylesheet's output against a name

`ReadMenuAsync` read each guest-menu heading with `InnerTextAsync`, which returns text **as rendered**, and
`app.css` declares `text-transform: uppercase` on `.order-menu-section-name`. Scenario 17 created a heading
called *Starters* through the real form and read back `STARTERS`.

**Both alternative repairs are wrong, which is why this has a number.** Asserting the uppercase string puts
a presentation rule inside a scenario about menu structure, so a designer removing the transform breaks a
test that is not about them. Comparing case-insensitively silently accepts a surface that had started
lower-casing headings. Only `TextContentAsync` distinguishes *the name* from *how the name is drawn*.

The audit is recorded rather than the conclusion asserted: `app.css` carries twelve `text-transform`
declarations, and this is the only one whose element the suite compares against a value. The four `dt`
terms under `.order-menu-facts` are read into a dictionary nothing asserts on.

## F-89 — a ruling reversed, and the evidence that reversed it

F-73 found a census count in prose that was stale on arrival, and ruled that it should be **kept** —
because it was the argument for `MinimumCountedClasses` — with the habit of moving it added beside it.

The habit was then tried for three slices:

```
                              floor   summary   S16.4
after F-73  (Slice 36)         ten      ten      ten
after 0004  (Slice 39)      sixteen      ten      ten
after editor (Slice 41)    eighteen  sixteen      ten
```

The floor moved both times. The summary moved once, late, and landed on a number its own next clause
contradicted eleven words later. §16.4 never moved at all and was stale by eight.

Neither prose copy is reachable by any gate: `TestingSectionContractTests` compares assertion counts *per
class* against files, and the census is a count of *paragraphs*, which nothing reads. **This is F-73
recurring inside the repair for F-73**, and the recurrence is the evidence — a habit tried for three slices
that did not hold is not a habit.

**So the ruling is reversed rather than restated.** F-77's habit wins: both prose copies are **deleted**,
leaving the floor as the only place the census is written. That copy is safe in the way the others were not
— it is asserted on every run, so it can go stale only *loudly*, which is the property F-73 was reaching
for and located in the wrong copy.

The floor moves eighteen -> **nineteen**, `MenuEventVocabularyContractTests` having become countable by
gaining a §16.4 paragraph of its own in this slice.

## F-84 and F-85, briefly, because they are what they look like

**F-84.** `MenuItemSummary` went seven members -> ten in `0005`; `OrderStagingTests.Item()` stayed at
seven. CS7036 named `DisplayOrder`, which is not the member that moved — a positional call binds left to
right, so inserting members re-points every later argument and the compiler reports the last parameter it
could not satisfy. **The defect is the good failure and the positional form is kept for that reason:** an
object initialiser would have compiled and left the file describing an item filed under no heading, which
is the one thing `0005` rules out.

**F-85.** `MenuSectionEventLogTests` asked for the username `"mo"` against
`CHECK (char_length(username) BETWEEN 3 AND 64)`. The insert is in `InitializeAsync`, so all six of that
class's facts went red before any assertion ran. `EventExplorerReadsTests` states that minimum in a comment
above its own four people; this is the sibling that did not. F-46's shape at the smallest scale this ledger
has recorded it.

## Two comments under `src/` that asserted the opposite of the code beneath them

Not findings — no behaviour, no gate, caught while reading. `ManageMenuItem.razor` and
`AdministrationMenu.razor` each carried a sentence saying `0005`'s `section_changed` *"will read as itself
until this arm is written"*, and in both files the arm is written twenty lines below. Slice 40 added the
arms and left the sentences. Corrected in the same pass, because a comment that describes the absence of
the code beside it is worse than no comment.

## What is in this slice

- **`MenuEventVocabularyContractTests.cs`** — `EventTypeCatalogue` at all seven references (F-83).
- **`OrderStagingTests.cs`** — ten-argument `MenuItemSummary` (F-84).
- **`MenuSectionEventLogTests.cs`** — a three-character username, and the rule beside the field (F-85).
- **`OrderTestWorld.cs`** — all five payload columns, three as optional parameters (F-86).
- **`EventExplorerReadsTests.cs`** — each type's bound payload, and a real section row for the FK (F-86).
- **`MenuAdministrationTests.cs`** — four counts, two payload reads, one new helper (F-87).
- **`TableOrderJourneys.cs`** — `TextContentAsync` on the heading (F-88).
- **`TestingSectionContractTests.cs`** — floor to nineteen, prose census deleted (F-89).
- **`ManageMenuItem.razor`, `AdministrationMenu.razor`** — two stale comments.
- **Documentation**: spec to v1.27, §16.4 gains three paragraphs and corrects one, Appendix A and
  `DOCUMENTATION_REVIEW.md` gain F-83 through F-89, the plan records what this unblocks.

## What was verified

**The working tree was reconstructed from `dump.txt` and checked against the SHA-256 recorded for every
file: 347 of 348 byte-identical.** The exception is `export.sh`, which contains the dump's own `# FILE:`
banner as literal text and therefore cannot be round-tripped by any parser that uses that banner as a
delimiter. It is excluded from this slice's work set rather than reconstructed and guessed at, and is not
delivered.

**`TestingSectionContractTests` was run in substance**, ported, before and after. Before: 18 counted
classes, 0 disagreements — the tree as delivered was correct on this gate, which is F-82's repair holding.
After: **19 counted classes, 0 disagreements, 0 ambiguous, 0 uncited**, floor met exactly. The nineteenth
is `MenuEventVocabularyContractTests`, which gains a §16.4 paragraph in this slice and is therefore
countable for the first time.

**`MarkdownTableContractTests` was run in substance** over every Markdown file in the repository,
fence-aware and escaped-pipe-aware: **60 table runs, zero findings**, including the fourteen new four-cell
rows across the two registers.

**`SpecificationVersionTests` was run in substance**: header 1.27, newest changelog entry 1.27, 28 entries
descending; `REQUIREMENTS.md` header 6 against newest entry 6; two documents qualify, which is its floor.

**Every `[Fact]` and `[Theory]` count §16.4 states was recomputed against its file.** `MenuAdministrationTests`
stays at **26** — this slice changes what six assertions expect and adds no test method, which is why no
count in §16.4 moves for it.

**The vocabulary gate's own extraction was re-run by hand** against `0005`: the regex matches
`ADD CONSTRAINT menu_item_event_type_vocabulary CHECK (event_type IN` across its newline, yields eight
quoted words, and those eight are set-equal to `EventTypeCatalogue.MenuEventTypes`. So the gate passes
*once it compiles*, which had never been established.

**Brace, paren and bracket balance** on all eight changed C# files, string- and comment-aware — and the
checker was proven against four **untouched, SHA-verified** siblings first, which is the habit Slice 41
paid for. All twelve clean.

**Razor tag-tree comparison** of the two changed components against their SHA-verified originals: markup
identical, 189 and 128 tags. **The checker failed its own proof first, and the failure is instructive.**
Its first run reported `ManageMenuItem.razor` losing four tags — and the four were `<c>` and `<para>`,
which are XML *doc-comment* elements rather than markup, deleted along with the stale sentence. A tag
scanner that does not strip `///` lines is comparing prose. Corrected, re-run, both identical. Independent
corroboration that nothing under `src/` moved: of 3 changed lines in one file and 7 in the other, the
number that are not `///` doc lines is **zero in both**.

**Byte hygiene** on every changed file: no CR, exactly one final newline, no whitespace-only line, no
context-dump separator.

## What was NOT verified

**Nothing compiled.** No .NET SDK in the authoring environment. Named rather than left to be found: the new
optional parameters on `AddMenuItemEventAsync` sit **after** a `CancellationToken`, which is legal and
which no other method in `OrderTestWorld` does — every existing call site passes the token positionally and
stops, so they bind correctly, but a future caller using named arguments will find the ordering unusual.
`CreatedEventScalarAsync` mirrors `ScalarAsync` exactly and uses the same `$"""` raw interpolated form,
which is the construct the balance checker mis-parsed two slices ago.

**No test ran.** Every count below is arithmetic.

**No database confirmed the six repaired assertions.** Each is a claim about how many rows `0005`'s create
writes, derived by reading `DapperMenuAdministration.CreateMenuItemAsync` — which writes `created`
unconditionally, `section_changed` unconditionally, and `description_changed` when the normalized
description is non-empty. The reading is corroborated by two facts in the same file that Slice 40 *did*
update and that consequently passed: `CreateWritesTheItemAndItsCreatedEventTogether` asserts 2, and
`TheHistoryKeepsEveryChangeFromBothWriteServices` asserts 5 for a create plus three later verbs. Both are
only consistent with a two-row create.

**No browser re-ran scenario 17.** `TextContentAsync` returns `string?` where `InnerTextAsync` returns
`string`; the null-coalesce is present, and whether Playwright ever returns null for a matched element with
text content is not something this environment can establish.

**Nothing verified that the five wrong spellings of `EventTypeCatalogue` were the only ones.** A repository
grep found five and they are repaired; a type name that appears in prose in a document nothing parses is
reachable by no gate here, which is F-83's residual and is stated rather than closed.

## Test count

Last predicted: **1149**, from Slice 41 — and **not observed**, because the build failed again. The last
observed count is **1124**, from Slice 39, which is now three slices back.

**Two slices in a row have now predicted a count that never met a run**, which is the F-82 residual
becoming a measurement rather than an argument.

Predicted here: **1149**, unchanged. This slice adds no `[Fact]` and removes none — every repair changes
what an existing assertion expects, or how it reads what it expects. §16.3 stays at **17**.

Per §18: if the run returns anything other than 1149, that difference is the next thing to chase. This is
the third consecutive slice in which that check has been scheduled and the first in which it is expected to
be possible.

## Still open

**`MoveMenuItemToSectionAsync`.** The last verb in the whole enhancement with no surface. Unchanged from
Slice 41, and now unblocked in a way it was not: the helper that would arrange its events could not write
`section_changed` at all until this slice (F-86).

**The sections-first index.** `/administration/menu` is still an item list with a Section column.

**A section's own description under its heading on the guest menu.** Unchanged.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**The handheld barrier visits neither section surface.** Scenario 16 walks ten; `ManageMenuSection` is a
detail surface with `.manage-inline-form` buttons and would move the control count. Carried from Slice 41.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, now with a third
instance behind it (F-83).

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Seventh slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a ninth time.

**A CI job that runs the canonical stack on the canonical engine.** Eighteenth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

# M6 Slice 43 — the last verb gets its surface, and three numbers nothing could check

**`MoveMenuItemToSectionAsync` lands with the picker on `ManageMenuItem` that calls it.** It was the last
verb in the whole menu enhancement written without a caller, and with it **no method behind
`IMenuWorkflow` is unreachable from a form**. Three findings ship beside it — F-90, F-91 and F-92 — and
they are one defect three times.

## The first thing to read: 1149 was predicted and 1151 ran

Slice 42 predicted **1149**. The run returned **1151**, green, twice. Per §18 that difference is the first
thing chased, and it resolves to the unit.

The tree holds **1132** `[Fact]` plus `[InlineData]` cases. `SchemaMigrationRunnerTests` adds its 5 facts,
`KeyRelations`' **13** theory rows, and `KeyColumnsAddedByAlter`'s **6** — four columns added by `0004`,
two more by `0005`. That is 1151. Substitute the **four** §16.4 states and you get 1149.

**§16.4 says *"Four theory rows therefore name the columns that arrived by `ALTER`"*.** `0005` added
`menu_item.menu_section_identifier` and `menu_item_event.new_menu_section_identifier` to that
`TheoryData` and the sentence did not move. That is **F-90**, and the part worth carrying is why the gate
built for exactly this could not see it: `TestingSectionContractTests` compares an **assertion count per
class**, which for that file is 7 methods and is still correct. A theory-row count is a different quantity
living in the same paragraph. So a number went stale inside the one section written to stop numbers going
stale, in the one form its gate is structurally blind to.

**The instrument that reported it was §18's habit and nothing else.** This is the first finding in the
ledger produced by chasing a predicted count rather than by somebody reading a file — which is what F-70
established the habit for, three slices after the last opportunity to use it.

## F-91 and F-92, which are the same defect one register out

**F-91.** §16.3 scenario 16 says *fifteen controls are expected* and itemises them, including *a rename and
a reprice on the item*. `ManageMenuItem.razor` gained a third `.manage-inline-form` in Slice 38 and a
fourth in Slice 40; this slice makes five. Nothing reported it because the assertion above the census is a
**floor of fourteen**, and a floor that passes at fifteen passes at seventeen — so the itemisation was a
number only a person re-deriving it by hand could ever check.

**The floor is deliberately not raised, and that is a ruling.** Its value is a claim about controls
rendered on ten surfaces against rows one scenario arranges, which this authoring environment cannot
observe. An unobservable raise is precisely the edit that turns a green suite red for no gain. It is now
justified by the **smallest selector group** — `.filter-actions`, two controls, one per read-only
explorer — which is a property of the selector set rather than of a render. The residual is written into
the file: a floor notices a group that vanished and never one that grew, and making it a census honestly
would mean attributing each measured control to the selector that matched it, which
`HandheldReachReport` does not carry.

**F-92.** The specification's opening sentence has cited `REQUIREMENTS.md` (rev 5) since v1.15 moved that
document to rev 6. `SpecificationVersionTests` compares each document's header against its **own**
changelog, which is what F-58 asked for and is a different question — so both documents were internally
consistent and disagreed with each other. **The sibling document had already learned this and said so in
its own header:** `REQUIREMENTS.md` records that it deliberately does not restate the specification's
version, *because a version of another document is a restatement joined to its subject only by somebody
remembering to edit it*. F-58's lesson was written into one of the two documents and not the other, so the
citation that survived is the one pointing the other way.

All three are repaired identically — **the number is deleted, not corrected** (F-77) — and in all three
**no gate is added** and the residual is stated. A gate for one sentence leaves every other instance of
the class untouched (F-47).

## The move, and the three rulings inside it

**An item is appended to the end of its new heading.** Carrying the old position across would drop the dish
into the middle of an ordering somebody chose for a different list, because a position is a position
*within* a heading. `MAX(display_order) + 1` under a lock on the target section row is exactly what
`CreateMenuItemAsync` does, so after this verb the two are one rule: an item arriving in a heading,
however it arrives, arrives at the end of it.

**Two events, or one.** §8.2 binds `new_display_order` to `reordered` alone, so a move that also changes
the position must say so in a second event rather than move a number the log does not mention. It is
conditional on the number actually differing — a move into an empty heading from position 0 lands at 0
again, and an event reading *moved to position 0* beside an unchanged column is the "somebody pressed
Save" noise §11.4's history exists to refuse. Order: `section_changed` then `reordered`.

**The item lock is taken before the section lock.** It is the only nested acquisition in that file and it
runs in the direction every existing write already runs in — the item verbs lock an item and nothing else,
`CreateMenuItemAsync` locks a section and nothing else. Two administrators moving two dishes into each
other's headings therefore cannot deadlock: both take their item lock first, and neither holds a section
lock while waiting for one.

**Nothing else about the item moves.** Name, price, description and `is_active` are untouched, so an 86'd
dish refiled between headings is still 86'd — the item-side counterpart of §7's rule that deactivating a
heading does not cascade to its items.

## The publish is as loud as a section visibility flip

§11.1 groups the guest menu by heading, so a committed refile moves a card between groupings on every open
picker in the building. A refile **into an inactive heading** removes the card from the guest's menu
entirely, because §7 renders no such heading at all — which is the same reach `SetMenuSectionActiveAsync`
has, arriving from the other direction. Conditional on `Moved` alone: `NoChange`, `MenuItemNotFound` and
`MenuSectionNotFound` each commit nothing.

## The obligation is discharged rather than narrowed, and how it was carried is the transferable part

A workflow verb with no caller is a code path no test can reach through the interface meant to protect it.
Six verbs were held outside `IMenuWorkflow` under that rule across seven slices — five section verbs and
this one — and **the count of how many were outstanding was written down every single slice.** That is the
only reason its reaching zero is a fact somebody can state rather than something noticed later. A deferral
named every slice is a deferral; one named once is an omission with a date on it.

## What is in this slice

- **`Menu/MenuAdministration.cs`** — `MoveMenuItemToSectionOutcome` (four members, where the reorder
  outcome has three), `MoveMenuItemToSectionAsync`, `menu_section_identifier` added to the shared lock read
  and to `MenuItemLockRow`, and `UpdateMenuSectionAndPositionSql`.
- **`Menu/MenuWorkflow.cs`** — the verb, publishing on `Moved`.
- **`Administration/ManageMenuItem.razor`** — a `.manage-inline-form` section picker between Description
  and Position, pre-selected on the item's own heading, offering inactive headings marked.
- **`MenuAdministrationTests.cs`** — 26 → **31**.
- **`MenuWiringTests.cs`** — 18 → **19**, plus the fake's new verb.
- **`AdministrationJourneys.cs`** — `MoveMenuItemToSectionAsync`.
- **`EndToEndScenarios.cs`** — scenario 17 gains step (i); scenario 16's census replaced by its rule
  (F-91).
- **Documentation** — specification to **v1.28** (§0, §7, §11.4, §16.4, Appendix A, changelog),
  `DOCUMENTATION_REVIEW.md` gains F-90 through F-92, the plan strikes the last deferred verb.

## Two things about the surface that are decisions rather than markup

**The button reads "File here", not "Move".** The Position form's button already says *Move*, and
Playwright's `has-text` is substring matching — so a second button containing that word would make every
locator in the harness ambiguous the day somebody wrote one. The name is chosen against a test-harness
constraint rather than for its own sake, which is worth saying because it looks arbitrary otherwise.

**No CSS moves.** `.manage-inline-form` has styled `select` since Slice 34 — which is the same fact the
comment beside the description form states from the other end when it says that class has never styled a
`textarea`. The page's closing note used to say it carried *two small forms*; it carried four. That count
is deleted rather than corrected, on the same ruling as the three findings above.

## What was verified

**The working tree was reconstructed from `dump.txt` and checked against the SHA-256 recorded for every
file: 348 of 349 byte-identical.** The exception is `export.sh`, which contains the dump's own `# FILE:`
banner as literal text and therefore cannot be round-tripped by any parser using that banner as a
delimiter. It is excluded from the work set rather than reconstructed and guessed at, and is not delivered.

**`TestingSectionContractTests` was run in substance**, ported: **19 counted classes, 0 disagreements, 0
ambiguous, 0 uncited**, floor met exactly. The two counts this slice moves — `MenuAdministrationTests` to
31 and `MenuWiringTests` to 19 — were compared against the files by that port and agree.

**The new §16.4 paragraph names two test classes and states no count**, which the gate reads and correctly
declines to attribute. That is deliberate: a second paragraph claiming a count for a file another paragraph
already counts would be the same fact written twice in the section whose whole subject is that mistake.

**`SpecificationVersionTests` was run in substance**: header 1.28, newest changelog entry 1.28, **29
entries descending**.

**`MarkdownTableContractTests` was run in substance** over every Markdown file outside `docs/llm/`,
fence-aware and escaped-pipe-aware: **61 table runs, zero ragged**, including the six new four-cell rows
across the two registers.

**Brace, paren and bracket balance** on all six changed C# and Razor files, string- and comment-aware —
and the checker was proven against **four untouched, SHA-verified siblings** first, which is the habit
Slice 41 paid for. All ten clean.

**Razor tag-tree comparison** of `ManageMenuItem.razor` against its SHA-verified original: 188 tags before,
**208 after**, and the diff is **one contiguous insertion** and nothing else — the twenty tags of the new
form and the heading above it. The markup walk closes every element it opens, with nothing unbalanced and
nothing left on the stack.

**Byte hygiene** on every changed file: no CR, exactly one final newline, no whitespace-only line, no
context-dump separator.

**The CS4007 scan caught one, which is the reason it is run.** The new harness journey's failure message
was first written as `$" effect. {await DescribeFailureAsync(page)}"` — an `await` inside an interpolated
string hole bound to `DefaultInterpolatedStringHandler`, which does not compile. Repaired to the shape its
four neighbours in that file already use: the `await` is a separate operand of the concatenation rather
than a hole. Worth recording because it is a defect a reading finds only if it is looking for it, and
because §18's list of mechanical traps exists precisely so that this class is scanned rather than reviewed.

**The Razor directive gate was run in substance** over the changed component: no bare `@section` or
`@RenderSection`, and the one occurrence of the word after a transition is `@@section` inside a comment,
which is Razor's escape and which `RazorDirectiveContractTests` explicitly admits (F-81).

**The F-90 arithmetic was recomputed from the tree** rather than taken from the prediction it explains:
1132 counted directly, 13 and 6 counted out of the two `TheoryData` initialisers, and 5 facts in the file
itself.

## What was NOT verified

**Nothing compiled.** No .NET SDK in the authoring environment. Named rather than left to be found:
`MoveMenuItemToSectionAsync` is the third method on `IMenuAdministration` whose parameter list is two
`Guid`s in a row, and the two are `menuItemIdentifier` then `menuSectionIdentifier` — the same order
`CreateMenuItemAsync` uses, deliberately, but positionally interchangeable to the compiler. Every call site
in this slice passes them in that order; a transposition would compile and fail at run time as
`MenuItemNotFound`.

**No test ran.** Every count below is arithmetic.

**No database saw the move.** The append is derived from reading
`LockMenuSectionAndReadNextPositionSql`, which `CreateMenuItemAsync` already uses and which
`ItemsAreAppendedToTheEndOfTheirOwnSection` already proves against a real PostgreSQL — so what is new here
is the caller, not the query. That two events are permitted in one transaction rests on §8.2's paired
CHECKs, which `MenuAdministrationTests` exercises for each type separately and which no fact yet exercises
in this combination.

**No browser ran scenario 17's new step.** The arrival barrier is a CSS attribute selector on the facts
grid's Section link, `a[href='/administration/menu/sections/{guid}']`, which requires the rendered `href`
to match exactly — Razor renders a `Guid` with its default `D` format and `ToString("D")` produces the
same, but this environment cannot observe that agreement.

**Nothing verified that F-91's census was the only stale count of its kind in the harness.** A repository
reading found this one; a number in a comment nothing parses is reachable by no gate here, which is F-90's
residual restated in a second file.

## Test count

Last predicted **1149**; **observed 1151** — the first prediction to meet a run in three slices, and the
difference is F-90 above.

Predicted here: **1157**. Arithmetic on the observed number, per §18: 1151 + 5
(`MenuAdministrationTests` 26 → 31) + 1 (`MenuWiringTests` 18 → 19). Scenario 17 is **extended, not
added**, so §16.3 stays at **17** and the end-to-end project stays at 17 facts.

Per §18: if the run returns anything other than 1157, that difference is the next thing to chase.

## Still open

**The sections-first index.** `/administration/menu` is still an item list with a Section column. It is now
the largest remaining piece of Stage 3, and nothing blocks it — the editor it needs to open into has
existed since Slice 41.

**A section's own description under its heading on the guest menu.** Unchanged. It needs either a second
read or a widened `MenuItemSummary`, and F-84 is the reason widening that record is not free.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**The handheld barrier visits neither section surface, and now it also misses a form.** Scenario 16 walks
ten surfaces; `ManageMenuSection` is a detail surface with `.manage-inline-form` buttons and would move the
control count. As of this slice the item detail page it *does* visit has five inline forms where the
barrier's own account said two — corrected as F-91, but the gap it points at is unchanged.

**No gate can see a count written in a comment.** F-90's and F-91's shared residual, stated once here
rather than twice above.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Eighth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a tenth time.

**A CI job that runs the canonical stack on the canonical engine.** Nineteenth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

---

# M6 Slice 44 — the index becomes the menu, and a barrier that measures by list

**Stage 3's largest remaining piece.** `/administration/menu` was a flat list of every item with the heading
as a *column*; it is now a group per heading, each holding the items filed under it. That column was shipped
deliberately in Slice 40 as an honest intermediate and named as one in the same breath, on the reasoning that
a sections-first index needs an editor to open into and a record list whose rows link nowhere is a list of
dead ends. The editor landed in Slice 41, the refile verb in Slice 43, and **nothing had to be undone to get
here** — which is the claim that intermediate was chosen against, now testable and true.

## The surface

**A heading is a `<details>` and its summary is the heading.** A native disclosure, chosen for four
properties rather than for looking modern: it collapses with no script on a page that is static SSR and hosts
no island, it is a disclosure in the accessibility tree rather than a `div` somebody wired up, it needs no
state on the server, and `summary` keeps its own `display: list-item` so the marker is the affordance. The
last of those is why `.menu-group-summary` does not set `display: flex` — that removes the marker in every
engine that draws one, and then the control's own affordance has to be reinvented.

**It is rendered open on every request, and there are two independent reasons.** A heading a server
collapsed is a heading whose items nobody looking for an item can find. And §16.3 scenario 16 measures what a
layout engine laid out: a control inside a closed `<details>` has no box, so a collapsed group would remove
its own controls from the barrier that exists to catch controls going missing. Collapsing is the operator's
decision; the server does not make it for them.

**An empty heading is on this surface and on no other page in the application.** The old list was built from
`menu_item`, so a heading with nothing under it was invisible everywhere — §11.1 renders no empty heading to
a guest, and the index could not see one at all. A heading created with a typo could only be worked around
by making another, and the *reason* it could only be worked around was that nothing showed it existed. The
page now reads both directories: `IMenuSectionDirectory.ListAsync` for the headings, which is what that read
was written for and which says so in its own doc comment, and `IMenuDirectory.ListAsync` for the items.

**Filtered per heading rather than grouped, and that is §7's ordering being collected on.** The six-key
`ORDER BY` already makes each heading's items contiguous, so `Where(...)` preserves the order somebody chose,
where a `GroupBy` would re-order the headings into hash order and make the ordering decision a second time in
a second file. A per-section read would be a query with one caller, which `IMenuDirectory` declines to invent
for exactly this reason. `ManageMenuSection` has done the same filter since Slice 41, so the two surfaces now
group by one rule.

## The cut, and why it is a ruling rather than a shortfall

**The plan promised this index "with the section's own order controls" and they are not in it.** The reason
only becomes visible once somebody tries to write them. `ReorderMenuSectionAsync` sets an **absolute**
`display_order`, and §7 makes positions deliberately non-unique with a name tie-break — so *move this heading
above that one* is not expressible as one absolute write. Two headings sharing a position have an order
nobody assigned, and there is no single number that distinguishes them: writing the predecessor's position
onto the mover leaves both at the same number, ordered by name, which is where they already were.

An honest up/down control therefore needs a **resequencing verb** — one transaction, a lock per affected row,
and one `reordered` event per row whose number actually moved. That is a new write with new event semantics,
not a surface change, and it is a slice of its own. So the index makes the ordering **legible** — headings in
stored order, each one's position on its own summary — and the editor keeps the write.

**The transferable rule is narrower than "defer the hard part".** When a surface would need a verb the model
cannot express, the surface ships without it and says so, rather than shipping a control that is right in the
common case and silently wrong wherever the data is *permitted* to be ambiguous. The permission is the point:
non-unique positions are a decision this project made on purpose, so an up/down control would not be a rare
edge case — it would be wrong exactly where somebody had never bothered to assign distinct numbers, which is
the default state of every menu this application creates.

**Recorded for veto**, with the reversal spelled out in `_CHANGES.md`: `ResequenceMenuSectionsAsync` behind
`IMenuWorkflow`, and a two-button form per group whose `@formname` is derived from the section identifier —
the shape `ManageMenuSection`'s visibility toggle already uses, and the only shape that works for N forms
without N `[SupplyParameterFromForm]` properties, because that attribute's `FormName` must be a compile-time
constant.

## F-93 — the barrier measures by list, and a surface can go quiet inside it

**The finding is a property of the gate, not of this page.** §16.3 scenario 16's reach selector names
`.record-actions`, `.page-head-action`, `.filter-actions` and `.manage-inline-form button`. The membership
*rule* is good — *the thing an operator opened the page in order to press* — and it is enforced as a list of
class names, which means a surface can keep being **visited** and stop being **measured** with nothing
reporting it.

This slice is where that became concrete rather than hypothetical. The sections-first index replaces every
`.record-actions` row on its primary list with a `.menu-group` group, whose two controls — the disclosure and
the link into the editor — are in none of the four groups above. **The floor would have gone up while
coverage of the heading went to zero**, because the item rows *inside* the groups still carry
`.record-actions`. A floor notices a selector group that vanished and never one that was never counted, which
is F-91's stated residual arriving as a live defect one slice after it was written down as a note.

`.menu-group-summary` and `.menu-group-actions a` join the reach set, and **the repair recorded in §16.4 is a
rule rather than two selectors**: a surface that acquires a new kind of control acquires a selector in the
same slice, or it is a surface this barrier has stopped asserting anything about. A `<summary>` is admitted on
the existing membership rule rather than as an exception to it — it occupies the position `.record-primary`
holds on every other index, and it is the only control the new surface introduced.

**No gate is added and the residual is restated.** Making the floor a census honestly means attributing each
measured control to the selector that matched it, which `HandheldReachReport` does not carry. That was
declined in Slice 43 and is declined again here, for the same reason and now with a second instance behind it.

## F-94 — a count that named one set and computed another, under a comment that knew

`AdministrationMenu.razor` closed with *"N of M available, K described, across S sections"*, and `S` was
`_items.Select(item => item.MenuSectionIdentifier).Distinct().Count()` — the number of headings **with
something under them**. A menu with five headings and two stocked read *across 2 sections* to the one person
in the building entitled to see all five.

**The page knew, and said so.** The line above it carried a comment reading *"not the same number as the
section count — an empty heading exists and is not visible here"*. That is **F-65's mechanism** — a comment
asserting what the code beneath it does not do, in the position a reader checking the number would stop —
with one difference worth naming: F-65's comment was *false* about its declaration, and this one was
*accurate* about its computation and still left the screen wrong. An honest comment about a defect is not a
fix, and it is more durable than the defect, because the next reader stops at the explanation.

**No gate is added.** A number computed from a list two lines above it is not a restatement of anything, so
there is no second copy for a gate to compare against; what was wrong was the English. Prose describing a
computation inside a component is reachable by no gate this repository has, which is stated as the residual
(F-47).

## What is in this slice

- **`Administration/AdministrationMenu.razor`** — rewritten sections-first: two directory reads, a group per
  heading, the item list inside each, the counts corrected per F-94.
- **`wwwroot/app.css`** — the `.menu-group*` vocabulary, declared once, plus one rule inside the existing
  `min-width: 48rem` query.
- **`Harness/HandheldReach.cs`** — two selectors join the reach set, with the membership reasoning (F-93).
- **`Components/HandheldLayoutContractTests.cs`** — `.menu-group` joins `SharedSelectorPrefixes`, and the
  list becomes a multi-line initialiser so the next addition is a one-line diff.
- **`Harness/AdministrationJourneys.cs`** — `MenuHeadingOnTheIndex` and `ReadMenuIndexAsync`.
- **`EndToEndScenarios.cs`** — scenario 17 gains step (j).
- **Documentation** — specification to **v1.29** (§7, §11.4, §16.3, §16.4, Appendix A, changelog),
  `DOCUMENTATION_REVIEW.md` gains F-93 and F-94, the plan strikes the index and records the cut.

## Scenario 17's new step, and why the assertion is a disagreement

**A third heading is created and left empty.** §11.1 renders no empty heading to a guest; §11.4 renders the
complete record to the administrator. So the same instant must produce **three groups on the index and two
groupings on the guest's menu**, and the difference must be exactly the empty one.

**Neither surface alone says anything.** A heading missing from the guest's menu has three possible reasons —
it is inactive, it is empty, or the page is broken — and a heading present on the index has none. It is the
comparison that is the test, which is why the step reads both and why it is in scenario 17 rather than in a
scenario of its own.

The step also asserts the index's **ordering** (stored, not alphabetical — a page sorting its own headings
would put *Puddings* first and pass every other assertion here) and that the refile from step (i) is visible
from the administration side, so an index grouping by anything other than `menu_item.menu_section_identifier`
fails here even where the guest's menu is right.

**One direction is weaker and it is named in the file.** The closing assertion is that the guest never sees
the empty heading, and an assertion of absence cannot prove §9's broadcast landed. What carries it is the
disagreement with the index above, which was read from a page that had to be fetched.

## What was verified

**The working tree was reconstructed from `dump.txt` and checked against the SHA-256 recorded for every file:
348 of 349 byte-identical.** The exception is `export.sh`, which contains the dump's own `# FILE:` banner as
literal text and therefore cannot be round-tripped by any parser using that banner as a delimiter. It is
excluded from the work set rather than reconstructed and guessed at, and is not delivered.

**The balance checker reported findings on a correct file three times before it was trusted, and that is the
habit paying for itself rather than an anecdote.** It was run against four untouched, SHA-verified siblings
first (F-41's rule, and Slice 41's lesson). It failed on `ManageMenuSection.razor` three times in
succession, each time for a different reason, and each reason is a real property of this tree: an apostrophe
in Razor *prose* read as the start of a C# character literal, so the scan swallowed text to the next
apostrophe and lost a brace; `<ValidationMessage For="…" />` counted as an unclosed element, because the
self-close was being read out of a lazily-matched attribute group; and `For="@(() => Input.Name)"` truncating
the tag match at the `>` of the lambda arrow. **A checker that had been pointed at the changed files first
would have reported all three as defects in this slice's work.**

**Razor tag-tree walk** of the rewritten page: **75 tags**, every element closed, nothing left on the stack —
and the same walk run over two untouched SHA-verified siblings, `ManageMenuSection.razor` (112 tags) and
`AdministrationTables.razor` (39 tags), both clean, which is what makes the first number mean anything.

**Every class the new page names is declared in `app.css`:** 32 class tokens, none undeclared. Run over the
two control files as well — 28 and 20 tokens, none undeclared.

**The cell-label gate was run in substance** on the rewritten page: **9 `<td>` and 9 `data-label=`**, exact,
which is the arithmetic `EveryRecordListCellCarriesTheLabelThatReplacesItsColumnHeader` performs. The page
still contains two record lists, so the gate's floor of seven pages is unaffected.

**The stylesheet's own facts were checked in substance:** **two media queries in the file and exactly one
carrying a width**, `min-width`, no `max-width` anywhere; **no undeclared custom property read**; **zero
`var()` fallbacks**; **no colour literal outside `:root`**; and every `min-height` in the file is
`var(--touch-target)`, exactly `0`, `5.5rem` or `100dvh` — the floor holds with nothing new added to it.

**No component declares a `.menu-*` selector inline**, checked before `.menu-group` was added to
`SharedSelectorPrefixes`, so the new prefix reports nothing on a correct tree (F-67's rule, and the reason
that ruling had to exist before any prefix could be added).

**`SpecificationVersionTests` was run in substance:** header **1.29**, newest changelog entry **1.29**, **30
entries descending**.

**`MarkdownTableContractTests` was run in substance** over every Markdown file outside `docs/llm/`,
fence-aware and escaped-pipe-aware: **61 table runs, zero ragged**, including the three new four-cell rows
across the two registers.

**`TestingSectionContractTests` was run in substance**, ported: **19 counted classes, 0 disagreements, 1
ambiguous paragraph** (one that names two classes and is correctly skipped), floor of nineteen met exactly.
The two new §16.4 paragraphs name no test class and state no count, so the gate reads them and correctly
declines to attribute anything — which is deliberate, F-89's ruling being that the floor is the only census.

**Byte hygiene** on every changed file: no CR, exactly one final newline, no whitespace-only line, no
context-dump separator.

**The CS4007 scan found nothing this time**, which is worth one line rather than none: the new harness method
composes its failure message by concatenating an `await` as a separate operand rather than putting it in an
interpolation hole, which is the shape its four neighbours in that file already use and the shape Slice 43
had to repair.

## What was NOT verified

**Nothing compiled.** No .NET SDK in the authoring environment. Named rather than left to be found: the new
page's `@code` block declares `_items` as `IReadOnlyList<MenuItemSummary>` initialised to `[]` and `_sections`
as nullable, and the markup branches on `_sections is null` while `ItemsUnder` dereferences `_items` — which
is safe only because both are assigned in the same `OnInitializedAsync` before any branch reads either. A
static SSR intermediate render fires `StateHasChanged` the moment `OnInitializedAsync` suspends, so the
branch order matters: `_sections is null` is tested first and is the only branch that reaches `ItemsUnder`.

**No browser rendered a `<details>`.** The disclosure is the one piece of this surface whose behaviour is a
browser's rather than this project's, and three claims about it are unobserved here: that `min-height` on a
`display: list-item` box produces a 44px target, that the marker survives the padding, and that a group
rendered with the `open` attribute is laid out with its body measurable. All three are ordinary HTML and all
three are what scenario 16 would fail on.

**No test ran.** Every count below is arithmetic.

**Nothing measured the new controls.** F-93's repair is two selectors in a reach set, and whether the
disclosure and the editor link actually lie inside a 375px viewport is precisely the question this
environment cannot answer — which is the same reason F-91's floor was not raised.

**Nothing verified that F-93 is the only surface the barrier has gone quiet on.** The mechanism is general: any
surface that changes vocabulary does this, and the gate has no way to report a class it was never told about.
The rule is now in §16.4, which makes the next instance a rule violation rather than an accident, and does
nothing about a past one.

**Nothing verified that F-94 is the only count of its kind in a component.** A repository reading found this
one; a number computed inside a `@code` block and described in prose beside it is reachable by no gate here.

## Test count

Last predicted **1157**, by Slice 43, and **not known to have run** — this session has no observation of it.
Predicted here: **1157**, unchanged, and unchanged for a reason rather than by coincidence. No test class is
added. No `[Fact]` or `[Theory]` row is added. `HandheldLayoutContractTests` gains a list *entry* rather than
an assertion, so its count of nine is untouched and §16.4's census does not move. Scenario 17 is **extended,
not added**, so §16.3 stays at **17** and the end-to-end project stays at 17 facts.

Per §18: if the run returns anything other than 1157, the difference belongs to **Slice 43's** arithmetic
rather than to this slice's, and that is the first place to look.

## Still open

**A section's own description under its heading on the guest menu.** Unchanged, and now the largest remaining
piece of Stage 3. It needs either a second read or a widened `MenuItemSummary`, and F-84 is the reason
widening that record is not free.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**Reordering a heading from the index.** New, and named rather than discovered: it needs
`ResequenceMenuSectionsAsync`, which is a write rather than a surface, for the reason recorded above.

**The handheld barrier visits neither section surface.** Scenario 16 walks ten surfaces; `ManageMenuSection`
is a detail surface with `.manage-inline-form` buttons and would move the control count. Carried, and now
larger than it was: the menu index it *does* visit has changed shape entirely since the barrier last had
anything to say about which controls it holds.

**No gate can see a count written in a comment, or a sentence describing a computation beside it.** F-90's,
F-91's and now F-94's shared residual, stated once.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Ninth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred an eleventh time.

**A CI job that runs the canonical stack on the canonical engine.** Twentieth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

---

# M6 Slice 45 — the tie-break that was a coin flip

**A test failed, then passed, on an unchanged tree, and the failure message was the whole finding.** The
first `dotnet test` of the session reported one inverted pair in `MenuEventLogTests`: `section_changed`
expected where `created` arrived. Those are two events of one create transaction, written at one instant, and
their order in the log is decided by the identifier tie-break. So the tie-break was not breaking the tie.
`bash scripts/ci_local.sh --with-all --with-e2e` then ran the same suite green, and the count came back at
1157 exactly as Slice 43 predicted — which is what a 50% property looks like from inside a green run.

**`Guid.CreateVersion7()` is ordered between milliseconds and random inside one.** Verified against
`dotnet/runtime` `release/10.0`: the method is `Guid.NewGuid()` with the 48-bit Unix-millisecond timestamp
written over the top and the version and variant nibbles set. The other 74 bits are left exactly as the
cryptographic source produced them. Two values minted in the same millisecond therefore share their entire
ordered prefix and are separated only by random bits — 49.8% of such pairs invert under PostgreSQL's `uuid`
comparison, measured over 20,000 pairs.

## Why the schema was leaning on the missing half

Every mutation in §8 reads `IClock.UtcNow` **once** and stamps every row of its transaction with it. That is
deliberate and it is right: a row and its event describe one change and should agree about when it happened.
The consequence is that same-instant rows are the normal case rather than the edge case, so nine reads in
`MyRestaurant.DataAccess` order by an instant and then break the tie on an identifier, and `OrderProjection`
does the same for lines. Every one of those was resolving the tie at random.

**Three menu surfaces and one guest surface were affected, and the guest one is the worst.**

- **§11.4's per-item history.** A menu item created under a heading with a description writes `created`,
  `section_changed` and `description_changed` at one instant. Six orderings, one of them right: the history
  read *"Created as “Soup” at 4.50 / Filed under Starters / Description set"* **one time in six**, and read
  the effect before the cause the rest of the time.
- **The section history**, same shape, one register up.
- **The index's activity feed**, added last slice, reordered itself between page loads on unchanged data.
- **A guest's basket order did not survive being sent.** `OrderStaging.Build` mints one line identifier per
  basket row in a tight loop **in basket order** — the loop that builds the human-readable descriptions
  alongside them depends on that order and shows it correctly. `OrderProjection` then orders lines by their
  added-at instant and breaks the tie on `order_line_identifier`, and every line of one send shares that
  instant. So the basket was ordered, the descriptions were ordered, and the order itself was shuffled: on
  the guest's own surface, on the kitchen ticket, and on the bill.

## F-95 — and what the comments were doing

Four comments asserted the property. Two in `MenuEventLog`, one in `AdministrationMenu.razor`'s `@key`
explaining why an index key would be wrong, one in `MenuEventLogTests` explaining why `section_changed` sits
second. Every one of them reasoned **correctly from a false premise**: the values are UUIDv7, UUIDv7 is
time-ordered, therefore these two are ordered. The first two clauses are true and the conclusion does not
follow for two values inside one millisecond.

That is a different failure from F-65's and F-77's, which were two copies of one number disagreeing. Here
there was one claim, load-bearing in four places, and **half right in a way that reads as fully right** —
which is why four separate readings of those files never caught it. So the repair is not deletion, and this
is the rare case where F-77's delete-the-number ruling does not apply: the prose was right about the
mechanism and wrong about who provided it. The comments now name the factory's **contract** as what makes the
tie-break hold, which is a sentence a test can fail.

## What is in this slice

- **`IIdentifierFactory.Create`** gains the contract: successive calls ascend under PostgreSQL's `uuid`
  ordering, including inside one millisecond. Stated on the interface because nine reads depend on it and
  none of them can do anything about it individually — the F-47 habit, applied to a guarantee rather than to
  a list.
- **`UuidV7IdentifierFactory`** keeps it with a 12-bit counter in `rand_a`, which is RFC 9562 §6.2's first
  named method for exactly this. `Guid.CreateVersion7()` is still called, for its 62 random `rand_b` bits
  from the same cryptographic source and for the version and variant nibbles it has already placed; only
  bytes 0–7 are replaced. No new dependency, no new randomness source.
- **The concurrency argument is one `long`.** It packs the millisecond count above the counter, which is the
  first 60 bits of the value *in the order PostgreSQL compares them* — so "the next identifier ascends" and
  "the next packed value is larger" are the same statement, and the whole proof is that one `long` only ever
  increases. Advanced by `Interlocked.CompareExchange`; a failed exchange returns the value that beat it, so
  a thread only ever loses to a thread that made progress. 48 + 12 = 60 bits cannot overflow a `long`.
- **The two edges both resolve the same way.** Counter exhaustion carries into the timestamp rather than
  wrapping, because a wrap hands out a value sorting *before* its predecessor — the defect back under a
  smaller name. A clock stepping backwards is that case seen from the other side: the candidate is behind
  what was issued, so issued-plus-one is used and the stream never doubles back.
- **The state is static**, and that is tested rather than asserted. The application registers a singleton so
  an instance field would suffice in production, but the guarantee is about the *process's* stream: two
  factories each ascending independently would satisfy an instance field while handing two callers values
  that interleave wrongly.
- **`UuidV7IdentifierFactoryTests`** goes from 2 assertions to 7. The five new ones are the burst, the
  two-instance interleave, the counter-exhaustion carry, the concurrent sort-key distinctness, and the
  variant bits surviving the overwrite.
- **§16.4** gains a paragraph and its enforced census floor moves 19 → 20. **§8.1** carries the requirement.
  **ADR-0011** is amended with the counter and both edges. **Appendix A** gains F-95;
  `DOCUMENTATION_REVIEW.md` gains its row and the narrative about probabilistic evidence.
- **`MENU_AND_HANDHELD_PLAN.md` gains Stage 3a**, the resequencing verb, fully specified and recorded as
  unblocked — see the ruling below.

## Every comparison is the database's, and that is the load-bearing choice

`Guid.CompareTo` is **not** PostgreSQL's `uuid` order. The BCL compares a `Guid` field by field and the
second field is a *signed* 16-bit integer holding the low sixteen bits of the millisecond, so it reads as
negative for half of every 65.536-second window; the two orders disagree wherever a pair straddles a boundary
at which those bits cross 0x7FFF. A concrete disagreeing pair was constructed and checked.

So every assertion in the new tests compares `ToByteArray(bigEndian: true)` byte by byte, and a private
`SortKeyOf` exists so that no assertion can quietly acquire the wrong comparison later. A version of that
file written with `CompareTo`, `Comparer<Guid>.Default`, or `OrderBy(identifier => identifier)` would pass
while pinning a relation no read uses — F-41's shape arriving through a comparison operator rather than
through a scope.

## The reordering verb is deliberately not in this slice

§7 records `/administration/menu`'s inability to reorder a heading as a cut, and Slice 44 named
`ResequenceMenuSectionsAsync` as what it needs. **It is not here, and the reason is this slice's own
subject.** A resequencing verb writes several `reordered` events in one transaction, therefore at one
instant, therefore in an order decided entirely by the property F-95 is about. Shipping it before the fix
would have written a correct set of rows in a random order onto the surface whose whole job is legibility.
Shipping it *with* the fix would have made the verb's ordering test simultaneously the first test of the fix,
so a red run could not have said which change caused it — and §18's habit of chasing a count deviation
before the slice closes is cheap with one candidate and expensive with two.

Stage 3a in `MENU_AND_HANDHELD_PLAN.md` carries the full design so the next slice is arrangement rather than
design, including the two obligations it inherits: F-93's selector, and the explicit statement that the
item-level mirror is a third slice rather than an oversight.

## What was verified

- **The root cause, against the framework source.** `Guid.cs` on `dotnet/runtime` `release/10.0` was read
  through the GitHub API. `CreateVersion7(DateTimeOffset)` calls `NewGuid()`, overwrites `_a` and `_b` from
  `unix_ts_ms`, sets the version nibble in `_c` and the variant in `_d`, and returns. There is no counter and
  no monotonic state, so the finding is a property of the method rather than an inference from a failure.
- **The ordering claim, by measurement.** A byte-accurate model of both the old and the new value layout:
  same-millisecond pairs invert 49.8% of the time before, 0 times in 20,000 after; a three-event create reads
  in the minted order 16.7% of the time before; 50,000 values across a moving clock give 0 inversions; 10,000
  inside one millisecond give 0 inversions with the timestamp borrowing 2 ms.
- **The exact byte arithmetic of the shipped `Create`, transliterated and run.** 5,000 values inside one
  millisecond: 0 inversions, every value version 7, every variant nibble `0x80`, timestamp carried forward by
  1 ms, all sort keys distinct.
- **The `CompareTo` trap, by construction.** A pair for which PostgreSQL's order and the BCL's disagree was
  built and both answers printed.
- **`TestingSectionContractTests` simulated in full** against the edited specification: every cited
  `*Tests.cs` resolves, 20 paragraphs state a count, and every count equals the `[Fact]`/`[Theory]` total in
  the file it names. 94 uniquely named test classes found, against the walk's floor of 20.
- **`SpecificationVersionTests` simulated.** Header `1.30` matches the newest changelog entry `v1.30`; the
  history descends; both versioned documents still parse.
- **`MarkdownTableContractTests` simulated.** 20 documents, 56 tables, 583 rows, every row the width of its
  header. This caught a real defect before packaging: the F-95 row contained a literal `|` inside backticks,
  which the gate reads as a cell boundary, so the row had five cells in a four-column table. The phrase was
  rewritten in words.
- **Byte hygiene** on every changed file: LF only, exactly one final newline, no trailing whitespace, no
  whitespace-only lines.
- **Brace and paren balance** on both changed C# files, and the new test file's `[Fact]` count read back as 7
  by the same regex the census gate uses.
- **The reconstructed tree itself.** All 349 files from `dump.txt` SHA-256 verified against the manifest the
  exporter wrote.

## What was NOT verified

- **Nothing was compiled, and nothing was run.** There is no .NET SDK in this environment and the package
  feeds it would need are not reachable from it. Every claim above about ordering is a claim about a model
  and about arithmetic, not about `MyRestaurant.Domain.dll`. Per §18 an uncompiled archive is a prediction.
- **The five new assertions have never executed.** In particular `Create_MintsDistinctSortKeysUnderConcurrency`
  uses `Parallel.For`, and a compare-and-swap loop is exactly the kind of code whose first real test is the
  first real run.
- **No integration test was run**, so it is not observed that `MenuEventLogTests.ListRecent_…` now passes
  deterministically. It should — that is the whole point — but the evidence for it is the model, and the
  original failure was 50% so a single green run would not be evidence either. **The honest check is to run
  the DataAccess suite several times.**
- **Whether any test elsewhere depended on the old randomness** is reasoned about rather than observed. The
  reasoning: the fix makes an order deterministic that was previously arbitrary, and an assertion that passed
  reliably against an arbitrary order cannot have been asserting that order. Assertions about version,
  uniqueness and distinctness are unaffected by construction. But it is reasoning.
- **The guest-basket consequence is not covered by a test in this slice.** `OrderProjection`'s line ordering
  is now correct and nothing asserts that a multi-line send reads back in basket order. That is a real gap
  and it is named in *Still open* rather than quietly closed.
- **No end-to-end scenario was added or changed**, so no browser has observed any of this.

## Test count

Last predicted **1157**, by Slice 44, and **observed at 1157** — twice in one session, once with a failure
and once without.

Predicted here: **1162**. The arithmetic is one term. `UuidV7IdentifierFactoryTests` goes from 2 `[Fact]`
methods to 7, so `MyRestaurant.Domain.Tests` gains **5**. No other test file gains or loses a method:
`TestingSectionContractTests` changes one `const` and one doc paragraph, `MenuEventLog` changes comments only,
and §16.3 is untouched at **17** scenarios.

Per §18: if the run returns anything other than 1162, the first thing to check is the `[Fact]` count in
`UuidV7IdentifierFactoryTests`, because it is the only term in the sum and it is also the number §16.4 now
claims — so a miscount there fails twice, once as a total and once as
`TestingSectionContractTests`.

## Still open

**A multi-line send is not asserted to read back in basket order.** New, and the largest residual of this
slice. `OrderProjection` orders lines by their added-at instant and then by identifier, and the identifier is
now monotonic, so the property holds — but it holds because of a guarantee two projects away and nothing
states it where it is consumed. The right shape is a `MyRestaurant.Domain.Tests` fact over
`OrderProjection.Project` with several lines added in one event, asserting they come back in the order the
operations were listed in.

**Nothing prevents a stored-row identifier being minted outside the factory.** `Guid.NewGuid()` is correct
for security stamps, broadcast tokens and staging keys and appears in production code for all three, so the
rule is not "never call it" — it is "never call it for a value a row will be ordered by", which is a
distinction a tree gate could draw from the call site's context and this tree does not draw at all. F-95
reached the guest's basket through code that used the factory correctly; a future one could reach it through
code that does not.

**A section's own description under its heading on the guest menu.** Unchanged, and still the largest
remaining piece of Stage 3. It needs either a second read or a widened `MenuItemSummary`, and F-84 is the
reason widening that record is not free.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**Reordering a heading from the index.** Now specified rather than merely named — Stage 3a in
`MENU_AND_HANDHELD_PLAN.md` — and unblocked as of this slice.

**Reordering items within a heading.** The same design against `menu_item`, recorded now so the section verb
does not arrive looking complete.

**The handheld barrier visits neither section surface.** Scenario 16 walks ten surfaces; `ManageMenuSection`
is a detail surface with `.manage-inline-form` buttons and would move the control count. Carried.

**No gate can see a count written in a comment, or a sentence describing a computation beside it.** F-90's,
F-91's and F-94's shared residual, and F-95 is a sharper version of it: no gate can see a *claim* written in
a comment either, and this one was wrong for eight months in four files.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** New, and deliberately not made executable.
A retry that goes green is indistinguishable from a fixed flake by any artefact this repository produces, and
F-95 arrived exactly that way. §18 already says a predicted count the run contradicts is chased; the sibling
habit — a run that contradicts *itself* is chased — is now written in `DOCUMENTATION_REVIEW.md` rather than
left as folklore.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Tenth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twelfth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-first consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

# M6 Slice 46 — the dump that had become mostly history

## Read this first: Slice 45 was green, and it was green twice

`total: 1162, failed: 0` — predicted 1162, observed 1162, on both the plain `dotnet test` and the full
`scripts/ci_local.sh --with-all --with-e2e`. §16.3's seventeen scenarios passed on their own run as well.
And the honest check Slice 45 asked for was performed: `MenuEventLogTests` was run **five consecutive
times**, 9 of 9 every time. F-95 was a 50% property, so one green run would not have been evidence and
the delivery note said so; five is.

That closes Slice 45 with nothing outstanding, and it means **the resequencing verb is unblocked** — its
whole reason for waiting was that it writes several `reordered` events at one instant and therefore leans
entirely on the identifier tie-break F-95 fixed.

**This slice is not that verb.** It is the dump, for a reason given in full below, and Stage 3a is next.

## Why this slice is not the menu

The context dump had reached **6.08 MiB and 87% of the project capacity it is loaded into**, and the
composition is lopsided in a way that made the fix obvious once measured:

| Artefact | Size | Share of dump | Content a session reads |
| --- | --- | --- | --- |
| `docs/BUILD_PROGRESS.md` | 829 KiB | 13% | the last six slices; the rest is archaeology |
| per-file metadata blocks | 164 KiB | 2.6% | none of it, ever |
| `LICENSE` | 34 KiB | 0.5% | none — verbatim AGPL-3.0-only |
| everything else | 5.09 MiB | 84% | all of it |

**The argument for doing it before Stage 3a is scheduling, and it is the same argument Stage 1 made
about the handheld contract.** A dump at 87% is a dump that will refuse a session partway through the
next feature, and the cost of hitting that ceiling mid-slice is a slice delivered from a partial tree.
Fixing the container before putting more in it is cheaper than fixing it around the thing already inside.

**And it is deliberately alone in this slice**, on the ruling Slice 45 made and this slice is the second
application of: **one change, one green run, then the feature.** Slice 45 declined to ship the
resequencing verb beside the identifier fix, because the verb's ordering test would simultaneously have
been the first test of the fix and a red run could not have said which change caused it. The same logic
holds here from the other side — this slice moves 730 KiB of documentation that four gates read and
changes what a fifth script enumerates. If Stage 3a's new write rode along, a red run would have two
candidate causes and §18's habit of chasing a count deviation gets expensive with two.

## What is in this slice

**The log is split in two, and neither half is edited.** `docs/BUILD_PROGRESS.md` keeps M6 Slice 40
onward, 106 KiB; `docs/progress/BUILD_PROGRESS_THROUGH_M6_SLICE_39.md` takes M1 through M6 Slice 39, 749
KiB, byte-identical to what was above the `# M6 Slice 40` heading apart from the H1 line being replaced
by an orientation header. `export.sh` withholds `docs/progress/` from the dump by path.

**Every citation of the form *BUILD_PROGRESS M6 Slice N* is left exactly as it was**, in about a hundred
ledger rows across two documents. They cite the *log*, and the log still contains every slice; which of
two files holds slice N is a filing detail, stated once in both files' headers, rather than a fact worth
rewriting a hundred rows to record. This is F-47's habit — where a rule can be executed, a list should
not exist — applied to a rule a reader executes rather than a script.

**`export.sh` names three kinds of held-out path instead of one, because other gates care about the
difference.** `GENERATED_DIRECTORIES` is tool output, and `scripts/check_tree.sh` skips it because a
dump's own structure is the separator that script forbids. `ARCHIVED_DIRECTORIES` is authored history:
still hygiene-checked, still hand-edited, still a record file for the platform-state rule — withheld only
to keep the dump small. `ELIDED_FILES` is listed with its metadata and hash and no body.

**The per-file metadata block goes from twelve lines to three.** Relative path, size, SHA-256 — the three
a session actually uses, which is exactly why they survive: the path is where a change goes back to, and
the size and the hash are what make a reconstruction *checkable* rather than approximate. Gone: absolute
path, last modified, permissions, owner, inode, hard links, MIME type, last git commit, and the file name,
which was the tail of the relative path on the line above it. **Four of the nine described the authoring
machine rather than the repository**, so the dump is now both smaller and less about a computer nobody
asked about. The header's `Host`, `User` and `OS` lines go for the same reason.

**`LICENSE`'s body is elided and its hash is not.** That is the property that makes the elision safe
rather than merely cheap: a modified licence is still detectable from the dump alone. This was flagged as
a veto candidate in the session and cleared — **to revert it, delete `LICENSE` from `ELIDED_FILES` in
`export.sh`**, which is a one-word edit and needs nothing else.

**`ContextDumpExclusionContractTests`, four assertions, and it is the part of this slice that will
outlive it.** The dump reduction is a one-time edit; the *hazard* it creates is permanent, and three of
the four facts are about relationships between files that nothing was comparing.

## The gate, and the defect it caught before packaging

**Fact 2 is the load-bearing one: every withheld document must be linked by path from a document the dump
contains.** Without it, the archive is a file that exists, is in git, is read by nobody, and is invisible
to every future session — which is the state a document is in one careless slice before somebody
regenerates the log without it. History that leaves the dump leaves a pointer behind, or it is gone in
the only sense that matters.

**Facts 3 and 4 are one fact written twice, caught by writing it a third time.** `scripts/check_tree.sh`
carried a comment saying its `GENERATED_DIRECTORIES` was *"kept in step with export.sh's
EXCLUDED_DIRECTORY by hand"* — and after this slice that sentence is false in a way that matters: the
exporter now withholds two directories and only one of them is generated. Hygiene-exempting the archive
because it happens to be excluded from the dump would have stopped checking 749 KiB of tracked text for
the exact defect F-40 was about. So the gate asserts set **equality** against the generated list and
**non-membership** for the archived one.

**And gate 3 of `scripts/check_repository.sh` would have failed on this archive.** That gate forbids a
document from asserting platform state, exempting the files whose job is to quote such a claim —
`DOCUMENTATION_REVIEW.md`, `BUILD_PROGRESS.md`, and the script's own pattern list. The archive contains
F-42's quoted sentence, *"Issues are disabled. There is no bug…"*, at what is now line 6252 of
`docs/progress/`. Moving history out of an exempt file into a non-exempt one carries the exemption with
it or lands red. `docs/progress/*` joins `RECORD_FILES`, and fact 4 asserts that it is there rather than
leaving the next archive to rediscover it.

## What was verified

- **`export.sh` was run.** Not reasoned about — executed, against a `git init`ed copy of the
  reconstructed tree, exit 0, and the output read back. `Withheld paths : docs/llm/, docs/progress/`;
  `Elided files : LICENSE`; zero `FILE: docs/progress` banners in the dump; `LICENSE`'s block carrying
  its real size and hash above the elision line; a sample metadata block showing exactly three fields.
- **The reduction was measured on the produced file rather than predicted.** 6,377,323 bytes before,
  5,483,728 after — roughly **894 KiB, about 14%**, taking 87% of capacity to about **75%**. Stated as a
  round number deliberately: the dump contains this entry, which contains the measurement, so the
  artefact measures itself and a byte-exact saving would be false precision. The first run of the new
  exporter reported 5,436,795, before this slice's own documentation was written into the tree it dumps —
  which is the whole 47 KiB difference and worth knowing rather than quietly reconciling.
- **`bash -n` and `shellcheck --severity=warning` on all twelve scripts, clean**, which is the blocking
  severity CI uses. `--severity=style` is also clean on `export.sh`.
- **Two dead symbols found and removed rather than left.** `file_mime()` had exactly one caller — the
  metadata block — and `is_binary_file` calls `file` itself, so the helper became unreachable;
  `HOSTNAME_VALUE`, `USER_VALUE` and `OPERATING_SYSTEM_VALUE` likewise. An unused function that shellcheck
  does not complain about is still a thing the next reader has to decide about.
- **The split is byte-exact.** The archive is the original bytes above `# M6 Slice 40` with the H1
  replaced; the boundary blank line is consumed by the split rather than left as a trailing blank, which
  is the shape that would have failed the *exactly one final newline* half of tree hygiene — and did, on
  the first attempt, which is why the split asserts its own boundary line numbers.
- **Byte hygiene on both halves and every changed file:** LF only, exactly one final newline, no
  whitespace-only lines, no CR.
- **The platform-state scan was run over the archive before packaging**, against gate 3's own ten
  patterns, which is how the `RECORD_FILES` omission was found rather than shipped.
- **`TestingSectionContractTests` simulated** against the edited §16.4: every cited `*Tests.cs` resolves,
  the new paragraph states exactly one parseable count, and the census reaches 21 against a floor of 21.
- **`MarkdownTableContractTests` simulated** over every changed and new document, including the archive.
- **The reconstructed tree itself:** all 349 files from `dump.txt` SHA-256 verified against the
  exporter's own manifest, zero mismatches.

## What was NOT verified

- **Nothing was compiled and no test was run.** There is no .NET SDK here and the package feeds are
  unreachable. Per §18 an uncompiled archive is a prediction. `ContextDumpExclusionContractTests` has
  never executed — and it is a new file that parses shell arrays with regular expressions, which is
  precisely the kind of code whose first honest test is its first real run.
- **The four new assertions have not been proven sensitive on a pre-fix tree**, which this project
  normally requires before delivery. Two of them **were** proven against a real defect — the
  `RECORD_FILES` omission and the trailing-blank-line boundary were both found by running the check by
  hand against the unfixed state — but by hand, in this container, not by the assertion. Fact 2's
  sensitivity is untested against anything.
- **`shellcheck` here is `shellcheck-py`, not the distribution binary**, so a version difference could
  in principle report differently on your machine. The gate is advisory at `--severity=style` and
  blocking at `--severity=warning`; both were clean here.
- **No gate other than the exporter was executed.** `check_tree.sh`, `check_repository.sh` and
  `ci_local.sh` were reasoned about and hand-simulated against their own pattern lists, not run.
- **The dump this slice produces has never been consumed by a session.** The claim that three metadata
  fields are sufficient rests on nine fields never having been used, which is an observation about past
  sessions rather than a guarantee about the next one. If a future slice needs the last-commit line back,
  that is evidence and not a mistake.

## Test count

Last predicted **1162**, observed **1162**, twice, plus a five-times-repeated `MenuEventLogTests`.

Predicted here: **1166**. The arithmetic is one term. `ContextDumpExclusionContractTests` is new with four
`[Fact]` methods, so `MyRestaurant.WebApplication.Tests` gains **4**. No other test file gains or loses a
method: `TestingSectionContractTests` changes one `const` and one doc paragraph, and §16.3 is untouched at
**17** scenarios.

Per §18: if the run returns anything other than 1166, check the `[Fact]` count in
`ContextDumpExclusionContractTests` first, because it is the only term in the sum. If it returns 1166 and
a *documentation* gate is red, the cause is §16.4's census — the floor moves 20 → 21 in the same slice as
the paragraph that raises it, so an error there fails twice.

## Still open

**Stage 3a — `ResequenceMenuSectionsAsync` — is next, and it is fully specified.** Unblocked as of Slice
45, deferred by name here rather than dropped, which is the discipline that let six earlier verbs be
reported as discharged rather than noticed. The shape is in `MENU_AND_HANDHELD_PLAN.md`: whole-list
permutation rather than a pairwise swap, because equal positions are permitted and a swap would have to
decide something the model leaves ambiguous; refuse a non-permutation as a stale page; `FOR UPDATE` over
all rows ordered by identifier; one `reordered` event per section that actually moved. **It carries F-93's
obligation**: up and down are `<button>` elements and the 375px barrier's reach selector currently reads
`.menu-group-actions a`, so `.menu-group-actions button` joins the set in the same slice or the index is a
surface the barrier has stopped asserting anything about.

**Two §16.4 counts will move with it** — `MenuSectionAdministrationTests` from 20 and `MenuWiringTests`
from 19 — and `TestingSectionContractTests` compares both, so a stale one is loud rather than silent.

**A multi-line send is still not asserted to read back in basket order.** Slice 45's largest residual,
carried unchanged. `OrderProjection` orders lines by instant then identifier and the identifier is now
monotonic, so the property holds — because of a guarantee two projects away that nothing states where it
is consumed.

**Nothing prevents a stored-row identifier being minted outside the factory.** Carried.

**A section's own description under its heading on the guest menu.** The largest remaining piece of Stage
3. Needs a second read or a widened `MenuItemSummary`, and F-84 is why widening that record is not free.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**Reordering items within a heading.** The same design as Stage 3a against `menu_item`, a separate slice
because the two write to different event tables with different paired CHECKs.

**The handheld barrier visits neither section surface.** Carried.

**No gate can see a count written in a comment, or a sentence describing a computation beside it.**
F-90's, F-91's, F-94's and F-95's shared residual, carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried from Slice 45.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Eleventh slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a thirteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-second consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** New, and deliberately left as
a judgement rather than made executable. A size threshold that moved history automatically would be a
script silently rewriting the record of what this project did, which is worse than a document somebody
has to notice is long.

# M6 Slice 47 — the runner that was a default, and the verb that could finally be written

## Read this first: Slice 46 was green, and the count matched

`total: 1166, failed: 0, succeeded: 1166` on `dotnet test`, with `MYRESTAURANT_E2E` set in that shell — the
end-to-end project accounts for 155.9s of the 156.5s — and `total: 17` on the separate scenario run. The
predicted count was 1166 and the run returned 1166, so §18's arithmetic had nothing to chase for the first
time in three slices.

## Two changes in one archive, and why that is not a reversal of the last two slices' ruling

Slices 45 and 46 each deferred this menu verb by name on one rule: **one change, one green run, then the
feature**, because a red run beside two changes has two candidate causes and §18's habit of chasing a count
deviation gets expensive with two. That rule is about *indistinguishable* symptoms. These two are not.

A runner defect cannot fail as an assertion. It fails as an MSBuild error from a `.targets` file, or exit
code 5 for an argument the platform does not recognise, or a summary reporting no tests at all — before any
of this tree's own code runs. A verb defect fails as a named assertion in one of two files. So the first
question a red run raises here answers itself: *did the suite run?* If it did not, nothing in `src/` is
implicated; if it did, nothing about the runner is.

The order to run them in is therefore also the order to read this entry in, and it is in **What to run**
below.

## The runner (F-97)

`xunit.v3` 4.0.0 was published on 2026-08-14 and installs `xunit.v3.mtp-v2`, pinning Microsoft.Testing
Platform 2. **MTP 2 has removed the VSTest target for the .NET 10 SDK**, so bumping the version on a tree
that carries `Microsoft.NET.Test.Sdk` and `xunit.runner.visualstudio` fails at build time, four times, with
a message from a `.targets` file inside the NuGet cache that names the four projects and none of the
packages responsible. That is what happened on the workstation, and reverting the bump was the right
immediate move.

**The finding is not the build failure.** It is that this tree had carried *both* runners for eight
milestones, so which one `dotnet test` used was decided by the SDK's default rather than by anything
written down — and that the choice is spelled in **four independent places** which each move on their own:
the `test` stanza in `global.json`, a package reference per project, a version pin in
`Directory.Packages.props`, and the command line in every script and workflow. A half-migrated tree is one
where `dotnet test` means different things depending on which file was edited last, and the two mechanisms
disagree about the most ordinary argument there is: VSTest reads a bare path as the thing to run, MTP reads
it as a directory to search.

What changed:

- **`global.json`** gains `"test": { "runner": "Microsoft.Testing.Platform" }`. This is the .NET 10
  mechanism. `TestingPlatformDotnetTestSupport` is the .NET 8/9 one, which this tree never had and which
  the migration guidance calls legacy — worth stating because it is the property most search results still
  reach for.
- **Both adapter packages are deleted** from all four test projects and from `Directory.Packages.props`.
  Deleted rather than pinned back: a version standing ready for a package that cannot be used is an
  invitation with a comment on it.
- **Every invocation is respelled.** `--solution MyRestaurant.slnx` and
  `--project tests/…csproj` instead of bare paths; `--output Detailed` instead of
  `--logger "console;verbosity=normal"`; `-- --report-xunit-trx` instead of `--logger "trx"`. CI's artifact
  paths widen to `**/TestResults/**/*.trx`, because where a report lands is now the platform's decision
  rather than one flag's.
- **`README.md`** explains why a path needs an option in front of it, since that is the one change a reader
  meets without being told, and names the filter switches `dotnet test -?` now offers.

## The verb (Stage 3a)

`ResequenceMenuSectionsAsync` takes the **whole ordering** and assigns `0…n-1` from it. Everything else
follows from that one decision:

- **Why not an absolute write per heading.** `ReorderMenuSectionAsync` already sets an absolute
  `display_order`, and positions are deliberately permitted to be equal with a name tie-break. Two headings
  sharing a number have an order nobody assigned, so no single absolute write expresses "move this one up",
  and a pairwise swap would have to decide what happens when the two numbers are equal. Taking the whole
  ordering leaves nothing to decide.
- **The lock is `FOR UPDATE` ordered by identifier**, and the order is the point: PostgreSQL locks rows as
  the plan produces them, so two administrators resequencing at the same moment take them in the same
  sequence and one waits rather than the two deadlocking half way through each other's set.
- **One event per heading that actually moved.** The no-op rule the other verbs follow, applied per row:
  three headings reversed leaves the middle one where it was and writes two events, not three.
- **A list that is not a permutation is refused whole.** Short, repeating, or naming a heading the table
  does not hold are one answer — `MenuSectionSetChanged` — because from the write's side they are one fact:
  the list does not describe this menu. Partially obeying a stale ordering would leave a menu order nobody
  chose.
- **The events of one call share an instant**, so they read in the order the rows were written *only
  because* §8.1 requires the identifier factory to ascend inside a millisecond. That is F-95, fixed in
  Slice 45, and it is why this verb waited rather than shipping beside its own dependency.

The surface is `/administration/menu`. Up and Down at the foot of each heading's group, each its own
static-SSR form named from the heading's identifier, posting the list the page is already rendering with
two entries exchanged. The ends are **disabled rather than omitted**: a control that vanishes at the edge of
a list moves every other control up a row on the next render, and §16.3 scenario 16 measures where controls
are. The editor keeps its absolute-position field, which is a different question rather than a duplicate —
somebody who wants breakfast at 0 and does not care what else moves is stating an absolute.

**F-93's rule is obeyed on the way in for the first time.** That finding was a barrier that keeps *visiting*
a surface and stops *measuring* it when the surface's vocabulary changes. The group action row acquired a
new kind of control — two submit buttons where there was one link — so `HandheldReach` gains
`.menu-group-actions button` in the same slice, not the slice after.

**No CSS.** `.menu-group-actions .button-secondary` has styled that row since Slice 44 and a `<button>`
matches the same rule, so the buttons are 44px tall and full width on a handset by declarations that
already existed. The wide layout stacks the three controls, each on its own line, because a `<form>` is a
block: usable, honest, and recorded here as a deliberate non-change rather than discovered later. Making
them a row is a rule in `app.css` and a slice that has a reason to open that file.

## What was verified

- **The four assertions of `TestRunnerContractTests` were run by hand, in Python, against this tree** — all
  four pass — **and against the pre-fix state, where all four fail**: the `test` stanza removed, both
  adapters restored to a project, `OutputType` dropped, and the two old command lines put back. That is
  this project's sensitivity requirement met for every assertion rather than for the convenient ones.
- **The gate caught a defect in itself before packaging.** Its package scan first matched the bare package
  name and reported two findings on a correct tree: the comments this slice added to the four projects name
  both prohibited packages in order to explain their deletion. It now requires the `Include` attribute, on
  the standard F-67 arrived at — *declared, not merely mentioned* — and that comment is now the proof it
  does not fire on prose.
- **`TestingSectionContractTests` was simulated in full** against the edited specification: 23 counted
  classes, no unresolvable citation, no ambiguous paragraph, no disagreement. The floor moves to 23 in the
  same slice.
- **`SpecificationVersionTests` was simulated**: this document's header is v1.32, the newest changelog
  entry is v1.32, entries descend, and `REQUIREMENTS.md` is untouched and still consistent.
- **Markdown table shape** was checked on both new Appendix A rows and the new ledger row: four cells each,
  no unescaped pipe.
- **Structural checks on every edited C# and Razor file**: string-aware brace, paren and bracket balance; a
  Razor tag-tree walk on the rewritten component; Razor comment balance; and an orphaned-doc-comment scan,
  which caught a real defect — a blank line left between two `<para>` blocks, which is CS1587 and therefore
  an error under `ContinuousIntegrationBuild`.
- **One unverifiable claim was removed before packaging.** A comment first said NSubstitute 6.0.0 "was
  current on 2026-08-17". Nothing in this session checked that. It now says the pin is unchanged and
  unverified by this slice, with the date it was last checked by hand.

## What was NOT verified

**Nothing was compiled and no test was run.** There is no .NET SDK in the authoring environment and the
package feeds are unreachable from it. Per §18 an uncompiled archive is a prediction: build it before
believing anything above.

**`xunit.v3` 4.0.0 was not restored.** The release notes and the two Microsoft references were read; what
the package's dependency graph actually resolves to on your machine was not. If `--report-xunit-trx` is
rejected with exit code 5, drop that flag and the `--` before it from both CI steps: the report is an
artifact upload, not a gate, and nothing else depends on it.

**MTP's zero-tests exit code (8) was not exercised.** The end-to-end project reports 17 *skipped* tests
without `MYRESTAURANT_E2E`, and skipped tests are reported tests, so the solution-wide run should not trip
it. If it ever does, `--ignore-exit-code 8` on that one step is the documented remedy — but check first,
because "no tests ran" on a project that has 17 is a finding rather than a nuisance.

**No Blazor form was rendered.** Two forms per heading with per-heading `@formname` values is the documented
multi-form pattern for static SSR, and this page now has 2N of them. What is untested is the N: if a POST
lands on the wrong handler, every heading would move the same one.

**The 375px barrier was not run.** `.menu-group-actions button` is asserted to be measured, not measured.
The buttons inherit `.button-secondary`'s `min-height: var(--touch-target)`, which scenario 16 has been
passing on since Slice 34 — but that is an argument, not a measurement.

**The resequence was never executed against PostgreSQL.** In particular the `FOR UPDATE … ORDER BY` locking
order is a documented property of how PostgreSQL produces rows, asserted here by reading rather than by two
concurrent transactions.

## Test count

1166 predicted and 1166 observed last slice. This slice adds, as uncompiled arithmetic:

- `TestRunnerContractTests` — **4**
- `MenuSectionResequenceTests` — **8**
- `MenuWiringTests` — **2**

**1166 + 14 = 1180.** Any other number is the first thing to investigate (§18). If it reads 1180 and a
*documentation* gate is red, look at §16.4's census first: the floor moves 21 → 23 in the same slice as the
two paragraphs that raise it, so a mistake there fails twice, once as the floor and once as a count.

## Still open

**The context dump reduction.** Specified in `_CHANGES.md` and deferred by name. Measured composition:
`TECHNICAL_SPECIFICATION.md` 445 KiB of which Appendix A is 139 KiB and the changelog 64 KiB,
`DOCUMENTATION_REVIEW.md` 227 KiB, `BUILD_PROGRESS.md` 124 KiB. Every remaining cut is a split of a history
register that four gates read, which is a slice of its own on the same reasoning Slice 46 used.

**A section's own description under its heading on the guest menu.** Unchanged, and still the largest
remaining piece of Stage 3.

**The kitchen's "86" panel still groups by nothing.** Stage 3's last surface.

**Reordering items within a heading.** The same design against `menu_item`, and now the only remaining
ordering hole. It is a second slice because it writes to a different event table with different paired
CHECKs.

**The wide layout stacks a heading's three controls.** New, and deliberately not fixed here: it is a rule
in `app.css`, and this slice had no other reason to open that file.

**The handheld barrier visits neither section surface.** Carried.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Eleventh slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a fourteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-third consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 48 — the rule that caught its own documentation, and the ordering verb one register down

## Read this first: Slice 47 was green on the suite, the count matched exactly, and the governance gate was red

`total: 1180, failed: 0, succeeded: 1180` on `dotnet test` with `MYRESTAURANT_E2E` set, and `total: 17` on
the separate scenario run. The predicted count was 1180 and the run returned 1180, so §18's arithmetic had
nothing to chase for the second slice running.

**`scripts/check_repository.sh` failed, and it was not a flake:**

```
3. no document asserts a repository setting
   FAIL: docs/TECHNICAL_SPECIFICATION.md:1335 asserts a repository setting it cannot check
repository governance FAILED: 1 problem(s) in the tree. Nothing was modified.
```

One line, one gate, and the whole of the finding. It is repaired first in this entry because it was red on
arrival rather than caused by anything here.

## Two changes in one archive, on the ruling Slice 47 established

The rule Slices 45 and 46 deferred a verb under is about *indistinguishable* symptoms: one change, one green
run, then the feature. These two cannot be confused. A prose defect fails as a named line number out of a
grep gate with no test involved and nothing built. A verb defect fails as a named assertion in one of two
files. So a red run answers its own first question — *which gate went red?* — and the answer partitions the
archive.

## The gate (F-98)

Gate 3 of `scripts/check_repository.sh` is the F-42 rule made unrepeatable. It greps every tracked file that
is not a named record file for a short list of claims about GitHub settings, on the distinction that a
document may state **policy**, which is true wherever it is read, and must not state **platform state**,
which nothing in this repository can verify.

Slice 46 added §16.4's paragraph on `ContextDumpExclusionContractTests`, and that paragraph had to explain
why the archived build log is on the exempt list. It explained it by **reproducing the forbidden claim
verbatim** — a short quotation, in service of an accurate point, inside the one document in this tree that
is normative about the rule being quoted. So the specification asserted a repository setting it cannot
check, and the governance gate failed for a sentence whose subject was that very gate.

**The gate was right on every count. The finding is entirely in the prose**, which is what makes it worth a
row rather than a silent correction. The general shape:

> A paragraph documenting why a forbidden string is permitted somewhere is the paragraph most likely to
> contain that string. A gate over authored text is tripped by its own documentation before it is tripped by
> a defect.

Nothing else in the tree reads for that phrasing, so two slices of otherwise-green runs did not see it.

**What changed:** the clause now describes the claim instead of quoting it, and says what the general hazard
is. `docs/DOCUMENTATION_REVIEW.md` gains the row and the status line.

**Adding `docs/TECHNICAL_SPECIFICATION.md` to `RECORD_FILES` was considered and rejected.** It is the largest
non-record file in the tree — 449 KiB of normative prose — and widening an exemption to accommodate one
clause is precisely F-46's argument: a rule stated as a rule and enforced as a list of exceptions is
enforced as a list of exceptions. The exempt list is for files whose *job* is recording what this tree used
to say. The specification's job is saying what it does say.

**No new gate**, on F-47 and F-71. The existing gate caught this on the first run after the sentence landed,
which is a gate working. A second gate asserting that gate 3's subject does not describe itself is a
monument.

## The verb (Stage 3b)

Slice 47 shipped whole-list reordering for **headings** and named the item-level mirror as out of scope and
as the next ordering slice. This is that slice.

`ResequenceMenuItemsAsync(menuSectionIdentifier, orderedMenuItemIdentifiers, actorPersonIdentifier, …)`
assigns `0…n-1` within one heading, writes one `reordered` event per item whose position actually changed,
and refuses a non-permutation whole with `MenuItemSetChanged`. Outcomes are `Resequenced` / `NoChange` /
`MenuItemSetChanged`, the same three shapes the section verb returns.

**Why it was a second slice rather than a widening of the first.** The design is identical and the table is
not. `menu_item_event` has five named paired CHECKs where `menu_section_event` has three, and a verb is a
write to a table rather than an idea about ordering. Saying so in Slice 47 and then doing it here is cheaper
than discovering it while editing one file to serve two tables.

**Three things the design did not settle, settled in the writing.**

**1. The heading is a parameter rather than inferred from the list.** A position is a position *within* a
section (§7), so the set being reordered is one heading's items. Deriving the heading from the first item's
row would work and would be worse: a caller that assembled a list spanning two headings would get a silent
partial answer instead of a refusal, and the whole point of taking a whole ordering is that there is nothing
left to infer. Sending the whole menu is the other alternative, and it asks the write to renumber the
puddings because somebody moved a drink.

**2. An unknown heading returns `MenuItemSetChanged`, through the ordinary permutation comparison.** There is
deliberately no fourth outcome for it. An unknown heading has no items under it, so any non-empty list
against it fails the permutation test on the same line every other refusal fails on. And from the surface's
side the two are one fact — *this page is stale, reload it* — so a distinction the caller cannot act on
differently is a distinction not worth returning. That is the same ruling Slice 47 made about three shapes
of refusal collapsing to one outcome.

There is a fact for it, because "no rows came back" is also what an empty heading looks like and the two
agreeing should be a decision on the record rather than something a reader has to reconstruct.

**3. The section row is deliberately not locked, and the argument is arithmetic.** This is the one
substantive difference from the section verb, and it took the longest to be sure of.

A concurrent create or refile appends into this heading at `MAX(display_order) + 1`, computed from the very
positions the resequence is holding `FOR UPDATE`. If those are `n` rows whose maximum is `m`, then
`m ≥ n - 1`, so the arrival lands at `m + 1 ≥ n` — strictly after every position a resequence of those `n`
rows can assign. Which is *exactly* the append those two verbs promise. So the interleaving is correct with
no lock on the section at all.

And taking none is worth more than the lock would be: this verb takes item locks and nothing else, where
`MoveMenuItemToSectionAsync` takes an item lock and then a section lock. A section lock here would invert
that nesting and make the deadlock question live for the first time in this file. The item rows are locked
**ordered by identifier**, on the rule the section verb established, so two concurrent resequences cannot
deadlock half way through each other's set.

**What is deliberately not asserted:** the interleaving above. Two transactions racing is a property of a
scheduler, and a test that happened to pass on one ordering would be F-41's shape rather than evidence. The
argument is in the code, in §7, and here.

## The surface

Each item row's actions cell gains **Up** and **Down** beside its existing **Manage** link — the same three
controls a heading's group carries, one register down. Each is its own static-SSR form named from the
*item's* identifier, so a sixty-dish menu has a hundred and twenty distinct form names and Blazor routes
each POST to the row that owns it. The ends of each heading's list are **disabled rather than omitted**, on
the rule the group's row already follows: a control that vanishes at the edge of a list moves every other
control up a row on the next render, and §16.3 scenario 16 measures where controls are.

The list exchanged is the one that heading's loop is already rendering — `IMenuDirectory`'s six-key order
filtered to the heading, which is what makes the filter rather than a `GroupBy` load-bearing a second time.
Nothing is computed from a position.

Three new flash sentences, because the three outcomes are different things to be told and two of them are
ordinary events on a shared menu rather than errors.

## F-93 needed no edit, and that is the finding rather than the relief

`.record-actions button` has been in the 375px barrier's selector since the barrier was written. It matched
**nothing** until this slice: every index's actions cell held a link and only a link, so the `button` half
was a selector waiting for a submit control nobody had written. The item rows are the first to render one.

So the obligation F-93 imposes — a surface acquiring a new *kind* of control acquires a selector in the same
slice — was discharged by a selector added years of slices early. The uncomfortable part is that **a
selector matching nothing is indistinguishable from a selector matching everything it should**, and nothing
in the harness could have said which of the two this was. What makes it safe rather than lucky is that
`.menu-group-actions button` was already asserting the same claim on the same page, from Slice 47. The
barrier's comment now records all of this.

`MinimumControlsMeasured` is a floor, so more controls can only satisfy it further. It does not move.

## In passing

One xUnit analyzer warning cleared: `MenuSectionResequenceTests.cs(249,39): xUnit2031`, a `Where` clause
before `Assert.Single` where the filtering overload belongs. The analyzer is right about the reason — the
overload names the subject in the failure message where a pre-filtered empty sequence cannot.

## Test count arithmetic

Uncompiled, per §18. **1180 → 1190.**

| Where | Assertions |
| --- | --- |
| `MenuItemResequenceTests` (new) | 8 |
| `MenuWiringTests` | 2 |
| **Total added** | **10** |

Any deviation from 1190 is the first thing to investigate.

## What was NOT verified

**Nothing was compiled or run.** This archive is a prediction until `dotnet build` says otherwise, which is
the habit F-71 bought. What *was* done: a string-aware brace and bracket balance over every edited C# file;
a Razor tag-tree walk over `AdministrationMenu.razor` with generic type arguments and code islands excluded;
CS4007 and CS1620 scans; every constructor and helper signature the new test file calls checked against the
tree; a `SpecificationVersionTests` simulation; a `TestingSectionContractTests` simulation that resolved
every cited class and compared every stated count; a `MarkdownTableContractTests` simulation over every
tracked Markdown file; and byte hygiene.

**The census delta rather than the census.** `MinimumCountedClasses` moves 23 → 24 on the arithmetic that
exactly one §16.4 paragraph citing a class with a count was added. The absolute number was not independently
recomputed by the same code the gate uses, so if the floor is wrong it is wrong by the amount that
arithmetic is wrong.

**No browser saw the new controls.** §16.3's scenario 17 is not extended in this slice, so nothing asserts
end to end that an item moves within its heading through a browser. That is a real gap and it is the
obvious next end-to-end step; it is not here because the barrier already measures these controls and a
scenario extension is a separate kind of change.

**The lock-free interleaving is argued, not tested.** See above.

**Whether `.record-actions button` renders at the touch-target height on a handset.** The barrier will now
measure it, which is the point; nothing in the authoring environment can observe the answer in advance.

## Carried

**The wide layout stacks a heading's three controls, and now an item's three too.** The `<form>` is a block
element and `app.css` has no rule for a row of them. Carried, and it is now on two registers rather than
one, which makes it slightly more worth fixing than it was.

**The dump reduction.** Specified in `_CHANGES.md` and deferred again by name: both remaining cuts are
splits of history registers that four gates read, and this slice already edits two of those registers. It
is the obvious Slice 49.

**§16.3 has no scenario for either resequencing verb.** New, and named above.

**The handheld barrier visits neither section surface.** Carried.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Twelfth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a fifteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-fourth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 49 — the arithmetic a test got wrong about a tree that was right, and the sentence a guest could finally read

## Read this first: Slice 48 ran, the count matched exactly, and one assertion was red

**1190 predicted, 1190 observed, one failure.** §18's habit produced its cleanest result yet: the arithmetic
was exact, so the single red assertion had nowhere to hide and no second candidate to be confused with. The
end-to-end suite passed all seventeen scenarios against real browsers, twice — Debug and Release — and the
web-application and domain projects passed in a second each.

The failure was `MenuItemResequenceTests.ResequencingOneHeadingLeavesTheOtherHeadingAlone`:
`Assert.Equal() Failure: Expected: 2, Actual: 3`.

**Actual 3 was correct.** That is the whole of the finding, and it is why this entry opens with it rather
than with the fix.

## The arithmetic (F-99)

The fact arranges three drinks at 0, 1, 2 through `ThreeItemsAsync` and resequences them to
`[cola, tea, coffee]`. That is a **rotation**: cola 2 → 0, tea 0 → 1, coffee 1 → 2. Every one of the three
moves, so the verb writes three `reordered` events, which is exactly what §7 specifies — one event per item
whose position actually changed.

**The 2 came from forty lines up.** `OnlyTheItemsThatMovedGetAnEvent` resequences to `[cola, coffee, tea]`,
which is a **reversal**: it leaves coffee at 1 and writes two. The list came from a third fact,
`ResequencingAssignsPositionsFromThePlaceInTheList`, which rotates on purpose. So the new fact was assembled
out of two correct facts, took the arrangement from one and the count from the other, and was wrong about a
tree that was right.

**Nothing under `src/` was wrong, and that is the part worth keeping.** The verb, the `WHERE` clause, the
permutation test and Slice 45's UUIDv7 monotonicity fix are all vindicated by this run rather than implicated
in it — the isolation claim the fact exists for passed on every assertion that carries it (`Assert.Empty` on
trifle and on sorbet, `[0, 1]` on their stored positions). The uncomfortable half is stated rather than
enjoyed: **one named assertion printing two numbers is precisely what a real off-by-one in that verb's
`WHERE` clause would have looked like**, so the symptom shape gave no help at all in deciding which of the
two it was. What decided it was reading the arrangement.

### The repair, and what it deliberately does not do

The count becomes **3**, and the arithmetic goes into the fact's own summary rather than being left for the
next reader to re-derive: a rotation of three moves three, a reversal moves two, and this fact wants the
rotation. That last part is a ruling rather than an accident — this fact is about a write not reaching past
its heading, and the write with the most chances to reach past it is the one that touches **every** row under
it. A reversal writes two of three and never touches the row at the end of the heading's run.

**What the rotation costs is recorded in the same place.** Three moved of three listed means this total
cannot also witness the per-row no-op rule: an implementation writing one event per *listed* item would
satisfy it. That rule stays where a reversal can see it, which is `OnlyTheItemsThatMovedGetAnEvent`, and the
summary now says so and points there.

**The alternative repair is named because it is defensible.** Changing the list to `[cola, coffee, tea]` and
keeping the 2 would have let this one fact carry both properties at once. It was refused for the reason
above, and reversing that decision is a two-token edit — swap the list, restore the 2, delete the two
paragraphs of summary that explain the 3.

**No new gate**, on F-47 and F-71. The suite named the fact, the file, the line and both numbers on the first
run after the fact landed. A gate over the arithmetic *inside* an assertion is the assertion.

**The residual is general and is not closed.** A fact assembled by copying a sibling inherits that sibling's
**arrangement** along with its numbers, and once either is edited the borrowing is invisible. That is F-84's
mechanism moved out of the arrangement and into the assertion, and nothing in this tree can see it.

## The menu progress: a heading's own description, on the guest's phone

This closes **the last outstanding piece of Stage 3's guest menu**, named in the plan and carried unchanged
through nine slices' *Still open* sections. §11.1 now renders a heading's description beneath its name, and a
heading with none renders **no paragraph** rather than an empty one — `''` is what §7 stores for *none*, and
an empty box is indistinguishable from a surface that failed to load, which is the confusion §11.10's
`data-loaded` bit exists one level up to prevent.

### The route taken, which reverses a sentence four places carried

The plan named both routes and deferred rather than guessing: *"showing it needs either a second read or a
widened record."* Four places in the tree had already answered — §7, `MenuWorkflow`, `MenuWiringTests` and the
section editor's own lede all said §11.1 renders a heading's name and not its description *because the
grouping is built from `MenuItemSummary`, which carries the one and not the other* — and
`TableOrderSurface`'s render record went further: *"A surface that needed the section's own description would
read the directory rather than widen this."*

**The record is widened, and the argument is correctness rather than cost.** Two reads happen at two
instants. A heading renamed between them renders its **new name above its old sentence**, and there is no
lock a guest's picker could sensibly take to prevent that — the guest surface is not in a transaction and
should not be. One row of one query cannot disagree with itself. `MenuSectionDescription` is one more aliased
column on the INNER JOIN that has carried `MenuSectionName` since `0005`, for the same reason that one was
joined: a heading edited once reads under its new text everywhere at once.

The cost is that a heading's sentence is repeated on every item row under it. That is already true of the
name, it is what a denormalised read model is, and the walk takes the value from the first row of each run,
so the copies are read once each and never compared.

**To revert:** drop the member from `MenuItemSummary`, `MenuItemRow`, the SQL alias list, `ToSummary`,
`MenuSectionOnTheMenu` and `OrderStagingTests.Item`, and read `IMenuSectionDirectory.ListAsync` beside the
menu instead.

### The publish needed no edit, and that is Slice 40's ruling paying out

`DescribeMenuSectionAsync` has broadcast `MenuChanged` since the day it was written, when it reached no guest
surface at all. The argument then was that `MenuChanged` means *re-read the menu* and nothing else, and that a
workflow deciding which columns were worth announcing would have to be edited the moment a surface started
reading one. **This is that moment, and neither the workflow nor its wiring fact changed.** A tree that had
made the publish conditional would have shipped a menu showing the new sentence to whoever reloaded and the
old one to every phone already looking at it.

Three prose sites and one lede are corrected instead, which is the whole of the paperwork that ruling cost.

### Two rulings on the surface

**No `aria-describedby` on the list.** It is the more precise ARIA and it was refused for a concrete reason:
expressing *no description, no attribute* needs an attribute whose value is null, which this tree has no
precedent for, so the honest alternative was rendering the `<ul>` twice. What ships instead puts the sentence
between the heading and the list in document order, which is where a screen reader meets it either way.

**No `text-transform`.** The heading above it declares one, and F-88 is the finding that a harness reading
transformed text cannot tell a stored name from a rendering of it. The new harness read uses `TextContent`
pre-emptively for the same reason — a reader that would start lying if a stylesheet gained a line is worth
writing the safe way the first time.

**No new CSS vocabulary.** `.order-menu-section-description` declares the same three properties
`.menu-group-description` already carries on the administration index, because it is the same sentence read
by a different person, and a second opinion about how a description looks would be a second vocabulary.

### Scenario 17 needed no new arrangement, which is the pleasant part

It has created *Starters* **with** a description and *Puddings* **without** one since Slice 40 — the
description was an inline literal nothing asserted on. Step (c2) names it and asserts both halves of the rule
from what was already there: the sentence arrives under its own heading, and the heading with nothing to say
renders no paragraph. It is now the only place in the project where `menu_section.description` is carried
from the form that typed it to the phone that reads it, which is what step (d) does one register down for the
item's own description.

## What was verified

Nothing was compiled and nothing ran. What was done:

- **Tree reconstruction against two independent sources.** `dump.txt` parsed to 353 file records and every
  one of the 353 SHA-256 hashes matched the tree fetched from the remote at the sibling commit. Zero
  mismatches, zero missing.
- **The Razor tag tree, by before-and-after diff rather than by absolute walk.** The first instrument
  reported faults in *untouched control files*, which is how it was known to be the broken party; replacing
  it with a diff of the tag-event stream — quote-aware, comments and XML doc comments stripped, line numbers
  deliberately discarded — showed exactly one balanced `<p>` inserted between `</h4>` and `<ul>` in
  `TableOrderSurface.razor` and an identical stream for `ManageMenuSection.razor`, whose edit is prose.
- **String-aware brace and paren balance**, zero delta on all eight edited C# files.
- **A `TestingSectionContractTests` simulation** resolving every cited class against the tree and comparing
  every stated count: 24 counted classes against a floor of 24, zero disagreements.
- **Every construction site of the widened records**, found by search rather than by memory: two for
  `MenuSectionOnTheMenu` and exactly one positional site for `MenuItemSummary`. No `with` expression and no
  object initialiser exists for either, which is what makes CS7036 the good failure here.
- **`TreatWarningsAsErrors` under CI**, which is why step (c2) is two array assertions rather than one tuple
  comparison — tuple element nullability differences are a warning, and a warning is an error in CI.

## Test count arithmetic

Uncompiled, per §18. **1190 → 1191.**

| Where | Assertions |
| --- | --- |
| `MenuDirectoryTests` | 1 |
| **Total added** | **1** |

The resequence fix changes an assertion inside an existing fact, so it moves no count; scenario 17 is
extended rather than added, so §16.3 stays at seventeen. Any deviation from 1191 is the first thing to
investigate.

## What was NOT verified

**No browser rendered the paragraph.** `ReadMenuSectionDescriptionsAsync` is a new harness read and scenario
17's step (c2) is its only caller, so the likeliest site of a red first run is a locator that finds nothing —
`p.order-menu-section-description` inside `div.order-menu-section`. It fails as a length mismatch naming
`null` where the sentence should be, which is distinguishable from the assertion above it failing.

**No database answered the new column.** `MenuDirectoryTests.List_CarriesEachHeadingsOwnDescription_OnEveryItemUnderIt`
is the first read of `menu_section.description` through `IMenuDirectory`. If Dapper's constructor binding
disagrees with the alias, it fails naming the parameter.

**Whether the paragraph looks right under the uppercase heading.** Nothing in the authoring environment can
render 375px.

**The census was not recomputed, only argued unchanged.** No test class is added, so `MinimumCountedClasses`
does not move — and unlike Slice 48 that claim was checked by the simulation rather than by arithmetic alone.

## Carried

**The wide layout stacks each row's three controls.** The `<form>` is a block element and `app.css` has no
rule for a row of them. Carried on two registers.

**§16.3 has no scenario for either resequencing verb.** Carried, and it is now the largest end-to-end gap in
the menu: the barrier measures those controls and nothing presses them.

**The dump reduction.** Specified in `_CHANGES.md` and deferred again by name; both remaining cuts split
history registers that four gates read, and this slice edits two of those registers.

**The kitchen 86 panel does not group by heading.** Carried, and with the guest menu now complete it is the
last surface that reads the menu flat.

**The handheld barrier visits neither section surface.** Carried.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-99 is that residual arriving in a third form, an *arithmetic* written beside an assertion.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Thirteenth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a sixteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-fifth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 50 — the last surface that read the menu flat, and the rule that had nowhere to be tested

## Read this first: Slice 49 was green, the count matched exactly, and nothing is outstanding

**1191 predicted, 1191 observed, zero failures.** §18's arithmetic matched to the digit for the second
consecutive slice, and this time there was no red assertion beside it to explain. The end-to-end suite
passed all seventeen scenarios against real browsers **three times** — the Debug suite, the Release suite
under `scripts/ci_local.sh --with-all --with-e2e`, and a third standalone Debug run — and every local CI
gate reported passing.

So this slice opens with nothing to chase, which has happened rarely enough to say plainly. The only
`Error:` lines anywhere in the log are the two `run.sh --containers-only` prints about a Caddy container
that does not exist yet, which is a carried item rather than a regression.

That matters for what follows. **This slice is one change**, and it did not need v1.32's
distinguishable-failure argument to justify riding beside a second one.

## The finding: a rule with nowhere to be tested (F-100)

`GroupedMenu` was a **private property inside `TableOrderSurface.razor`**, and it had been since Slice 40.
What it implements is not incidental: §11.1's grouping of the guest menu, **and** the pair of rules §7
restates every single time it mentions either, because both are easy to lose and they point opposite ways
one sentence apart —

- an inactive **item** stays on the menu, marked, unorderable: *"the guest sees that the salmon exists and
  is out, rather than watching it silently vanish"*;
- an inactive **heading** is not rendered to the guest at all.

§16.1 records that this repository has no bUnit. So for ten slices the only thing in this project asserting
any of that was §16.3 scenario 17 — which needs a browser, a database and two and a half minutes, and which
asserts it incidentally, on the way to asserting something else.

**The tree had already written the rule down, three times, and this was the one place not following it.**
`KitchenQueue`'s own summary is the sentence that governs the case: *a rule that can only be checked by
rendering a Razor component is a rule nobody checks* — and it names `OrderStaging` and `OrderNarrative` as
the two others that sit outside their components for exactly that reason. Three pure functions exist
because of this argument. The fourth was inside a component.

### What made it a defect rather than a preference

This is the half worth keeping, because "extract it for testability" is a preference and this is not that.

**§11.2's "86" panel needs the same walk with the opposite rule about hidden headings, and a private
property cannot be called from a second component.** So the only route to grouping that panel, with the
tree as it stood, was to paste the walk into `KitchenBoard.razor` — one walk, two copies, two sets of §7
rules that would then drift independently. That is **F-59's mechanism exactly**: one paste, four times,
across four pages nobody had decided about, and nothing able to see it.

### The second, smaller half, found on the way in

The walk's own summary said it took each heading's name and description **from the first row of each run**.
It assigned both inside the loop body, on every iteration, so it took them from the **last**.

Nothing in this application could ever have failed on that. `MenuItemSummary` joins both columns from one
`menu_section` row through the INNER JOIN that has carried `MenuSectionName` since `0005`, so every row of
a run carries byte-identical values and the two readings cannot disagree. **Which is precisely why no test
could falsify the claim** — it is F-99's residual arriving in its fourth form, a claim written beside a
computation that no gate reaches.

F-77's habit is to delete such a claim rather than correct it. Here the cheaper direction is available and
is taken instead: the assignment moves to where a run begins, which costs one `if`, makes the sentence
true, and puts the assignment in the only place a reader would look for it.

## What shipped

`MenuGrouping` is the fourth member of the set, and `MenuHeadingGroup` replaces the component-private
`MenuSectionOnTheMenu`.

**Two named entry points rather than one with a flag**, and that is a ruling. `MenuGrouping.VisibleToGuests`
drops hidden headings; `MenuGrouping.EveryHeading` keeps them. A boolean at a call site is a rule nobody
reading the call site can see, and these two rules are §7's asymmetry — the thing a reader of either
surface most needs to know without opening another file. The names state the rule rather than the caller,
so a second guest-facing surface does not require this file be renamed.

**The guest surface's behaviour is unchanged by construction, not by inspection.** Its markup tag stream is
identical before and after; the only edit inside the `<div class="order-menu-section">` subtree is the loop
variable's *type name*, which is C# rather than markup. That is a stronger claim than "I checked it looks
right", and it is the reason this slice can carry a surface change and a refactor together.

## The menu progress: the kitchen's 86 panel, grouped

**This was the last surface in the application that read the menu flat.** The guest's picker has been
grouped since Slice 40 and the administrator's index since Slice 44; a cook was still scrolling one
undivided list of every dish in the building looking for the one that just ran out. §11.2 is now normative
about it.

### Hidden headings are listed and marked, which is required rather than permitted

The obvious implementation is to reuse the guest's rule, and it is wrong. §7: **deactivating a heading does
not deactivate its items** — their `is_active` is untouched, and switching the heading back on brings the
menu back exactly as it was, because cascading the flag would silently rewrite every item's availability
and lose which of them the kitchen had 86'd.

**This panel is the only surface in the application that can read or change those flags.** Drop the hidden
headings from it and §7's non-cascade rule becomes unmanageable in practice: a cook cannot 86 the eggs they
will need the moment breakfast is switched back on, and cannot bring back something 86'd last week. So the
heading is **chipped rather than dropped** — *Hidden from guests*, the consequence rather than the flag,
which is the wording §11.4's index and the section editor both already use. It is the same move the guest
surface makes one register down for an item.

### Three smaller rulings on the panel

**No per-heading toggle.** Switching a heading off is a decision about what guests can see and belongs to
§11.4's section editor. Putting it here would offer a cook the control that empties a quarter of the menu
next to the control that removes one dish, and §7 is explicit that the two are different requests.

**The heading's own description is deliberately not rendered.** The record carries it — §11.1 needs it —
and *"served until 11am"* is a sentence for a guest choosing, not for a cook counting. A stock list wants
to be short.

**No `app.css` edit and no `.menu-group` name.** The panel's two new rules are component-local, which is
this file's standing arrangement and is legitimate because `.kitchen-` is deliberately **absent** from
`HandheldLayoutContractTests`' `SharedSelectorPrefixes` — the list that says which vocabulary the
stylesheet owns. Reaching for `.menu-group*` would have been the F-66 defect: a page-local rule sharing a
shared name wins from later in the document at the same specificity and the stylesheet loses in silence.
A cook's group and an administrator's group are also not the same shape — one is a run of touch targets,
the other a `<details>` holding a table.

## Two facts nothing else in this project could hold

Worth naming, because "the unit test is faster" would be a weak argument on its own.

**The first-row reading.** The fact hands the walk two rows that **disagree about their own heading's
name** — an arrangement the INNER JOIN makes impossible through `IMenuDirectory`. That is exactly why no
integration fact and no scenario can distinguish reading a run's first row from reading its last, and it is
why the wrong reading survived ten slices under a comment asserting the right one. The arrangement is
deliberately impossible rather than merely unusual, and the fact's summary says so — because it is the kind
of thing a later reader repairs by mistake.

**§7's asymmetry as an asymmetry.** One input, both doors, and the **difference** between the two answers
compared against the hidden heading. Asserting either door alone says very little: a heading missing from
the guest's answer has several possible causes, and a heading present in the kitchen's has none. It is the
disagreement that is the test — the same shape scenario 17's closing step uses one register up, where three
groups on the administrator's index and two groupings on the guest's menu must differ by exactly the empty
heading. An implementation dropping the hidden heading from **both** lists, or from neither, fails here
rather than passing half a rule.

## What was verified

Nothing was compiled and nothing ran. What was done:

- **Tree reconstruction.** `dump.txt` parsed to 353 file records; 351 of the 352 written matched their
  SHA-256 exactly. The one mismatch is `LICENSE`, which the dump elides to metadata and hash by design
  (Slice 46), so it is expected rather than a fault. Zero unexplained mismatches.
- **The Razor tag tree, by before-and-after diff**, on the method Slice 49 recorded rather than the
  absolute walk that slice found to be the broken party. A second pristine extraction served as the
  control: `AdministrationMenu.razor`, untouched, came back **0 changed events and 0 faults**, so the
  instrument was trustworthy before it was believed. `KitchenBoard.razor` shows exactly one balanced
  `<div>` wrapping a balanced `<h3>` containing a balanced `<span>`, inserted between `</p>` and `<ul>`
  and closing after `</ul>`, and nothing else moved. **`TableOrderSurface.razor` is 247 → 247 markup
  events, zero delta.**
- **String-aware brace, paren and bracket balance**, zero on both new C# files.
- **A `TestingSectionContractTests` simulation**: **25 counted classes against a floor of 25**, zero
  disagreements, zero ambiguous paragraphs, zero unresolvable citations, and no duplicate test file names
  anywhere under `tests/`.
- **A `MarkdownTableContractTests` simulation**: 33 table runs across the documentation, **0 problems**.
- **A `HandheldLayoutContractTests` simulation**, four facts of it: 14 component `<style>` blocks against
  a floor of 8 with **zero shared-vocabulary re-declarations** — `.kitchen-menu-group` correctly does not
  trip the `.menu-group` prefix, since prefix matching is on the *start* of a simple selector; 12 custom
  properties read and **0 undeclared**; **0 colour literals** in the new CSS; and still exactly one
  `min-width: 48rem` in the tree.
- **A `RazorDirectiveContractTests` simulation**: 51 components against a floor of 20, **0 collisions**
  with `@section` or `@RenderSection`.
- **The version gate and the platform-state gate**, both simulated: header 1.35 against a newest entry of
  1.35, two versioned documents against a floor of two, and **no forbidden platform-state phrasing** in
  any non-record file this slice touches.
- **Tree hygiene on every touched file**: LF endings, exactly one final newline, no whitespace-only line,
  no dump separator.

## Test count arithmetic

Uncompiled, per §18. **1191 → 1202.**

| Where | Assertions |
| --- | --- |
| `MenuGroupingTests` | 11 |
| **Total added** | **11** |

No test is removed and none moves file. §16.3 stays at seventeen — no scenario is added or extended. §16.4
gains one paragraph, so the counted-class census and its enforced floor both move 24 → 25. **Any deviation
from 1202 is the first thing to investigate.**

## What was NOT verified

**No browser rendered the grouped panel.** `/kitchen` has no §16.3 scenario at all — the board's alert
state, its queue and its 86 panel are asserted by unit tests over pure functions and by integration tests
over the writes, and nothing drives the surface. So the likeliest red is not a test: it is the panel
looking wrong. Nothing in the authoring environment can render 375px, and the new `<h3>` sits inside a
`<section>` whose `font-size` is 1.05rem by deliberate choice.

**Whether the uppercase heading reads well above the rows.** `.kitchen-menu-group-name` declares
`text-transform: uppercase` and `--ink-soft`, matching `.kitchen-menu-state` beside it rather than the
guest menu's `.order-menu-section-name`. That is a judgement, it is reversible in one declaration, and it
is the thing to look at first on a real screen.

**The chip inside an `<h3>`.** `.chip-warn` is app.css's and is consumed here, which is allowed and which
this file already does with `.chip-ok` fifty lines up. What is unverified is whether a chip baseline-aligns
acceptably inside a heading that also declares `letter-spacing` — the flex container should handle it, and
no engine has been asked.

**Whether `MenuGrouping`'s two names read as well at the call sites as they do in the file.** That is a
prose judgement about somebody else's future reading, and the reversion is mechanical: collapse the two
methods into one taking a boolean, and the two call sites each gain an argument.

## Carried

**§16.3 has no scenario for either resequencing verb.** Carried, and it is now unambiguously the largest
end-to-end gap in the menu: scenario 16's barrier measures those controls and nothing presses them.

**`/kitchen` has no §16.3 scenario at all.** Stated as a carried item for the first time rather than left
implicit, because this slice changed that surface and could not assert the change through a browser. It is
the largest end-to-end gap in the *application*, as distinct from in the menu.

**The wide layout stacks each row's three controls.** The `<form>` is a block element and `app.css` has no
rule for a row of them. Carried on two registers.

**The handheld barrier visits neither section surface.** Carried.

**The dump reduction.** Specified in `_CHANGES.md` and deferred again by name; both remaining cuts split
history registers that four gates read.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-100's second half is that residual arriving in a fourth form, a *claim about which row was read* written
beside the loop that read it. The repair made this instance true and gated it; the class is untouched.

**A fact assembled by copying a sibling inherits that sibling's arrangement along with its numbers.**
F-99's residual, carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Fourteenth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a seventeenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-sixth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

# M6 Slice 51 — the picture a menu could not carry, and three columns a plan had already got wrong

## Read this first: Slice 50 was green, the count matched exactly, and nothing is outstanding

**1202 predicted, 1202 observed, zero failures.** §18's arithmetic matched to the digit for the third
consecutive slice. The end-to-end suite passed all seventeen scenarios against real browsers **three
times** — the Debug suite, the Release suite under `scripts/ci_local.sh --with-all --with-e2e`, and a
standalone Debug run — and every local CI gate reported passing.

The only `Error:` lines anywhere in the log are the two `run.sh --containers-only` prints about a Caddy
container that does not exist yet, which is a carried item rather than a regression.

**One correction to the record, and it belongs at the top because it is about this log rather than about the
tree.** The session that authored this slice arrived believing the project was at Slice 46 and predicting
1166 tests. The tree said Slice 50 and 1202. Nothing was lost — the reconstruction from `dump.txt` is what
settled it, 353 of 355 file records matching their SHA-256 exactly with the two exceptions being `export.sh`
(excluded by design) and `LICENSE` (elided since Slice 46) — but it is worth writing down that the
authoritative account of where this project is, is this file and the terminal log, and that a session's own
sense of it is not evidence.

## The finding: a schema about to be created out of an unchecked sketch (F-101)

Stage 4 of `docs/MENU_AND_HANDHELD_PLAN.md` has carried a DDL sketch for `menu_item_image` since Slice 30.
Three of its columns were wrong, and they were wrong in two different ways.

`byte_length integer NOT NULL CHECK (byte_length BETWEEN 1 AND 524288)` **is** `octet_length(bytes)`. One
fact written twice, in a table where a single `UPDATE` can separate them, and where the copy every read
would select is the one that can be false. That is **F-65's mechanism met for the seventh time** — F-48 a
version header against its own changelog, F-50 a variable four documents agreed about, F-56 a port three
helpers dialled, F-65 a touch target written as a literal eight pixels short, F-89 a census in three places,
F-94 an index counting one thing and saying another.

`pixel_width` and `pixel_height` are a worse shape, and the argument against them is in the same stage's own
prose. It says there is no free-libre .NET imaging library available to this stack for this use, and that the
server therefore *"validates and stores what it is given"*. Nothing in this tree can open an image. So
neither number could ever have come from anywhere but the uploading browser's word — **recorded as a column,
in the indicative, beside columns the database actually knows.** A later reader has no way to tell the five
apart.

### What makes it a finding rather than a refinement

**Three gates read that document and none of them reads a fenced SQL block for meaning.**
`MarkdownTableContractTests` reads it for table structure, `SpecificationVersionTests` for version
agreement, `scripts/check_tree.sh` for hygiene. So a DDL sketch in a plan is **authored prose carrying the
authority of a schema and none of the checking** — and its destination is uniquely unforgiving, because DbUp
journals by script name and an applied migration is therefore never edited (**F-34**). The slice that copies
a sketch into `Migrations/` is the last moment the sketch is free to be wrong.

It was found by reading the sketch in order to implement it, which is **F-93's timing arriving a second
time**: caught in the slice that would have caused it, rather than in the slice after.

### The repair, and where it stops

All three columns are dropped **before `0006` was authored**, and each reason is written into §7 and into the
script rather than left as an absence a later reader might helpfully repair. `new_byte_length` **is** kept on
`menu_item_image_event`, and the asymmetry is stated as the point rather than left to look like an
inconsistency: after a removal the bytes are gone, so the log is the only place that number can live at all.

The dimensions are refused with the general form recorded beside them — *a number nothing in the tree can
verify is a worse artefact than an absent column* — and `alt_text` is named next to it as the caption that
**can** honestly be added later, by one `ALTER` with a `DEFAULT ''`, on `0004`'s precedent.

**No gate is added over the plan's SQL blocks**, on F-41 and F-47. A document that sketches a schema *in
order to argue about it* legitimately contains shapes the tree does not have — Stage 4's sketch also argues
against two alternatives it never built — so a gate comparing them would report findings on a correct
document. The residual is stated instead: a fenced code block in a design document is unchecked prose, and
nothing mechanically prevents the next one.

## The menu progress: a picture, in the schema

**Stage 4a.** `0006_menu_item_images.sql` adds `menu_item_image` and `menu_item_image_event` and touches
nothing that already existed, which is `0003`'s cut applied a second time — so every read, every write,
every integration fact and all seventeen §16.3 scenarios mean exactly what they meant before, **green by
construction rather than by inspection**. `OrderTestWorld` needed no edit at all, because
`TRUNCATE … CASCADE` on `menu_item` reaches both new tables.

### The storage decision, which is ADR-0015 and is the reason to decide now

`bytea` in PostgreSQL rather than a volume of files, and the argument is **F-38's**. §15 *defines* a recovery
set as exactly two artefacts and `scripts/restore_drill.sh` rehearses both on every push. A third artefact
means editing that definition, `backup.sh`, `restore.sh`, the drill and the runbook — after which an operator
who takes one more backup the old way holds a set that restores, cleanly and quietly, an application whose
menu has no pictures in it. Object storage is refused one register further out, on R§1's self-hosted premise.

**The direction of reversibility is what settles it rather than the cost.** `bytea` → volume is a migration
that reads rows and writes files. Volume → `bytea` is a migration that cannot find the files, because by then
some have moved and nothing ever knew which. Choosing the reversible direction is the whole reason to choose
before there is data.

**It pays out immediately, in a file that is not in this archive.** `OPERATIONS.md`, both scripts and the
drill are untouched, because the recovery set is still two artefacts. A volume would have meant editing five
files whose subject is getting a restaurant's data back.

### Four schema rulings, each of them a thing a later reader would otherwise repair by mistake

**One image per item is `UNIQUE` on the referencing column**, not a `bytea` on `menu_item`. A picture is
replaced far more often than a dish is renamed, and a column on the item would put the images inside every
menu read §11.1 and §11.4 perform. It also makes a gallery a later migration that drops the `UNIQUE` and adds
a position, rather than a redesign.

**A replace mints a new `menu_item_image_identifier` and deletes the old row.** §7's route is
`GET /menu/image/{menu_item_image_identifier}`, not `…/{menu_item_identifier}`, so the URL changes when the
picture does and `Cache-Control: public, max-age=31536000, immutable` is a **true statement**. Keying on the
item would buy an `ETag` and a revalidation round trip per image per page load, on phones, forever, to avoid
a cost paid once per upload.

**A removal deletes the row, and that is a stated exception to §6.8's hide-never-delete rule.** That rule
exists so history is never orphaned; here the history is in the log and the bytes are not history — the
`removed` event names which picture it was and the `attached` or `replaced` event before it records the
format and the size. Keeping the bytes would grow §15's recovery set by up to half a megabyte for every
photograph anybody ever retook, for no reader.

**`menu_item_image_event` references `menu_item` and not `menu_item_image`**, naming the image as a bare
`uuid` with no key. This is the **opposite** of `0005`'s ruling about `new_menu_section_identifier`, and it is
opposite for a reason: there the identifier is a pointer §11.4 renders, and a dangling one renders as a
blank; here the row it names is gone by design, so a real key could only forbid the deletion or cascade the
history away with the bytes.

### The one addition to the sketch rather than a subtraction

**The declared media type is checked against the bytes' own signature.** A `Content-Type` on an upload is the
client's claim about its own file, and §7's route hands the stored column straight back out as a response
header on this application's origin — so a column that disagreed with its bytes would make this program
mislabel its own responses. `MyRestaurant.Domain.Menu.ImageFormat` reads the opening bytes and no more.

It is in `Domain` on **F-100's** argument, one slice after that finding: the subject is a pure function of a
byte span and the cases worth asserting are the malformed ones, each of which behind an `INSERT` would cost a
container and arrive as a constraint name instead of a sentence. **Both halves of WebP's RIFF header are
required**, because `RIFF` alone is also an AVI and a WAV, and a check that stopped there would accept an
audio file as a picture.

**The media-type vocabulary is therefore declared twice, which is F-80's shape, and the agreement is gated
behaviourally rather than textually.** F-80's repair read the SQL text and compared two lists. This is
stronger: a real file of every format the domain can identify is attached and the database must accept it, so
the two agreeing on paper while nothing can actually be stored is *also* a failure. The reverse direction
needs no assertion — a type the CHECK admits and the domain cannot identify is a type no caller can produce
bytes for, because the write refuses the pair before it opens a transaction.

### The cap is the database's, and nothing in C# says how large

§8.2 declares `menu_item_image_bytes_within_cap`. `DapperMenuItemImageAdministration` catches the check
violation, compares the constraint's **name**, and answers `BytesOverCap`; **no number appears in C# at
all.** A second copy would be F-65's mechanism, and worse it would be the belt that hides the buckle — F-64,
F-69 and F-75 are each an instance of a redundant check making the first one's absence invisible.

Two constraints rather than one bounded `BETWEEN`, because an operator who chose an empty file and one whose
phone produced four megabytes need different sentences, and the constraint name is what carries the
difference back up. The empty case is refused in C# before the transaction opens, because zero is a
definition rather than a policy number — and it is refused *first*, so a zero-byte file is not reported as a
PNG that is not a PNG.

## Two test classes, and why they are two

**`ImageFormatTests`, eight assertions, no container.** The RIFF fact is the one to read: every other fact in
that file passes on an implementation that checks four bytes and stops. One fact is the non-vacuity guard and
does more than guard (F-41) — it asserts that every member of `RecognisedContentTypes` is a type **some bytes
actually produce**, so a media type added to that list with no signature behind it fails there.

**`MenuItemImageTests`, eleven assertions, real PostgreSQL.** Its own class rather than facts on
`MenuAdministrationTests`, for a structural reason: every verb over there writes one row and one event, so
*the newest event for this item* is unambiguous and every helper is built on it. These two verbs **delete** a
row, so that shape does not hold.

Two of the eleven could not have been written any other way. One is the behavioural vocabulary gate above.
The other **asks the database for its own cap** through `pg_get_constraintdef`, then attaches one byte over it
and exactly it — so the bound is never written in this file, and a migration that moves the cap moves the
test with it instead of turning it red.

## What was verified

Nothing was compiled and nothing ran. What was done:

- **Tree reconstruction.** `dump.txt` parsed to 355 file records; 353 of 355 matched their SHA-256 exactly.
  The two mismatches are `export.sh`, which the dump excludes and reproduces only in its self-documentation
  section, and `LICENSE`, which the dump elides to metadata and hash by design (Slice 46). Zero unexplained
  mismatches.
- **String-aware brace, paren and bracket balance**, zero on all three new C# files and on the three edited
  ones.
- **SQL statement balance on `0006`**: parenthesis depth returns to zero at each `;`, three `CREATE` verbs,
  no dollar-quoted block at all — which is what naming every constraint bought (F-78's collision cannot
  recur in a script that has no `DO`).
- **A `TestingSectionContractTests` simulation**: **27 counted classes against a floor of 27**, zero
  ambiguous paragraphs, zero unresolvable citations, no duplicate test file names anywhere under `tests/`.
  **It reported one disagreement and that is the part worth recording**: §16.4 said *seven assertions* for
  `ImageFormatTests` and the file holds eight — the declared-versus-actual fact was written last and the
  paragraph was not moved. That is precisely **F-70's** shape, in the section written to stop it, caught by
  simulating the gate rather than by re-reading the prose. The count is eight and the arithmetic below moves
  with it.
- **A `MarkdownTableContractTests` simulation**: table runs across the documentation, 0 problems, including
  the two new Appendix A rows and the new ledger row.
- **The version gate**: header 1.36 against a newest changelog entry of 1.36, two versioned documents against
  a floor of two.
- **The platform-state gate**: no forbidden phrasing in any non-record file this slice touches.
- **Tree hygiene on every touched and new file**: LF endings, exactly one final newline, no whitespace-only
  line, no run of twenty or more `#` on a line of its own.

## Test count arithmetic

Uncompiled, per §18. **1202 → 1223.**

| Where | Assertions |
| --- | --- |
| `ImageFormatTests` | 8 |
| `MenuItemImageTests` | 11 |
| `SchemaMigrationRunnerTests` theory rows | 2 |
| **Total added** | **21** |

No test is removed and none moves file. §16.3 stays at seventeen — no scenario is added or extended. §16.4
gains three paragraphs and two counted classes, so the census and its enforced floor both move 25 → 27.
`SchemaMigrationRunnerTests`' own `[Fact]`/`[Theory]` count stays at **7**, because a theory row is not an
attribute — which is exactly the distinction F-90 was about, and the reason its §16.4 count does not move
while the suite total does. **Any deviation from 1223 is the first thing to investigate.**

## What was NOT verified

**Nothing was compiled and nothing ran.** This archive is a prediction until `dotnet build` says otherwise.

**No `bytea` round trip was performed.** `TheContentReadBackIsByteIdenticalToWhatWasStored` is the fact that
proves Dapper and Npgsql hand a `byte[]` parameter and a `bytea` column back unchanged, and no database was
available to run it. The likeliest failure in this archive is a parameter type: `byte[]` was chosen over
`ReadOnlyMemory<byte>` deliberately for that reason, being the mapping Npgsql has always had.

**Whether `PostgresException.ConstraintName` is populated for a check violation.** The cap outcome depends on
it. PostgreSQL sends the constraint name in the error fields for `23514` and Npgsql surfaces it, and any
*other* check violation is rethrown by design — so if that field arrives empty, the symptom is a thrown
`PostgresException` in `BytesOverTheSchemasCapAreRefusedWithNothingWritten` rather than a wrong answer
anywhere else. That is the second thing to look at on a red run.

**Whether `regexp_match(pg_get_constraintdef(…), '([0-9]+)')` finds the cap.** It relies on the rendered CHECK
containing exactly one run of digits. `CHECK ((octet_length(bytes) <= 524288))` does, and `octet_length` has
no digits in it — but the rendering is PostgreSQL's and no server was asked. A wrong answer there fails the
fact's own guard, which asserts the value is greater than a twelve-byte PNG before using it.

**Whether a private nested record can be a Dapper generic argument across a class boundary.**
`MenuItemImageTests.ImageEvent` is passed to `OrderTestWorld.QueryAsync<T>`. `DapperMenuSectionEventLog`
proves private nested records bind, but not from another type — Dapper emits its deserialiser with visibility
checks skipped, so this should hold, and no runtime confirmed it.

**Whether the collection expressions targeting `ReadOnlySpan<byte>` compile as written.**
`ImageFormat.IdentifyContentType([.. PngPrefix, 0x00])` and the `params` spread in `Riff` are C# 12 shapes
this tree has not used before. If either is refused it is a compiler error naming the line, which is the
cheapest kind of red.

## Carried

**No surface reads or writes a picture, which re-opens the obligation Slice 43 closed.** Named here for the
first time and to be named every slice until Stage 4b discharges it. It is the weaker form: nothing is added
behind `IMenuWorkflow`, so no surface can change a picture without announcing it for the reason that no
surface can change one at all.

**How a file upload reaches a static-SSR page is not settled.** §11.4's pages are static SSR with form posts;
`InputFile` needs an interactive render mode and `[SupplyParameterFromForm]` does not bind a file. Stage 4b
chooses between a plain `<form enctype="multipart/form-data">` posting to a minimal API endpoint and making
one page interactive. **This was not foreseen in the plan's Stage 4 text**, and it is the reason the stage was
cut at the schema rather than shipped whole.

**Whether a browser downscales before upload.** A phone camera produces four megabytes against a 512 KiB
cap, so without it the answer to most uploads is *too large*. It changes no schema and it decides whether
this feature is usable by the person who asked for it.

**§11.11 needs no edit and that is carried to be asserted rather than assumed.** `default-src 'self'`
declares no `img-src`, so bytes served from this origin are already covered — and because a CSP is the one
configuration that becomes wrong by editing a file it does not mention (F-49),
`ContentSecurityPolicyContractTests` gains the fact in the slice that adds the route.

**§16.3 has no scenario for either resequencing verb.** Carried, and still the largest end-to-end gap in the
menu: scenario 16's barrier measures those controls and nothing presses them.

**`/kitchen` has no §16.3 scenario at all.** Carried — the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls.** The `<form>` is a block element and `app.css` has no
rule for a row of them. Carried on two registers.

**The handheld barrier visits neither section surface.** Carried.

**The dump reduction.** Specified in `_CHANGES.md` and deferred again by name; both remaining cuts split
history registers that four gates read, and this slice adds a table to one of them.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-101 is that class arriving in a fifth form, a *column* written beside a computation in a document no gate
reads for meaning.

**A fact assembled by copying a sibling inherits that sibling's arrangement along with its numbers.** F-99's
residual, carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Fifteenth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred an eighteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-seventh consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

# M6 Slice 52 — the transport question that had a third answer, and a count of seven that said six

## Read this first: Slice 51 was green, the count matched exactly, and nothing is outstanding

**1223 predicted, 1223 observed, zero failures.** §18's arithmetic matched to the digit for the fourth
consecutive slice. The end-to-end suite passed all seventeen scenarios against real browsers twice — the
Debug suite and the Release suite under `scripts/ci_local.sh --with-all --with-e2e` — and every local CI
gate reported passing.

The only `Error:` lines anywhere in the log are the two `run.sh --containers-only` prints about a Caddy
container that does not exist yet, which is a carried item rather than a regression.

**A note about where this project is, because it went wrong once already.** The session that authored
Slice 51 arrived believing the tree was at Slice 46 and predicting 1166 tests, and it was at Slice 50 and
1202. The reconstruction from `dump.txt` is what settles this every time: 360 file records, 359 matching
their SHA-256 exactly, the one exception being `LICENSE`, which the dump elides to metadata and hash by
design. **This is Slice 52.**

## The stage: Stage 4b, and the open question was a real one

Slice 51 shipped `menu_item_image`, `menu_item_image_event`, `ImageFormat`, and two data-access services
with **no caller outside their integration tests**. It said so, in four places, and named the obligation it
was re-opening. This discharges it.

It also named one thing as a genuinely open design question rather than a deferral, and that is the part of
this slice worth reading.

### The transport: the two candidates, and the answer that was neither

§11.4's pages are static SSR. `[SupplyParameterFromForm]` does not bind a file, and `InputFile` needs an
interactive render mode. The plan named two ways out.

**A minimal API endpoint** beside `AccountEndpoints`, taking a multipart post. The cost is not the code —
it is that the endpoint acquires an **authorization rule of its own**, which then has to agree with
`ManageMenuItem`'s `[Authorize(Policy = Administration)]`. Two places that can disagree about who may change
a menu is exactly the shape §3.7 exists to prevent, and the way it goes wrong is a policy added to one and
not the other by somebody who did not know there were two.

**Making the page interactive.** A circuit under §11.4's largest form surface, in order to move one file —
and it would make this the only administration page whose forms behave differently from every other one's,
so the next person editing any of the six forms already on it has to know which kind of page they are in.

**Neither was taken.** A plain `enctype="multipart/form-data"` form posts to **the page itself** under an
ordinary `@formname`, and the handler reads the part back out of `HttpContext.Request.Form.Files`.

**The reason that costs nothing is the part worth keeping.** Blazor's static form handling has already read
the request body — that is how it found `_handler` and dispatched to this callback rather than to one of the
other six. So `Request.Form` is a cached collection by the time the handler runs, and the request the model
binder declined to bind one field of is sitting right there. The page stays static SSR, antiforgery stays
the framework's job, post/redirect/get is unchanged, and the authorization rule stays in one place.

**What is given up is model binding for exactly one field**, and that is the field the model binder refuses.

### The route

`GET /menu/image/{menu_item_image_identifier}`, a minimal-API endpoint rather than a page, because
everything a component endpoint does — render a layout, apply the obligations pipeline, negotiate a circuit
— is wrong for a response whose body is a `bytea` and whose `Content-Type` comes out of a column.

**Anonymous**, and that is a decision rather than an oversight. §11.1's guest menu is the surface this
exists for, and §4.3 puts registration at the moment of joining a table — so a guest reading a menu may have
no session at all. A picture of a dish is also what a menu is *for*: it is the thing a restaurant prints.
The key is a UUIDv7 rather than a filename, so nothing about the URL enumerates a menu.

**It carries no §3.5 obligations exemption, and the distinction from the two that do is worth stating.**
The clock and the source offer are asked for *by* a page a locked-down principal is looking at. This is a
**subresource** of a page such a principal was redirected away from before it rendered. An exemption would
therefore protect nothing and would widen the set of paths that answer during a forced password change.

**`Cache-Control: public, max-age=31536000, immutable`**, and it is a true statement rather than a hope,
because ADR-0015's second decision keys the route on the image: a replace mints a new identifier and deletes
the old row, so the address changes exactly when the bytes do.

### The two workflow verbs, and how the publish is keyed

Attach and remove come behind `IMenuWorkflow` and publish `MenuChanged` on a written row. **The publish is
keyed on the two outcomes that wrote a row rather than on "not a refusal"**, and that is not a style
preference: `AttachMenuItemImageOutcome`'s refusal set has grown twice already, and keying on the negative
would make a future member an announcement by default — a menu-wide re-query for an upload that was
rejected.

**Why publish at all, when no guest surface renders a picture?** Because `MenuChanged` means *re-read the
menu* and nothing else (§9), and this file has already settled that bet once: the section description
published for nine slices before §11.1 rendered it, and when §11.1 did, neither the workflow nor its wiring
test needed an edit. §11.4's own item page reads the picture today, so the publish is not even speculative.

### No number was added anywhere, and that was the hard part

The obvious thing to write in the handler is a size check. It is not there.

§8.2 declares the cap in a named CHECK, `DapperMenuItemImageAdministration` catches the violation and
compares the constraint's **name**, and a second copy in C# would be F-65's mechanism — and worse, the belt
that hides the buckle, which F-64, F-69 and F-75 are each an instance of.

**The question that makes this non-trivial is what bounds the buffer.** Reading an upload into a `byte[]`
in order to have the database refuse it is an allocation an untrusted request chose the size of. The answer
is that **it needs no new bound at all**: Kestrel's request-body limit already bounds every POST this
application accepts, on every form, today, and no form here raises it. So the picture form declares no
transport ceiling because it inherits one, and there is still exactly one number about image size in the
tree.

### The declared media type is the browser's, and the surface deliberately does not improve on it

`ImageFormat.IdentifyContentType` is public. The page could read the bytes, name the format itself, and
never produce `UnsupportedContentType` or `ContentTypeContradictedByBytes` at all.

**That is precisely the reason not to.** The write service is the one place that decides what an image is,
and a surface that pre-judged would leave two of that verb's outcomes unreachable from the only form that
can produce them — which is the same defect this project keeps recording about verbs with no caller, one
register in. So the browser's `Content-Type` is handed on unaltered and the refusal message **names what
the browser sent**, so the failure is diagnosable rather than mysterious.

The residual is carried honestly: an operating system with no extension mapping sends
`application/octet-stream` for a genuine PNG and gets *"not a picture format this menu serves"*. The fix if
it ever bites is one line.

## The finding: an enum that counted itself and got it wrong (F-102)

`AttachMenuItemImageOutcome`'s summary opened *"**Six answers** rather than a boolean, and every one of them
is a different sentence for the person who chose the file."*

The enum has **seven** members. They begin three lines below that sentence.

**The sentence saying six is the sentence explaining why each one matters** — that an operator who cannot
tell a file too large from a file that is not an image tries the same file again. So the paragraph arguing
that no answer may be collapsed had collapsed one by miscounting.

It is **deleted rather than corrected**, on F-77's standing ruling, and the row is earned by the shape
rather than by the arithmetic. This is that ruling's **sixth form** — after a version header disagreeing
with its own changelog (F-48), a variable four documents agreed about (F-50), a port three helpers dialled
(F-56), a touch target written eight pixels short (F-65), a class census in three places (F-89), and an
index counting one thing while saying another (F-94). **A census in prose is wrong at the moment it is
written or at the moment the thing it counts changes, and nothing in between can tell which.**

Found by reading the type in order to write the surface that renders one sentence per member, which is
**F-93's timing for the third time**: caught in the slice that would have consumed it rather than the slice
after.

**No gate is added**, on F-41 and F-47. A rule forbidding a number near an enum would report findings on
every correct comment that mentions one. The residual is the one this log already carries — nothing can see
a count written in a comment — and what shrinks it here is a side effect rather than a repair: the new
handler switches over those outcomes, so a member with no sentence is now a missing `case`.

## The one CSS rule that is not a presentational choice

`.manage-picture-image { max-width: 100%; height: auto; }`.

§7 stores what it is given and nothing in this stack can resize an image, so the intrinsic width of that
element is whatever somebody's camera produced. **Without the constraint a 3000px photograph makes the
document wider than a 375px viewport, and §16.3 scenario 16 fails on a page whose every control is
correctly placed.** That is the kind of failure that gets diagnosed as a control problem for an hour.

It is `.manage-` rather than a `.picture-` prefix of its own, so the vocabulary is inside the set
`HandheldLayoutContractTests` already forbids a component from redeclaring — from its first day rather than
from the slice somebody notices. **No test file was edited to make that true**, which is the point of
choosing an existing prefix.

The form is `.manage-inline-form` rather than a `.form-field` block for the same class of reason: the 375px
barrier reaches `.manage-inline-form button` and does not reach `.form-actions button`, so this is F-93's
rule — a surface acquiring a control acquires the selector in the same slice — obeyed by putting the control
under a selector that was already right.

## The assertion Slice 51 promised, and the one that would actually fail

Slice 51 carried this by name: *"§11.11 needs no edit and that is carried to be asserted rather than
assumed."* `ContentSecurityPolicyContractTests` now carries it, in two halves.

That `img-src` admits `'self'` is stable and will not fail. **That every `<img>` in the tree is still
same-origin is the half that would**, because a CDN, an object store or a thumbnail service is exactly the
shape somebody reaches for when a menu grows pictures — and `NoResourceElementNamesAnAbsoluteUrl` already
forbids it tree-wide, so this one exists to make the failure *say which feature it is about*.

## The new contract test, and why it is its own class

`MenuItemImageSurfaceContractTests`, **six assertions**, no container.

Separate from `MenuWiringTests` because that file asserts what the workflow does with an upload once it has
one, and every claim here is about whether an upload ever reaches it. **All six guard one failure mode**:
the form renders, the button submits, the page redirects, and the file is simply not there. Nothing throws,
nothing logs, no other test goes red, and the operator's only symptom is that every picture they choose
comes back reported as empty.

Three of them are about one string being written in one place — the input's `name`, which
`Request.Form.Files` indexes by; the `accept` list, which is the media-type vocabulary's **third**
declaration after §8.2's CHECK and `ImageFormat.RecognisedContentTypes` (F-80's shape); and the thumbnail's
address. In all three the markup is asserted to **reference the constant** rather than to contain the value,
because the value is what drifts.

**The `accept` one is the copy with no server-side symptom whatsoever.** An `accept` attribute refuses
nothing — a drifted one just hides the file somebody wants from the picker, and everything else in the
application keeps working perfectly.

**The sixth is the longest-lived bug this feature can have.** A route pattern re-keyed on the *item* would
still route, still return a picture, and would then serve last week's photograph out of every browser cache
in the building **for a year**, because `immutable` means the browser will not even ask.

## What was verified

Nothing was compiled and nothing ran. What was done:

- **Tree reconstruction.** `dump.txt` parsed to 360 file records; **359 of 360 matched their SHA-256
  exactly**. The one mismatch is `LICENSE`, which the dump elides to metadata and hash by design (Slice 46).
  Zero unexplained mismatches.
- **String-aware brace, paren and bracket balance**: zero on the two new C# files and on every edited C# and
  Razor file.
- **A Razor tag-tree walk** over `ManageMenuItem.razor`: every element opened is closed, the two new
  `<form>` elements are siblings rather than nested, and the `<figure>` block balances.
- **The CSP contract test's own scan, simulated** against the edited tree: one `data:` URL (the favicon,
  unchanged), the new `<img src>` classified as same-origin, no inline `<script>`, no `on*` attribute
  introduced — `@onsubmit` is preceded by `@` rather than by whitespace, which is what that scan
  distinguishes on.
- **A `TestingSectionContractTests` simulation**: **28 counted classes against a floor of 28**, zero
  ambiguous paragraphs, zero unresolvable citations, no duplicate test file names anywhere under `tests/`.
  `MenuItemImageSurfaceContractTests.cs` and the existing `MenuItemImageTests.cs` are deliberately different
  names for that reason.
- **A `MarkdownTableContractTests` simulation**: table runs across the documentation, 0 problems, including
  the two new Appendix A rows.
- **The version gate**: header 1.37 against a newest changelog entry of 1.37, two versioned documents against
  a floor of two.
- **A CSS vocabulary check**: the three new selectors are `.manage-` prefixed, declared once, in `app.css`
  and in no component; every custom property they read is declared in `:root`; no colour literal.
- **The platform-state gate**: no forbidden phrasing in any non-record file this slice touches.
- **Tree hygiene on every touched and new file**: LF endings, exactly one final newline, no whitespace-only
  line, no run of twenty or more `#` on a line of its own.

## Test count arithmetic

Uncompiled, per §18. **1223 → 1233.**

| Where | Assertions |
| --- | --- |
| `MenuItemImageSurfaceContractTests` | 6 |
| `MenuWiringTests` | 3 |
| `ContentSecurityPolicyContractTests` | 1 |
| **Total added** | **10** |

No test is removed and none moves file. §16.3 stays at seventeen — no scenario is added or extended. §16.4
gains one paragraph and one counted class, so the enforced floor moves 27 → 28. **Any deviation from 1233 is
the first thing to investigate.**

## What was NOT verified

**Nothing was compiled and nothing ran.** This archive is a prediction until `dotnet build` says otherwise.

**Whether Blazor's static form handling dispatches a `multipart/form-data` post.** This is the load-bearing
assumption of the whole transport decision. The reasoning is that `_handler` is an ordinary form field and
`HttpContext.Request.Form` reads multipart bodies, so the dispatch sees what it always sees — but no request
was made. **If it is wrong the symptom is unmistakable**: the handler never runs, the page re-renders with
no flash and no error, and nothing is written. That is the first thing to check on a red or a silent run,
and the fallback is the minimal API endpoint the plan named, at the cost of a second authorization rule.

**Whether `<AntiforgeryToken />` inside a multipart form validates.** It renders the same hidden field it
renders in every other form on the page, and the framework validates form posts to component endpoints
regardless of encoding. If it does not, the symptom is a 400 rather than a wrong answer.

**Whether `Results.Bytes` leaves the `Cache-Control` header alone.** It is set on the response before the
result executes. A result writes the body and the content headers; nothing observed says it clears others.
A wrong answer here is a picture that is served correctly and re-fetched more often than it needs to be.

**Whether `HttpContext.Request.Form.Files[name]` returns null or throws for an absent part.** The handler
treats null as an empty upload and reaches `BytesEmpty`. If the indexer throws instead, it is an unhandled
exception on a form submitted with nothing chosen — which is the second thing to check.

**Whether `using MemoryStream buffer = new(); using Stream content = file.OpenReadStream();` inside an `if`
block compiles without an analyzer warning under `TreatWarningsAsErrors` in Release.** If it does not, it is
a compiler message naming the line, which is the cheapest kind of red.

**Whether the file input renders acceptably at 375px inside `.manage-inline-form`.** That class sets
`width: 100%` and `min-height: var(--touch-target)` on `input`, which a file input inherits — but a file
input's internal button is the browser's and is not styled by anything here. §16.3 scenario 16 measures the
`button`, not the input, so a cramped file control would pass the barrier and look wrong.

## Carried

**§11.1 renders no picture, which is the half of this feature that was actually asked for.** Stage 4c, and
it is two decisions about a 375px screen rather than about bytes: a thumbnail beside the name rather than a
hero above it, and an `alt_text` column, because a picture on a guest's card may say something its name does
not.

**`IMenuItemImageDirectory.ListAsync` has no caller.** It is §11.1's. Named on the same rule that named the
write and weaker than it — an unread read cannot change anything without telling anybody.

**No §16.3 scenario touches a picture.** A picture scenario needs a fixture image the harness has no way to
produce, and inventing bytes inside the harness would be a test arranging the thing it asserts about.
Carried, and it is now the largest end-to-end gap in the menu after the two resequencing verbs.

**A browser that sends `application/octet-stream` for a genuine PNG is refused.** The message names what the
browser sent. Carried with the fix written down.

**Whether a browser downscales before upload.** A phone camera produces four megabytes against a 512 KiB
cap, so the answer to most uploads is *too large*. It changes no schema. Carried for a third slice, and it
is now the thing that decides whether this feature is usable by the person who asked for it.

**§16.3 has no scenario for either resequencing verb.** Carried: scenario 16's barrier measures those
controls and nothing presses them.

**`/kitchen` has no §16.3 scenario at all.** Carried — the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls.** The `<form>` is a block element and `app.css` has no
rule for a row of them. Carried on two registers.

**The handheld barrier visits neither section surface.** Carried.

**The dump reduction.** Specified in `_CHANGES.md` and deferred again by name.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-102 is that class arriving in a sixth form, a count of an enum's members in the summary of that enum.

**A fact assembled by copying a sibling inherits that sibling's arrangement along with its numbers.** F-99's
residual, carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Sixteenth slice carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a nineteenth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-eighth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 53 — the picture a guest can finally see, and a plan that argued for it wrongly

## Read this first: Slice 52 was green, the count matched exactly, and the session before it was wrong about where the project was

**1233 predicted, 1233 observed, zero failures.** §18's arithmetic has now matched to the digit for five
consecutive slices. Seventeen end-to-end scenarios passed against real browsers twice — the Debug suite and
the Release suite under `scripts/ci_local.sh --with-all --with-e2e` — and every local gate reported passing.
The only `Error:` lines in the log are the two `run.sh --containers-only` prints about a Caddy container that
does not exist yet, which is a carried item rather than a regression.

**And it happened again, which is why this paragraph is here for the second slice running.** The session that
authored *this* slice arrived believing the tree was at **Slice 47** and that `ResequenceMenuSectionsAsync`
was unwritten. It was at Slice 52, and that verb landed in Slice 47 with the item-level one in Slice 48. Six
slices of drift, from a summary of prior work rather than from the tree.

**The reconstruction from `dump.txt` is what settles this, every time, and it is cheap.** 363 file records
parsed, **361 verified against their SHA-256 exactly**; the two exceptions are both by design — `export.sh`
contains the dump delimiter as literal text and is excluded, and `LICENSE` is elided to metadata and hash.
Doing that read *before* authoring anything is the difference between a slice and a fiction. The rule is
already written down for the withheld archive; it holds for the whole tree.

This is **Stage 4c**, plus the finding found while reading the paragraph that specified it.

---

## The stage: §11.1 renders the picture, and the card was re-laid out rather than decorated

`0006` put a picture in the database, Stage 4b put it on the administrator's page and on a route, and the
guest's menu — the half that was actually asked for — showed nothing. `IMenuItemImageDirectory.ListAsync`
had been **a read with no caller** for three slices, named each time on the rule that names an unreachable
write and each time as the weaker case, because an unread read cannot change anything without telling
anybody. It has its caller.

### The thumbnail, and why the crop is the decision rather than the placement

The plan said *a thumbnail beside the name rather than a hero above it* and stopped. The placement is the
easy half: an image per card roughly **doubles** the height of the menu, and at 375px the card grid is
already one column, so doubling card height doubles how far a guest scrolls to compare two dishes.

What the plan did not settle is the size, and there the obvious choice is wrong. **`width: 4rem; height:
auto` defeats the entire re-layout.** Nothing in this stack can resize an image — §7 stores what it is
given, because there is no free-libre .NET imaging library available for this use — so the intrinsic
dimensions of that element are whatever somebody's camera produced. A portrait photograph at `height: auto`
renders twice as tall as it is wide, and the card height is back where it started. So it is a **fixed 4rem
square under `object-fit: cover`**.

**That crops, and the crop is paid for rather than hidden.** The detail panel renders the same picture
**uncropped** — which §11.1 has owed since Slice 39, when it named that panel *"the surface that item
descriptions, and later ratings and images, are read on"*. A guest who wants the whole frame taps the dish.
Reverting the crop is one declaration and the consequence is written beside it in `app.css`.

### `loading` is per heading, and the interesting part is why not per card

`loading="lazy"` on everything after the first heading is what the plan asked for. What is worth recording is
why the cut is not finer: **how many cards sit above the fold depends on how long each description is, how
wide the viewport is, and how large the reader has set their text**, none of which the server knows. A
heading is the coarsest unit that is certainly right at one end — the first heading's cards are what a guest
is looking at when the page arrives, and no card in the second heading is, on any screen §11.12 targets. A
card count would be a number invented here and wrong on somebody's phone.

`eager` is written out rather than left to the default, because the interesting property of that attribute is
that it was *decided*: an omitted attribute reads as an oversight and the next reader could not tell.

### One read, and it is the list read

The pictures are read in the same pass as the menu and re-read on the same `MenuChanged`, because a picture
dictionary loaded once at initialisation would be **a second place for the menu to be stale** — which is
precisely what `GroupedMenu`'s own note refuses one register up. The assertion that guards it is negative:
`FindForItemAsync` must not appear in that component at all. A per-card lookup would render a page that
looks exactly right and gets slower as the restaurant's menu grows, which is a defect with no symptom until
it has one.

---

## The caption: a verb, not a field, and `AttachMenuItemImageAsync`'s signature did not change

The plan called `alt_text` *"one `ALTER` with a `DEFAULT ''` … and a field on the item's picture form"*. The
`ALTER` is right. The field is not, and the reason is concrete rather than aesthetic.

**The upload form requires a file.** So a caption settable only there means that correcting a typo costs a
re-upload: a new `menu_item_image_identifier`, every cached copy of an **unchanged** photograph invalidated
across the building for a year, and a `replaced` event recording a replacement that replaced nothing. The
whole point of keying §7's route on the image was that the URL is a content address; a caption is not
content.

So `0007` adds `alt_text_changed`, `SetMenuItemImageAltTextAsync` writes one `text` column and moves no
identifier, no bytes and not `uploaded_at` — which says when the *picture* arrived, and moving it would make
§11.4's panel report a photograph as newer than it is.

**And the attach carries the caption forward**, from the row it deletes onto the row it writes, with **no
event for the carry**. Both halves have a plausible wrong implementation that leaves a plausible artefact.
Resetting to `''` would strip alternative text off a guest's menu as a side effect of somebody improving a
photograph, and nothing else in the suite would notice; writing an event for the carry would put a row in
§11.4's history claiming a caption moved when it did not.

**The column is on the picture and not on `menu_item`**, which is the ruling that made the carry necessary in
the first place. Alternative text describes a photograph: *"served on a bed of wilted greens with a lemon
wedge"* is true of one picture and false of the next one somebody takes. A column on the item would outlive
the picture it described with nothing able to tell that it had stopped being true; a column on the picture is
deleted with the bytes it belongs to.

### What `0007` did not have to widen

The vocabulary CHECK is dropped and re-added **by name** — two ordinary statements, nothing to query and
nothing to dollar-quote. That is the return `0006` collected by naming every constraint it declared, and the
contrast is `0004`, which had to write a PL/pgSQL loop over `pg_constraint`, a dollar-quoted body, and then
the F-78 fix in the runner's configuration, all because `0001` left four CHECKs unnamed.

**The two existing biconditionals needed no widening at all, and that is the surprising half.** A new event
type on a table with two total equalities would normally need both. `alt_text_changed` needs neither, because
**a caption is not a fact about the file**: it sits outside both right-hand sides and passes each with NULL.

---

## The finding: a plan argued for a column with a sentence that is false (F-103)

The plan's justification for `alt_text` read: *"an `<img>` with no alternative text on a menu is a card a
screen reader renders as nothing."*

**It conflates two different pieces of markup with two different behaviours.** An `<img>` with **no** `alt`
attribute makes a screen reader fall back to announcing the URL — for this feature, a bare UUIDv7, which is
worse than silence. `alt=""` marks an image decorative and is correctly **skipped**.

And §11.1's card is a `<button>` holding the dish's name and its price as text, so the button's accessible
name is already *"Grilled salmon £24.00"* — correct and sufficient. **`""` is therefore the right value for
most pictures on this menu**, and the column earns its place only for the ones that say something a name does
not, which is the narrower claim the same paragraph makes two clauses earlier and which is true.

**This is F-101's mechanism a second time, one register up.** There it was a DDL sketch in a design document
becoming a migration; here it is an *argument* in a design document becoming markup. Three gates read that
file — for structure, for tables, for version — and none of them reads a sentence for whether it is true. So
the slice that implements a paragraph is the last moment its reasoning is free to be wrong. Found while
writing the markup the paragraph specified, which is **F-93's timing** for the fourth time.

**Corrected rather than deleted**, because the cheaper direction was available — F-77's habit, taking the
same turn it took for F-100's first-row claim.

### The row names something executable, and the gate had to be shaped by the defect

`alt` is now **always written**, on every `<img>` in the tree, with whatever is stored — `""` included. The
gate asserts exactly that: every `<img>` under `Components/` carries the attribute, with the tag count as its
own non-vacuity guard (F-41).

**Why that shape rather than an assertion about values.** The *correct* value is usually the empty one, so
the *incorrect* markup — no attribute at all — renders identically on every screen, in every browser, and
would pass any test that looked at output. The only place the difference exists is the source. A second fact
covers the other direction, because a page that hard-coded `alt=""` on the guest's card would also render
identically, also pass the tree-wide gate, and make the whole column unreachable from the only surface it was
added for.

### One consequence nothing above anticipated

**The `<img>` is last in the document and first on the screen.** A button's accessible name is computed from
its contents in document order, so a captioned picture placed first announces its own description *before*
the dish it describes — *"served on a bed of wilted greens, Grilled salmon, £24.00"*. `grid-column` moves it
into the left column instead. Reordering a **non-interactive** element visually is free, because there is no
focus order for the visual order to disagree with, and that is exactly why the same trick would be wrong for
a control.

---

## What was verified

- The tree was reconstructed from `dump.txt` before anything was authored: **363 records, 361 matching
  SHA-256 exactly**, the two exceptions being `export.sh` (excluded; it contains the delimiter) and `LICENSE`
  (elided by design).
- **Razor tag-tree walk on both edited components, against the pristine files re-extracted from the dump.**
  With `@(…)` expressions masked, `ManageMenuItem.razor` is a clean tree — zero unclosed, zero mismatches —
  both before and after. `TableOrderSurface.razor` retains exactly three pre-existing artefacts of a generic
  type in markup, **identical before and after**, so nothing was introduced.
- **§16.4's count gate simulated in full**: 28 counted classes against a floor of 28, no ambiguous
  paragraph, no uncited class, **no disagreement** between a stated count and a file's `[Fact]`/`[Theory]`
  census. The three moved counts were checked against the files, not asserted.
- **The specification version gate simulated**: header `1.38`, newest changelog entry `v1.38`, every entry
  descending; `REQUIREMENTS.md` untouched at rev 6.
- **The Markdown table gate simulated** over all five edited documents: the four new rows carry five pipes
  against a four-column header and contain no pipe inside a code span. The pre-existing discrepancies the
  simulation reports are inline-code pipes in rows this slice did not touch.
- Brace and parenthesis balance on every edited `.cs` and `.css` file, and against the pristine file where a
  naive count was already non-zero (`MenuItemImageSurfaceContractTests.cs` has one unmatched `{` inside a
  string literal, before and after).
- Every implementer of the three changed interfaces was enumerated and updated:
  `DapperMenuItemImageAdministration`, `FakeMenuItemImageAdministration`, `MenuWorkflow`. Nothing constructs
  `MenuItemImageMetadata` positionally outside its own declaration, so the sixth member breaks no caller.
- `Migrations/*.sql` is a glob in the `.csproj`, so `0007` needs no project edit — checked rather than
  assumed.
- The end-to-end harness reads `span.order-menu-name`, `span.order-menu-price` and
  `span.order-menu-description` as **descendants** of `button.order-menu-choice`, and counts
  `dl.order-menu-facts > div`. The new `.order-menu-body` wrapper and the `<img>` before the `<dl>` are
  therefore invisible to scenario 17 — verified by reading the harness, not by inference.
- Every custom property used by the new CSS is already declared in `app.css`'s `:root`.

## Test count arithmetic

Uncompiled, per §18. **1233 → 1242.**

| Class | Was | Now | Why |
|---|---|---|---|
| `MenuItemImageTests` | 11 | 15 | the caption stored without moving the identifier; the no-op and the clearing; the carry across a replace with no event; the two silent refusals |
| `MenuItemImageSurfaceContractTests` | 6 | 10 | the caption form carries no file input; the guest card renders the picture and reads once; every `<img>` carries `alt`; the card's `alt` comes from the column |
| `MenuWiringTests` | 26 | 27 | a caption is announced only when it moved, and arrives verbatim |

§16.4's counted-class floor **stays at 28** — the guest surface joined the existing class rather than
founding a new one, because the route-helper claim is one claim over two files. §16.3 stays at seventeen.
**Any deviation from 1242 is the first thing to investigate after a run.**

## What was NOT verified

- **Nothing was compiled.** No SDK, no database, no browser in the authoring environment. `0007` has never
  run: the `DROP CONSTRAINT … ADD CONSTRAINT` pair, the `DEFAULT ''` on a table whose rows may be half a
  megabyte, and the third biconditional are all unexecuted.
- **The 4rem square has never been rendered**, so whether `object-fit: cover` crops a real photograph
  acceptably is a judgement nobody has made against a real picture on a real 375px screen. It is the one
  thing in this slice most likely to want an opinion after you look at it.
- **No screen reader has read any of this.** The whole F-103 argument is about what a screen reader does with
  `alt=""` versus a missing attribute, and it is reasoned from the accessible-name computation rather than
  observed. The gate asserts the markup, which is the checkable half.
- Whether `Assert.SkipUnless` skips the four new integration facts cleanly where no container engine answers
  — the same as every fact in that file, but unobserved here.

## Carried

**No §16.3 scenario touches a picture.** The seventeen are unchanged. A picture scenario needs a fixture
image the harness has no way to produce, and inventing bytes inside the harness would be a test arranging
what it asserts about. It is now the largest end-to-end gap in the menu after the two resequencing verbs.

**Nothing reads `menu_item_image_event`.** `alt_text_changed` is written from its first day and rendered
nowhere, so §11.4 still cannot say when a picture last changed or who changed it — now four event types deep
rather than three. The panel and its reader arrive together, as `IMenuSectionEventLog` did with the section
editor.

**Whether a browser downscales before upload.** Fourth slice carried, and it has stopped being a nicety: a
phone camera produces four megabytes against a 512 KiB cap, so the answer to most uploads is still *too
large* — and the pictures those uploads would have become are now the feature a guest sees.

**A browser that sends `application/octet-stream` for a genuine PNG is refused.** Carried with the fix
written down.

**F-102 has no row in `DOCUMENTATION_REVIEW.md`.** Slice 52 put it in the status paragraph and in Appendix A
and not in the ledger's own table. F-103 has a row; F-102's absence is named rather than backfilled here,
because reversing a prior slice's filing decision is a decision, not a tidy-up. It is the same shape as the
carried item below it.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Seventeenth slice carried.

**§16.3 has no scenario for either resequencing verb.** Carried: scenario 16's barrier measures those
controls and nothing presses them.

**`/kitchen` has no §16.3 scenario at all.** Carried — the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls.** The `<form>` is a block element and `app.css` has no
rule for a row of them. Carried on two registers.

**The handheld barrier visits neither section surface.** Carried.

**The dump reduction.** Deferred again by name, and it is now overdue: this log has grown by another slice
and `0007` adds a file.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-103 is that class arriving in a seventh form, a claim in a *design document* rather than in a comment.

**A fact assembled by copying a sibling inherits that sibling's arrangement along with its numbers.** F-99's
residual, carried.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twentieth time.

**A CI job that runs the canonical stack on the canonical engine.** Twenty-ninth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 54 — the transition that broke the build, and the history a picture had never had

## Read this first: Slice 53's archive did not compile

```
/home/kushal/src/dotnet/myrestaurant/src/MyRestaurant.WebApplication/Components/Pages/Table/TableOrderSurface.razor(248,22):
error RZ1010: Unexpected "{" after "@" character.
```

One line, one character, and **every project that depends on `MyRestaurant.WebApplication` never ran** —
which means `dotnet test` produced no count, the container build failed at `dotnet publish`, and
`ci_local.sh` stopped at gate 5 with gates 6 onward unreported. That is **F-82's mechanism for the fourth
time**, and this time its cost is exactly nameable rather than general: the two facts that would have
reported F-105 live in the project that did not build.

Everything upstream of the compiler was green, legitimately. Tree hygiene passed on 365 authored files,
repository governance passed, all twelve shell scripts passed `bash -n` and `shellcheck`, `run.sh --smoke`
booted the app against real PostgreSQL and got a 200 from `/healthz/ready`, and the quick tunnel served the
application publicly for three hours. **A Razor syntax error is invisible to every gate this repository has
except the one that compiles.**

The tree was reconstructed from `dump.txt` before anything was authored, as it has been for four consecutive
sessions: **363 file records, 361 verified against their SHA-256 exactly**, the two exceptions by design
(`export.sh` contains the dump delimiter and is excluded from its own verification; `LICENSE` is elided to
metadata and hash). No drift this time — the tree was where the previous session left it, including
`0007_menu_item_image_alt_text.sql`, which had been committed rather than left untracked.

## The defect (F-104)

```razor
else
{
    <p class="order-picker-lede muted">…</p>

    @{ int headingIndex = -1; }        ← RZ1010
```

The `else` opens a **code block**. Razor is parsing C# from that brace onward; the `<p>` element switches to
markup for the duration of the element and switches back. So at the line in question there is no markup to
leave, and `@{` — which is the transition *from markup into code* — is a syntax error. The statement wants
writing bare.

**What earns this a ledger row rather than a one-word correction is that the correct and the incorrect form
are indistinguishable on the line itself.** There are three other `@{` blocks in this tree and all three are
correct:

| File | Encloser | Legal? |
|---|---|---|
| `KitchenBoard.razor:257` | `<section class="kitchen-eighty-six">` | yes — markup context |
| `TableOrderSurface.razor:642` | `<li class="order-party-order">` | yes — markup context |
| `AdministrationMenu.razor:167` | `<div class="menu-group-body">` | yes — markup context |
| `TableOrderSurface.razor:248` | `else {` | **no — already in code** |

Every one of the four is preceded by a closed element at the same indentation. The **nearest enclosing
construct** is the only thing that distinguishes them, and it is not on the line.

**No gate is added, and that is a ruling rather than a shrug.** Deciding markup context from code context is
not decidable from text without a Razor parser. This project's own habit — *where a rule can be executed, a
list should not exist* (F-47) — points the other way here, because the rule **is** executed, by `csc`, in
three seconds, with the file and the column in the message. A second implementation inside the test suite
would be **two parsers for one rule, with the worse of the two doing the blocking**, which is F-59's
mechanism inverted. F-71's ruling applies unchanged: the compiler is the gate, it blocked, and a test
re-asserting what the compiler already refuses is a monument.

What is added instead is the reason, written **beside the statement** rather than only in this log, because
the next person to reach for `@{` in that file will be reading that file. And the residual is stated in §18:
**no gate in this repository can see a Razor transition written where the parser is already in C#.** The
authoring verification that missed it walks tag trees and balances braces, and neither has any notion of
transition context — which is worth saying plainly, since both instruments were run on this file and both
passed.

## The stage (4d) — the history a picture had never had

`0006` created `menu_item_image_event` in Slice 51. Slices 51, 52 and 53 wrote to it; `0007` took it to four
event types. **Nothing in the tree could read it.** §16.4 recorded that on each of those slices under the
standing rule that a read arrives with the surface that renders it, and `MenuItemImageTests` selected from
the table directly with a comment saying why. So §11.4 could not answer *when did this photograph last
change, and who changed it*, and `alt_text_changed` — added one slice ago — was written from its first day
and rendered nowhere.

`IMenuItemImageEventLog` and `DapperMenuItemImageEventLog` are `IMenuSectionEventLog`'s shape almost line for
line: one connection per call, no transaction, aliased columns, every reference table-qualified, an internal
row type with a `DateTime` member because Npgsql materialises `timestamptz` as one, `COALESCE(NULLIF(btrim(…)))`
on the actor's name, and `ORDER BY (occurred_at, menu_item_image_event_identifier)` so that two events sharing
an instant — which a replace's row and event always do — come back in a deterministic order.

### The one divergence, and it is the whole design

**This reader must not join `menu_item_image`.**

Every other reader in this family joins the row its events are about, and is right to: `menu_item` and
`menu_section` rows are never deleted, because §6.8's answer to *get rid of it* is a flag. **A picture is the
stated exception to that rule.** A replace mints a new identifier and deletes the old row — required, so that
§7's `Cache-Control: immutable` is a true statement rather than a hope — and a removal deletes the row
outright. So an event here names a row that, in the ordinary case, is gone.

Both joins a maintainer reaches for are therefore wrong:

- **INNER JOIN** → the history silently **begins at the current photograph**. It reads like a complete
  history, nothing throws, and no other fact in the file notices.
- **LEFT JOIN** → everything comes back with a column null on every row but the newest, which is a column
  about this schema rather than about the restaurant.

`0006` declared no foreign key on that column precisely so the log can outlive its subject, and its comment
says the identifier is *"not a pointer to a row a reader can open; it is the evidence that the URL changed"*.
This slice asserts it rather than trusting the comment.

### The surface

Under the picture forms, as `<h3 class="manage-subheading">` — a subsection of the Picture panel rather than a
peer of Section and Position. Three decisions, none of which the plan had made:

**Rendered whether or not a picture is attached now.** *No picture now, three of them previously* is precisely
the state §11.4 could not describe before this slice, so gating the panel on `_picture is not null` would hide
it in the one case somebody opens the page to ask about. The read is therefore unconditional too, and the
asymmetry with the metadata read on the line above is documented where it is written.

**No identifier and no link.** Every row carries one, and a URL for a replaced picture answers 404 by design,
so a link would be a link that mostly does not work — while a bare UUIDv7 in a cell is a fact about this
schema rather than about the restaurant. What the identifier is *for* is making it legible that a replacement
produced a new address, and *Replaced with a new picture* says that without it.

**What a picture WAS goes inside the sentence.** The format and the size are carried by `attached` and
`replaced` and by neither of the other two, so two columns of their own would be empty on half the rows — a
`data-label` reading *Format* beside nothing, on the row somebody came to read, which is the exact card-layout
failure §11.12's label rule exists to prevent.

**And a sentence that was false becomes true for free.** Slice 52's removal flash said *"The record of it stays
in the history below"* and there was no such record: a removal writes to `menu_item_image_event`, and the
history below it is `menu_item_event`'s, which has never carried a picture type. It now names the panel that
exists. F-77's cheaper direction, arriving without being sought.

## The second defect (F-105)

Reading §7 in order to write the reader turned up this, in the indicative, about the current schema:

> `menu_item_image_event` mirrors every change to it (`attached | replaced | removed`, typed nullable payload
> columns CHECK-bound to type by two named biconditionals, actor, timestamp)

The vocabulary is **four** types and the biconditionals are **three**, and have been since `0007` — one slice.
**The aggravating circumstance is three sections above it.** §7's paragraph on `menu_item_event` says, in
bold, that its own vocabulary *is not counted in prose anywhere* and that the list there is the only copy of
it in the document. That rule was written down after F-77 and then not applied to the table this project added
next.

F-77's shape for the **seventh** time, and the second time in three slices that the stale artefact was a
**specification or design paragraph** rather than a comment (F-101 was a DDL sketch, F-103 an argument for a
column). Found by reading the section in order to implement against it, which is **F-93's timing for the
fifth time** — caught in the slice that would have consumed it.

The list is **corrected** on F-77's cheaper direction, as for F-100 and F-103; the **count is deleted** in
favour of *one named paired biconditional per payload column*, which is a rule a migration cannot falsify; and
§7 now says of this list what it already said of the other one.

**And the row names something executable**, because on this project's own evidence a corrected sentence is
worth nothing — the next migration to widen this vocabulary will be written by somebody who has not read the
sentence. `MenuEventVocabularyContractTests` gains a third fact: every type the migration admits has a
sentence on the one surface that renders that log.

**Its subject is the surface rather than the write service**, for two reasons worth separating. The service's
four type constants are `private`, and widening them to `public` so a test could read them would be changing
an API for a test's convenience. But the surface is the better subject anyway: §11.4 falls back to the raw
string for an unrecognised type **by design**, so a missing arm throws nothing, logs nothing, and costs
nothing at run time — it appears as a cell reading `alt_text_changed` where a sentence belongs, on a page an
administrator opens once a month. **That is F-80's symptom exactly**, which is the class this gate belongs to.

The other direction is deliberately unasserted (F-41): an arm for a type the CHECK no longer admits is
unreachable rather than wrong, the fallback covers it, and forbidding one would report a finding on a surface
that had merely kept a sentence through a migration that narrowed the vocabulary. The reader's presence in the
file is checked before any arm is looked for, because a `Contains` loop over a list read out of a regex is
precisely the shape that passes against an empty list.

---

## What was verified

- The tree was reconstructed from `dump.txt` before anything was authored: **363 records, 361 matching
  SHA-256 exactly**, the two exceptions being `export.sh` (excluded; it contains the delimiter) and `LICENSE`
  (elided by design).
- **String-aware brace, paren and bracket balance** on every edited `.cs` file, with raw string literals,
  verbatim strings, char literals and both comment forms handled. **Proven sensitive** by deleting a closing
  brace from the new reader — reported at the enclosing line — and **proven not to false-positive** by
  planting `// "{{{" and '}'` in the same file, which it correctly ignored.
- **Razor tag-tree walk on both edited components, against the pristine files re-extracted from the dump.**
  `ManageMenuItem.razor` is a clean tree — zero findings — both before and after. `TableOrderSurface.razor`
  reports exactly the same **four** pre-existing artefacts of a generic type in markup, at the same lines,
  before and after; nothing was introduced.
- **The new gate simulated in both directions.** Against the tree as delivered it reports **nothing**; against
  the pristine `ManageMenuItem.razor` it reports **all four** event types, and its non-vacuity guard correctly
  reports the renderer as absent. Its arm pattern was probed against `FlashFor`'s `"picture-attached"`,
  `"picture-replaced"` and `"picture-removed"` arms with `DescribePicture` deleted: none of the four types
  matches, so the gate is measuring the switch it names.
- **The regex loosening is behaviour-preserving for the fact that already used it.** Making `ADD` optional was
  necessary because `0006` declares its constraint inline; run both ways over the migrations, the *item*
  vocabulary still resolves to `0005` and the same eight types.
- **§16.4's count gate simulated in full**: **29** counted classes against a floor of **29**, no ambiguous
  paragraph, no uncited class, **no disagreement** between a stated count and a file's `[Fact]`/`[Theory]`
  census. The three moved counts were checked against the files rather than asserted.
- **The Markdown table gate simulated faithfully**, splitting on unescaped pipes exactly as the gate does:
  **25 documents, 37 tables, 433 rows, zero column-count problems, zero runs without a header.** It caught one
  real defect while authoring — F-105's row spells `attached | replaced | removed` inside a code span, and a
  pipe inside a code span is still a cell boundary to a renderer, so it is escaped as `\|`.
- **The specification version gate simulated**: header `1.39`, newest changelog entry `v1.39`, all **40**
  entries strictly descending.
- **The `data-label` parity gate simulated**: `ManageMenuItem.razor` at **6 cells, 6 labels** (was 3 and 3),
  and **8** pages rendering a record list against a floor of 7.
- **The directive gate simulated** over 51 components: no `@section`, no `@RenderSection`, and the new comment
  block's `@@{` is stripped as a comment before the scan, as three existing comment blocks' `@@section` is.
- `.manage-subheading` was checked to be **already declared in `app.css` and already used** by
  `ManageSitting.razor`, which is why this slice adds no CSS.
- Tree hygiene on every edited file: LF only, exactly one final newline, no whitespace-only line, no dump
  separator.

## Test count arithmetic

Uncompiled, per §18. **1242 → 1250.**

| Class | Was | Now | Why |
|---|---|---|---|
| `MenuItemImageEventLogTests` | — | 6 | the stream oldest-first across three verbs; the payload each type is allowed; the history outliving every picture it names; a cleared caption as `""`; the actor fallback; one dish's history and two kinds of empty |
| `MenuWiringTests` | 27 | 28 | the picture history reader resolves in a scope |
| `MenuEventVocabularyContractTests` | 2 | 3 | every picture event type has a sentence on the surface that renders it |

§16.4's counted-class floor moves **28 → 29**, because the new integration class acquired a paragraph of its
own. §16.3 stays at seventeen. **Any deviation from 1250 is the first thing to investigate after a run** — and
note that this run is the first count since 1233, because the arithmetic that predicted 1242 was never tested.

## What was NOT verified

- **Nothing was compiled.** No SDK, no database, no browser. Given what this slice repairs, that is worth
  stating twice rather than once: the instrument that would have caught F-104 is the instrument this
  environment does not have, and the two instruments it does have both passed on the broken file.
- **The new SQL has never executed.** The two INNER JOINs, the aliased `person AS actor`, and the
  `ORDER BY` are unrun. The shape is `DapperMenuSectionEventLog`'s, which does run, and the one column that
  file does not have — `menu_item_image_identifier`, selected bare with nothing joined to it — is the one
  place a copy could not have carried the correctness with it.
- **The panel has never been rendered.** Whether four columns' worth of sentence wraps acceptably inside a
  `.record-list` cell at 375px is a judgement nobody has made against a real screen. `Replaced with a new
  picture — image/jpeg, 284736 bytes` is the longest sentence it produces.
- **The byte length is rendered as a bare integer**, which is what §11.4's existing picture facts do. Whether
  an operator reads `284736 bytes` as easily as `278 KiB` is an opinion this slice did not form, and forming
  it would have put a unit conversion in a surface where §8.2 stores none.
- Whether `Assert.SkipUnless` skips the six new integration facts cleanly where no container engine answers —
  the same as every fact in that directory, but unobserved here.

## Carried

**Browser downscaling is the only thing between this feature and the person who asked for it, and it is named
as the NEXT slice rather than carried a fifth time.** A phone camera produces four megabytes against §8.2's
512 KiB cap, so the answer to most uploads is *too large* — and every picture this slice's history would have
recorded is a picture that could not be uploaded. It changes no schema. Two things make it a real slice rather
than sixty lines of JavaScript: a static-SSR multipart form has to be handed the downscaled file **in place of
the chosen one**, and §11.11's `script-src` is the one configuration that becomes wrong by editing a file it
does not mention (F-49).

**No §16.3 scenario touches a picture.** The seventeen are unchanged, and this slice widens the gap slightly
rather than not at all: the history panel is one more surface no browser has loaded. A picture scenario needs a
fixture image the harness has no way to produce.

**A browser that sends `application/octet-stream` for a genuine PNG is refused.** Fifth slice carried, with
the fix written down.

**No `alt_text` on the administrator's own thumbnail, deliberately.** Not an omission and not open — recorded
so it is not repaired by mistake.

**F-102 has no row in `DOCUMENTATION_REVIEW.md`.** Second slice carried. Slice 52 put it in the status
paragraph and in Appendix A and not in the ledger's own table; F-103, F-104 and F-105 all have rows, which
makes F-102 the only recent finding without one. Named rather than backfilled, because reversing a prior
slice's filing decision is a decision.

**F-41 has no row in `DOCUMENTATION_REVIEW.md`.** Eighteenth slice carried.

**§16.3 has no scenario for either resequencing verb.** Carried: scenario 16's barrier measures those controls
and nothing presses them.

**`/kitchen` has no §16.3 scenario at all.** Carried — the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls.** Carried on two registers.

**The handheld barrier visits neither section surface.** Carried.

**The dump reduction.** Deferred again by name, and now overdue on two counts: this log has grown by another
slice and `MENU_AND_HANDHELD_PLAN.md` has grown a stage.

**No gate can see a count written in a comment, or a claim written beside a computation.** Carried — and
F-105 is that class arriving in an eighth form, a count in the **specification's own prose** three sections
from the paragraph that forbids it.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried — and this
slice is the fourth occurrence, with the cost nameable for the first time: the two facts that would have
reported F-105 were in the project that did not build. Worth saying that a report naming the skipped gates
would not have prevented anything here; it would only have made the second defect visible a session earlier.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twenty-first time.

**A CI job that runs the canonical stack on the canonical engine.** Thirtieth consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then starts
it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried.

---

# M6 Slice 55 — the 500 an operator found, and the picture a phone can finally upload

## Read this first: uploading worked, and the page that showed the result did not

The report was four words long — *when I try to upload an image I get a 500 error* — and it named the
wrong request, which is why it is worth writing down carefully.

`ManageMenuItem.razor` gained the caption editor in Slice 53. Its `<ValidationMessage>` was placed one line
**below** `</EditForm>`:

```
                <button type="submit" class="button-primary">Save caption</button>
            </EditForm>

            <ValidationMessage For="@(() => AltTextInput.AltText)" />
        }
```

An `EditForm` supplies its `EditContext` as a **cascading value to its children**. A sibling receives none,
and `ValidationMessage.OnParametersSet` throws `InvalidOperationException` when it has none. So that line is
not a message that renders empty. It is an unhandled exception during render.

The whole block sits inside `@if (_picture is not null)`, and that is what turned a placement mistake into
the worst symptom this repository has shipped:

1. The POST that attaches a picture renders the page first. `OnInitializedAsync` has already run and
   `_picture` is still `null` — the row is not written yet — so the block does not render.
2. `AttachPictureAsync` then runs. The transaction commits, the `attached` event is written, and
   post/redirect/get issues a 302. **The upload succeeds.**
3. The browser follows the redirect. That GET is the first render in which a picture exists. It throws.
   **500.**

And from then on, *every* administrator view of that item answered 500 — including the one carrying the
Remove button. The state was not reversible from any surface in the application. An operator's only way out
was `DELETE FROM menu_item_image`.

**Nothing in this repository could have caught it, and the reasons generalise.**
`MenuItemImageSurfaceContractTests` reads that exact file, and reads it as text: it asserted what is inside
the caption form and had no opinion about what is beside it. §16.1 rules out bUnit, so nothing renders a
component. The placement is legal Razor and legal C#, so the compiler is silent. And no §16.3 scenario had
ever uploaded a picture — an absence this log recorded on each of the four slices that built the feature,
deferred each time on the ground that the harness could not produce a fixture image.

That is **F-49's shape with the mitigating half removed**. F-49 was a control that existed, worked, and was
unowned. This is a path four slices built and no browser ever walked.

## What landed

Two changes, and they ride together under v1.32's rule because their failure modes are in different
projects with different names: a misplaced tag with a gate and two browser scenarios, and a browser-side
downscaler.

### The fix, and the gate that makes it a rule (F-106)

The tag moves inside the form, where the page's other five editors have always had theirs. One line.

`EditContextConsumerContractTests` is the rule. It walks every `.razor` file under `Components/`, tracks
`EditForm` depth, and requires every `ValidationMessage`, `ValidationSummary` and
`DataAnnotationsValidator` to sit at depth ≥ 1. Fifty-one components, eighty-three consumers, zero
findings after the repair.

Four decisions in it are worth reading:

- **The set is those three and not the `InputBase` family.** All three require the cascading context and
  all three throw without it, so a failure here always means the same thing. A bound input outside its form
  is a different defect with a different symptom, and folding it in would make the message ambiguous.
- **Depth rather than a boolean.** Nesting is legal markup even where this tree has none, and a walk that
  answered yes/no would have to interpret an unbalanced document instead of reporting it.
- **The close-tag count is clamped at zero.** Letting it go negative would make the *next* consumer on the
  page look correct, which is the one direction a gate must never fail in.
- **A self-closed `<EditForm />` does not open.** It supplies a context to nothing, so counting it would put
  every consumer after it inside a form with no children.

**Proven sensitive twice, and the first way is the strongest form of that proof this project has had
occasion to use:** the walk was run against `ManageMenuItem.razor` *as it shipped in the dump* and reported
`line 216 <ValidationMessage>`. The second is the sensitivity fact itself, written against synthesised
markup — the shipped shape, the repaired shape, the self-closed form, an element whose name merely begins
with the same letters, and a consumer stranded between two forms — because the first fact must stay true
after the repair and cannot depend on the tree still containing the defect.

### §16.3 scenarios 18 and 19, and the fixture objection answered

The plan deferred a picture scenario four times, and the stated reason was that *a picture scenario needs a
fixture image the harness has no way to produce, and inventing bytes inside the harness would be a test
arranging what it asserts about*. Half of that is right and half is not, and the difference is what
`PictureFixtures` is.

The right half: a checked-in photograph would be an opaque blob nobody can reason about, and a hard-coded
base64 string is the same blob with worse ergonomics. The wrong half: the objection about *arranging what it
asserts* does not apply, because nothing downstream asserts anything about these bytes. The claims are that
an upload round-trips, that the browser reduces one over the cap, and that the history records it.

So the harness **writes** a PNG: truecolour, 8-bit, unfiltered, uninterlaced, no ancillary chunks, with the
pixels in **stored** deflate blocks. Two consequences, both wanted. The byte length is
`edge × (1 + edge × 3)` plus about sixty bytes, so a caller asks for a picture over the cap by choosing a
number rather than by guessing — `ZLibStream` would have been three lines shorter and would have compressed
a gradient to nothing, which is precisely the file scenario 19 cannot use. And the content is a smooth
gradient rather than noise, which is load-bearing: JPEG's whole design is that smooth content is cheap, and
a random raster can survive every rung of the downscaler's ladder and still exceed the cap, failing the
scenario for a reason that has nothing to do with the product.

The generator was verified before delivery by re-implementing its exact arithmetic — the CRC-32 table, the
Adler-32 accumulator, the stored-block framing, the integer-division ramp — and decoding the output. A
12px square is 512 bytes and decodes as 12×12 RGB; a 640px square is 1,229,598 bytes, which is 2.34× the
cap, and re-encodes as JPEG at quality 0.82 to about 16 KB.

**Scenario 18** attaches a small picture and then walks *forward from the POST*, because that is where
F-106 lived: the flash is read on the redirected GET, the thumbnail is required to have **decoded** in the
browser rather than merely to be present in the markup — one assertion that covers §7's route answering, the
stored content type suiting the stored bytes, and §11.11's `img-src` admitting it — and the picture history
is required to carry the attach. Then the caption editor is used, which is F-106's own form and the one
whose validation could not previously be reached at all.

**Scenario 19** is the whole of Stage 4e and is not assertable anywhere else in this repository. The cap is
never written in the file: it is read off the rendered `data-picture-byte-budget`, and what is asserted is
the pair of inequalities that hold whatever the cap is — the chosen file is over it, the file the control
ends up holding is under it and smaller than what was chosen, and the upload is **not refused**. The closing
assertions read the stored format and byte count off §11.4's own panel, because a smaller file existing in a
browser proves nothing; a smaller file in the database does.

### Stage 4e: browser downscaling, and the number that had to leave the database (F-107)

§8.2 caps a stored picture at half a megabyte. A phone camera produces four. So the honest answer to almost
every real upload was *too large*, and every picture Slice 54's history panel would have recorded is a
picture that could not be uploaded in the first place.

Nothing on the server can help, and that is written down rather than assumed: there is no free-libre .NET
image library available to this stack for this use — ImageSharp's licence does not admit it, SkiaSharp is a
native dependency inside a rootless container — which is why `ImageFormat` reads signatures and never
decodes, and why `0006` stores no pixel dimensions (F-101). The one decoder everybody already has is the
browser's.

`wwwroot/js/menu-picture.js` is a classic script beside `passkey.js`, `display.js`, `kitchen.js` and
`clock.js`, and it is about a hundred and eighty lines of which most is comment. On `change`, it decodes the
chosen file with `createImageBitmap`, redraws it into a `<canvas>` no larger than a declared longest edge,
re-encodes as JPEG down a ladder of dimension-and-quality pairs until one fits, and replaces the input's
selection through a `DataTransfer`. The existing multipart form then posts the smaller file.

**Five things about it are decisions, not implementation.**

**It is an optimisation and never a check.** Every refusal is still the write service's and the schema's,
and every failure path fails **open** — the operator's chosen file stays selected and the server answers. A
downscaler that refused an upload would be a second authority on what may be stored, in the one place an
attacker controls entirely, which is F-64 and F-69's mechanism written in JavaScript.

**A picture already inside the cap is left completely alone**, bytes and declared media type both. §7 stores
what it was given; re-encoding something that already fits would throw away quality to solve a problem
nobody has and would silently convert a PNG somebody chose deliberately.

**The budget is not written anywhere in this application, and that is F-107.** Four slices were built on the
rule that the cap lives in one place — the write service reports `BytesOverCap` by reading the violated
constraint's *name*, with a comment saying a copy in C# "would be F-65's mechanism and, worse, would be the
belt that hides the buckle". That held only because nothing had yet wanted the *value*. A downscaler does.
The obvious implementation is a constant in a script: it would work, it would read as careful, and it would
be wrong on the day somebody edits the migration. So `IMenuItemImageDirectory.ReadDeclaredByteCapAsync` asks
`pg_get_constraintdef` for the bound — the same read `MenuItemImageTests` has performed since `0006`
shipped, given an interface — and the page splats it onto the input as `data-picture-byte-budget`.
**The attribute's presence is the switch**: a `null` cap renders no attribute, which turns the mechanism off
and restores the behaviour this form had before it. The twelfth fact on
`MenuItemImageSurfaceContractTests` computes the bound out of the migration and requires it to appear
nowhere under `src/` besides `Migrations/` — including in comments, which is why the doc comment on the new
read says the shape of the CHECK without quoting its number.

**It costs §11.11 nothing, and that was designed for rather than discovered.** `createImageBitmap` takes the
`File` directly and `canvas.toBlob` returns a `Blob` that becomes a `File`, so nothing ever produces a
`blob:` or `data:` URL and `img-src 'self' data:` needed no widening; the script is same-origin, so
`script-src 'self'` needed nothing either. The plan named the CSP as the thing that becomes wrong by editing
a file it does not mention (F-49). It did not, because the approach was chosen so that it could not.

**The output is JPEG although `0006` admits WebP.** WebP is smaller at equal quality on every current
browser, and that is not the property being optimised for: the stored bytes are served back to whatever a
guest is holding, and a picture that will not decode on an older handset at a table is worse than one forty
kilobytes larger. A `canvas.toBlob` JPEG also carries the `FF D8 FF` signature `ImageFormat` identifies, so
the re-encoded file passes the same check the original would have. The canvas is filled white before the
draw, because JPEG has no alpha and a transparent PNG would otherwise re-encode onto an undefined ground
that renders black — a defect with no error attached to it.

**Two smaller decisions, each with a symptom behind it.** The listener is delegated on `document` in the
capture-free bubble phase rather than bound to the input, because enhanced navigation replaces the body
without a reload and a handler bound at load time stops existing the first time somebody follows a link —
the same shape the other four scripts use for the same reason. And the submit control is **disabled for the
duration**: decoding four megabytes takes a noticeable moment, and a form submitted during it would post the
*original* file, which the server would refuse, correctly, with a message about size that the operator has
just watched the page promise to handle.

The status line is written through `aria-describedby` rather than a marker of its own — one association
doing two jobs, so the sentence a sighted operator reads under the control is the sentence a screen reader
announces as that control's description, and there is no second attribute for somebody to rename half of.
It is also what makes scenario 19 deterministic: the scenario waits on a settled sentence beside a control
that is not busy, which is unambiguous where either condition alone races a canvas.

## §18 arithmetic

Baseline **1250**, verified by the terminal log rather than predicted — the first slice in three whose
starting count was confirmed rather than assumed.

| Where | Facts | Running |
| --- | --- | --- |
| Baseline (verified) | — | 1250 |
| `EditContextConsumerContractTests` (new) | +2 | 1252 |
| `MenuItemImageSurfaceContractTests` (10 → 12) | +2 | 1254 |
| `MenuPictureScenarios` (new, §16.3 18–19) | +2 | 1256 |

**Predicted: 1256.** The end-to-end suite moves from seventeen to **nineteen**; `dotnet test` without
`MYRESTAURANT_E2E=1` will report the two new scenarios as skipped, exactly as it does the other seventeen.

Any deviation from 1256 is the first thing to investigate.

## What was verified before delivery, and what was not

**Verified.** The working tree was reconstructed from `dump.txt` and SHA-256 checked file by file: 364 of
365 matched, the exception being `LICENSE`, which the dump elides to metadata by design. The PNG
generator's exact arithmetic was re-implemented and its output decoded, at both sizes the scenarios use.
The new `EditContextConsumer` walk was run against the repaired tree (51 components, 83 consumers, 0
findings) **and** against the file as it shipped (1 finding, at the right line). The §16.4 counted-class
gate was emulated over the edited specification: 30 counted classes against a floor of 29, no
disagreements, no ambiguous paragraphs, no uncited names. The Markdown table gate was emulated over both
registers and over the specification: no row disagrees with its header. Byte hygiene — no CR, final
newline present, no whitespace-only lines — was checked on every edited document. The cap-restatement fact
was emulated over the real tree: the bound parses out of `0006` as six digits, 178 files under `src/` were
scanned, and none restates it.

**Not verified.** Nothing was compiled and nothing was run. There is no .NET SDK and no NuGet reachable
from where this slice was authored, so the C# is reviewed rather than built — in particular the Playwright
call shapes in `MenuPictureScenarios`, which are the least familiar API surface in this delivery. The
downscaler has not been executed in any browser; its behaviour is argued from the specifications of
`createImageBitmap`, `canvas.toBlob` and `DataTransfer` and from the JPEG sizes measured on the fixture
images. **Scenario 19 is the fact most likely to need a second pass**, and the likeliest reason would be a
timing condition rather than the mechanism.

## Open items after this slice

**Browser downscaling is closed.** It was named as the next slice at the end of Stage 4d and it is this
one.

**A browser that sends `application/octet-stream` for a genuine PNG is refused.** Carried with the fix
written down, for a sixth slice — and it is now *slightly* less likely to bite, because a downscaled
picture is re-encoded by the browser and arrives as `image/jpeg` whatever the original was labelled. That
narrows the case to files already under the cap, which is the wrong direction for a fix to arrive from and
is recorded so nobody mistakes it for a repair.

**The two menu resequencing verbs still have no §16.3 scenario.** With 18 and 19 landed they are the
largest end-to-end gap in the menu.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twenty-second time.

**A CI job that runs the canonical stack on the canonical engine.** Thirty-first consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried, and this slice makes it
more pressing: `BUILD_PROGRESS.md` is now past four thousand lines.

---

# M6 Slice 56 — the bytes decide the format, and a build that was red only where it mattered

## What arrived, and what the terminal said first

Two changes. `scripts/ci_local.sh` stopped at step 5 on the tree Slice 55 delivered, with an analyzer
error in the end-to-end project; and Stage 4f closed the open item this plan has carried longer than any
other. v1.32's distinguishable-failure ruling governs the pair, and here it is almost trivially satisfied:
one fails as `CA2014` from the compiler naming a file and a column, the other as three named contract facts
and one browser scenario. Nothing about the two can be confused for the other on a red run.

**The prediction was exact and that is worth recording before the defect is.** Slice 55 predicted **1256**
and the run returned 1256 — the first slice in four whose starting count was confirmed rather than assumed,
and the confirmation of a prediction that had itself been made against a verified baseline. Scenarios 18
and 19 both passed. Scenario 19 was flagged in that slice's own veto section as *the riskiest thing in this
delivery* — a real `<canvas>` in headless Chromium, waiting on a settled status sentence beside a
re-enabled control, authored without ever having been executed. It passed on the first run. The
end-to-end suite ran nineteen scenarios in 2m22s with nothing skipped.

## F-108 — the `stackalloc`, and the two builds that disagree

`PictureFixtures.Deflate` declared `Span<byte> lengths = stackalloc byte[4]` **inside** its stored-block
loop. Stack memory is released when the *method* returns rather than when the iteration ends, so the frame
grows once per pass. That is CA2014, and the analyzer's own name for it — *potential stack overflow* — is
the general case rather than this one: the loop runs once per 64 KiB of raster and the largest fixture is
nineteen blocks, so the actual cost was **seventy-six bytes** and nothing in the suite could ever have
failed on it. The repair is to hoist the declaration, which is behaviour-identical because every pass
overwrites all four bytes before reading any of them.

**What earns it a ledger row is the asymmetry that let it reach a delivery, and the asymmetry is
deliberate.** `Directory.Build.props` sets `TreatWarningsAsErrors` **false** for a plain `dotnet build` and
**true** under `-p:ContinuousIntegrationBuild=true`, with a comment arguing the case at length: a fresh
clone on tomorrow's SDK must build through analyzer drift rather than refusing at the door, and flipping it
globally would be a worse outcome than a warning nobody read. That argument is right. Its consequence is
that the same defect is *one line among eleven seconds of build output* on a workstation and *a halt* in
the pipeline — and the operator's session shows exactly that shape:

```
dotnet build   → Build succeeded with 1 warning(s) in 11.1s
dotnet test    → total: 1256   failed: 0   succeeded: 1256   skipped: 0
ci_local.sh    → error CA2014 … Build failed with 1 error(s) in 4.6s   [stops at step 5]
```

Three green signals in a row and then the one that counts. **The ruling is about ordering rather than about
spans:** `scripts/ci_local.sh` exists to reproduce CI, so its verdict is the one that decides whether a tree
is deliverable, and a green `dotnet test` earlier in the same session is not evidence about the build CI
will run.

**No gate is added, and that is a ruling rather than an omission** (F-47, F-71, F-88). CA2014 *is* the gate.
It exists, it ran, it decided correctly, and it blocked. A lexical re-implementation of a Roslyn analyzer
inside xUnit would be strictly weaker than the analyzer while adding a second thing that can be wrong,
which is F-41's *reaching past what it can decide* wearing a new hat. What failed was authoring-side
verification without a compiler — which Slice 55's own "what was NOT verified" section stated in advance,
and which is a property of how that slice was written rather than of the tree.

## Stage 4f — F-109, and six slices of a fix that was already written down

`ManageMenuItem.AttachPictureAsync` passed `IFormFile.ContentType` into the write service. **That value is
not a fact about the file.** It is whatever the operating system's extension map produced for the chosen
filename, so a Linux desktop without `shared-mime-info`, an Android browser handed a file from a document
provider, and any file saved with no extension all send `application/octet-stream` for a genuine PNG.
§8.2's census does not admit that string, so the write answered `UnsupportedContentType` and the page
rendered *"which is not a picture format this menu serves"* about a picture whose format was fine.

**The defect is ordinary. The deferral is the finding.** Stage 4b diagnosed it correctly and wrote the fix
out in full — *identify from the bytes and pass that* — and declined to take it on one sentence: doing so
*"would make two of the write's outcomes unreachable from the only surface that can reach them"*. That
sentence was then copied forward, unchanged, into Stage 4c's open list, Stage 4d's and Stage 4e's, and into
four consecutive BUILD_PROGRESS entries.

It is true. **It is not a cost.** `UnsupportedContentType` and `ContentTypeContradictedByBytes` are the
write service's answers, and the write service is a *library*: its contract is for any caller, and
`MenuItemImageTests` reaches both of them directly, without a surface, on every integration run. An outcome
no *form* can produce is not an outcome nothing tests.

There is a real worry underneath it and it is answered rather than waved away. A surface that decided for
itself what an image is would be a **second authority** on what may be stored — F-64/F-69's mechanism, and
refusing it would be right. But what the surface passes is the answer of **the same pure function the write
consults**: one decision procedure called twice, not two that can disagree. The write still checks the
census and still checks the signature, and both are now true *by construction* rather than by luck, which
is a stronger arrangement than the one it replaces.

**Stage 4e narrowed this without closing it, and the narrowing is why it stayed easy to defer.** Anything
the downscaler touches comes back from `canvas.toBlob` as `image/jpeg` whatever it was labelled, so after
Slice 55 only files *already under the cap* still reproduced it — which is to say screenshots and small
photographs, and nothing anybody happened to be testing with. A defect that gets rarer without getting
fixed is a defect that stops being reported and does not stop happening.

### The lesson, stated generally

F-62 established that **a reason for not doing something is a claim about the tree, and is checked against
the tree before it is written down.** This adds the other half: **a claim used to defer is re-checked each
time it is used again.** A recorded fix with a recorded reason is comfortable to carry — it reads as
diligence every time it is re-read, and the justifying sentence is never re-examined, because
re-examination is not what re-reading is for.

## F-110 — the fourth and fifth copies of the vocabulary, found on the way in

The refusal F-109 forced a rewording of said *"Choose a JPEG, a PNG or a WebP"*. The paragraph above the
form said *"JPEG, PNG or WebP; anything else is refused with a reason."* Both are declarations of the
media-type vocabulary, after §8.2's CHECK, `ImageFormat.RecognisedContentTypes`, and the `accept` attribute
— which was made **derived** in Slice 52 on the explicit argument that a stale `accept` list has no
server-side symptom at all. **Two more copies were written in that same slice**, and neither has a symptom
either: a migration admitting a fourth format leaves both sentences quietly wrong, read by an operator,
believed, and contradicted by a file picker that would happily offer the format the prose has just said is
unavailable.

F-80's shape in a fifth place, and **F-93's timing for the fifth time** — found while editing a paragraph
for another reason, which is the last moment its content is free to be wrong.

Both now render `MenuItemImageUpload.RecognisedTypesForOperators`. **It renders media types rather than
English names, and that is a ruling rather than a shortcut**: turning `image/webp` into *"a WebP"* needs a
map from type to article-and-name, and that map would itself be the copy this removes. The operator is
shown exactly the list their file picker was filtered by, so the two cannot disagree.

## The gates, and where they had to live

Three facts, in a **new class** — `MenuItemImageContentTypeContractTests` — rather than on
`MenuItemImageSurfaceContractTests`. That was not a filing preference. `MenuItemImageSurfaceContractTests`
is at **twelve**, and `TestingSectionContractTests.NumberWords` stops at twelve, saying in its own summary
that *a contract test with more than twelve assertions is a contract test that has become two, and the gate
refusing to parse the word is a reasonable place to find that out.* Writing "Fifteen assertions" into §16.4
would have made that paragraph unparseable and silently dropped it from the comparison; writing "15" would
have parsed and dodged the rule. **The tree's own constraint decided the design**, and the split is honest
on its own terms: one class asks whether an upload can *reach* the write service, and the new one asks what
the write service is *told* when it does.

**The first fact computes its own subject (F-47/F-58).** It names no page. It finds every file under `src/`
that binds an `IFormFile`, captures what each binding is called, and requires that none has `.ContentType`
read off it — so a second upload surface acquires this rule by existing rather than by somebody remembering
to add it. It is scoped to the **binding** rather than to the string, because §11.4's own panel renders the
*stored* `ContentType` and a blanket ban would report a finding on a correct file (F-41).

**The second is its positive half**, and it is needed because emptiness is cheap: deleting the argument or
passing a literal would satisfy *does not read the browser's declaration* while breaking every upload,
which is a worse product than the defect. The local is captured from its own assignment and required to be
among the arguments the attach call is given.

**The third scans the whole page rather than the refusal**, with the forbidden words derived from the
census. Scoping it to the `switch` would have caught the message and left the paragraph, which is F-46's
mechanism exactly — a rule enforced against the example that prompted it.

**Comments are stripped before every scan (F-67), and here it is load-bearing rather than tidy:** the
paragraph that *explains* F-109 necessarily contains both `IFormFile.ContentType` and the word PNG, so a
gate that read comments would report a finding on the very file it had just been satisfied by.

**All three were proven sensitive against the tree as it shipped, with nothing planted** — the strongest
form of that proof this project has occasion to use, and the third time it has been available.

## §16.3 scenario 20

An administrator uploads a real PNG named `shrimp`, with no extension, under `application/octet-stream`.
The picture is deliberately **under** the cap, which is what makes the scenario about F-109 and nothing
else: the downscaler leaves it completely alone, so the label survives all the way to the server, and the
scenario asserts that too — if that ever stops being true, the scenario silently stops being about
anything. The closing assertions are that the stored format is `image/png` **and is not the declared one**,
because accepting the upload alone would also be satisfied by a server that believed the label and then
handed it back as a response header, on this origin, for a year.

## Test count

Baseline **1256**, verified from the terminal log.

| Where | Facts | Running |
| --- | --- | --- |
| Baseline (verified) | — | 1256 |
| `MenuItemImageContentTypeContractTests` (new) | +3 | 1259 |
| `MenuPictureScenarios` (2 to 3) | +1 | 1260 |

**Predicted: 1260.** The §16.3 suite moves from nineteen to **twenty**. Anything other than 1260 is the
first thing to investigate.

## What was verified before packaging, and what was not

**Verified mechanically.** The working tree was reconstructed from `dump.txt` and SHA-256 checked file by
file: 370 files, with the only differences being `export.sh`, which embeds its own file marker, and
`LICENSE`, which the dump elides to metadata by design. No session drift — the tree matched what
`_CHANGES.md` said it was, which is the first time in several slices that check has been uneventful. All
three new gates were emulated **twice**: against the repaired tree, where each passes, and against
`ManageMenuItem.razor` **exactly as it shipped in the dump**, where each fails — the first naming
`file.ContentType`, the second reporting no `IdentifyContentType` call, the third naming all three format
words and the absent census. 185 files under `src/` were walked, one binds an `IFormFile`, and one binding
was named in it. The §16.4 counted-class gate was emulated over the edited specification: **31** counted
classes against a floor of 29, no disagreements, no ambiguous paragraphs, no uncited names. The Markdown
table gate was emulated with the real unescaped-pipe splitter over every tracked document: 415 rows, no
problems. The specification version gate was emulated: two versioned documents, headers matching their
newest entries, entries descending. Byte hygiene — no CR, final newline present, no whitespace-only lines —
was checked on every file in the archive.

**Not verified.** Nothing was compiled and nothing was run. There is no .NET SDK reachable from where this
slice was authored, so the C# is reviewed rather than built — and given that this slice exists partly
*because* of that gap, the point deserves stating plainly rather than in a footnote. The specific risks, in
order: the `@using MyRestaurant.Domain.Menu` added to `ManageMenuItem.razor` is a new import on a Razor
page and would fail as `CS0246` if `ImageFormat` did not resolve; the argument walk in the second gate
assumes the attach call's first `);` is its own, which is true of the shipped formatting and would break if
the call were reformatted onto one line; and scenario 20's assertion that the downscaler leaves a small
file's `type` untouched is argued from `menu-picture.js`'s early return rather than observed.

## Open items after this slice

**The picture feature has no open items.** Stage 4's list is empty for the first time since 4a. The
guest-side `srcset` question named in Stage 4e is not carried forward, because it was explicitly
conditioned on somebody measuring it on a real service and nobody has.

**The two menu resequencing verbs still have no §16.3 scenario.** With 18, 19 and 20 landed they are the
largest end-to-end gap in the menu, and there is now no picture work in front of them.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried — and F-108
is a second instance of the shape it describes, one register out: the build that failed was not the build
that had just reported green.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twenty-third time.

**A CI job that runs the canonical stack on the canonical engine.** Thirty-second consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past four thousand two hundred lines.

---

# M6 Slice 57 — the first stage of the menu that is not about a dish's own columns

## What arrived, and what the terminal said first

Two changes. Stage 5a of the menu plan — the like, its fold, and the two reads over it — and **F-111**, a
paragraph in the specification that had been describing `menu_item_event` three migrations out of date
while requiring a set of integration tests another section of the same document rules against writing.
v1.32's distinguishable-failure ruling governs the pair and is comfortably satisfied: one fails as nine
named integration facts against a real PostgreSQL plus one registration fact in the web project, the other
as a single contract fact over two text files. Nothing about the two can be confused for the other on a red
run.

**The prediction was exact for the second consecutive slice.** Slice 56 predicted **1260** and the run
returned 1260 — `dotnet test` green with nothing failed, the end-to-end project green at twenty, and
`scripts/ci_local.sh --with-all --with-e2e` clear, which is the gate that stopped at step 5 the slice
before. Two consecutive exact predictions is the first time this project has had that, and it is worth
recording because the §18 habit exists precisely so that a run which *disagrees* is loud.

**Session memory was stale by two slices and the tree corrected it.** This session opened believing the
tree was at Slice 54 with a predicted ~1250 against an unverified 1242 baseline. It is at Slice 56 with a
verified 1260. That is the fourth drift event this log records, and the SHA-256 reconstruction caught it
before a line was written — which is the whole reason the reconstruction is the first thing a session does.

## Stage 5a — what was cut, and why it was cut there

Stage 4 closed completely in Slice 56, so this is the first slice in eight with no picture in it. Stage 5
was specified when the plan was written and had been sitting behind two rulings it named and did not make.
**Both are made here**, and neither took an hour — which is the argument for making a decision at the
moment it is cheap rather than at the moment it is forced.

**Who sees the count: staff.** A count of 3 on a menu of sixty items is noise that makes a restaurant look
empty, and the number's only honest audience is the person deciding what to stock. So *which of these is
popular* is §11.4's question and *which of these do I like* is §11.1's — two reads over one fold, rather
than one read handing every guest the restaurant's opinion. The guest still gets their own press back, or
the control is an affordance with no feedback; what they do not get is everybody else's.

**Whether a like requires having ordered the item: no**, and this is the ruling worth reading because
Stage 6 inherits it. `order_current_line` records what somebody **ordered**, not what they ate, and a table
shares — so the requirement refuses the case it most wants to admit (*I ate my partner's dessert and it was
the best thing on the menu*) while admitting the one it wants to refuse (*I ordered it, sent it back, and
liked it anyway*). It would also make a menu write read order history, inverting §6.5.4's direction: an
order prices itself **from** the menu, and nothing in the menu has ever looked the other way. What bounds
the number instead is the door — §4.3 authenticates every person at a table and R§8 permits no anonymous
ordering — so a like is one authenticated person's press. **The decision is reversible additively:** if the
restriction is ever wanted it belongs on the *read*, as a second and narrower count, not on the write as a
refusal a guest at a table has to be given a sentence about.

The cut itself is Stage 4a's, applied a second time: **schema and data access, no surface.** The two
surfaces belong to different people and neither is a small page, and a slice that shipped one of them would
have to decide the other's shape in passing.

## `0008`, and the four rulings inside it

`0008_menu_item_reactions.sql` is the third migration in this tree that touches nothing existing — one
table, one index, one view, no `ALTER`, no backfill, no constraint widened. That is `0003`'s cut and
`0006`'s, and it is why the suite is green here **by construction** rather than by inspection.

**It is an event table and not a row per like.** The small schema is `(menu_item_identifier,
person_identifier)` `UNIQUE` with a `DELETE` to withdraw, and it is smaller, and it gets every visible
answer right — the fold, the count, the guest's own state. It also destroys the record. R§6.8 makes this
system append-only because a record that can be removed is a record nobody can audit, and §6.8's
hide-never-delete rule has exactly **one** stated exception — the image bytes — granted because the history
of those lives in a log beside them. A like has no log beside it, because the log **is** the record. Three
of the nine integration facts fail against the rejected schema, which is what makes the rejection a
decision rather than a preference.

**There is no `actor_person_identifier`**, which every other event table in this schema has. Elsewhere the
subject and the actor genuinely differ: an administrator renames somebody else's dish, and §11.1 renders
*"kitchen removed Salmon"*. A reaction's subject **is** the person reacting, and no surface in §11 could
offer to press it on somebody else's behalf, so an actor column would be constrained to equal its neighbour
on every row that will ever exist. That is F-65's rule arriving as a column that was never written.

**There is no count column and no count view.** A `menu_item_reaction_count` view is one line, and §8.3's
views exist to give the application a shape it would otherwise assemble from event tables by hand rather
than to save a `GROUP BY`; a second view would be a second place for *which of these is popular* to be
defined, and the second definition is the one that counts presses instead of people. A `like_count` on
`menu_item` is refused one register harder, on F-101's reasoning — a stored total beside the rows it totals
is one fact written twice, in the one table in this schema that grows a row every time a thumb moves.

**The fold's identifier tie-break is load-bearing here in a way it is not on `order_visibility_current`,**
and this is the sentence worth reading twice. Nobody hides an order twice in one millisecond. **Everybody
taps a heart twice**, and one transaction stamps its rows with one `IClock.UtcNow` (§8.1), so two presses
genuinely share an `occurred_at`. Without the tie-break `DISTINCT ON` returns whichever row the scan reached
first — the *oldest* — and a double-tap reads back as the state before it. It is an answer only because §8.1
requires `IIdentifierFactory` to ascend inside a millisecond, which is the property **F-95** found nothing
was keeping. `TwoPressesAtOneInstantFoldToTheLater` is the one fact in this slice that could not have been
written any other way, and it asserts its own premise first — two rows, one distinct instant — because a
fixture whose clock had started moving would make it pass while testing nothing (F-41).

## The lock, and what it costs

`SetLikedAsync` takes the `menu_item` row `FOR UPDATE` before it compares, which is the standing rule in
this file's neighbours and is doing two jobs at once: it answers `MenuItemNotFound` from the same statement
that takes the lock, and it serialises read-compare-append against itself. Without it two presses from one
person could both read *not liked* and both append `'liked'` — the fold would still be right and the
history would be a lie, which is the worse of the two failures in an append-only system (ADR-0002).

**What it costs is written down rather than left to be discovered.** The lock is wider than the conflict:
the conflict is one person against themselves, and this serialises every press on one dish against every
other, and against a rename of it. The alternatives were an advisory lock keyed on the pair — a second
locking scheme in a codebase that has one — and no lock at all, which trades a truthful log for concurrency
nobody at one restaurant's table will ever need. A dish is locked for the duration of one `INSERT`.

**Absence and `'unliked'` are one state**, deliberately. The fold has no row for a person who has never
pressed anything, so the read coalesces to `false`, and unliking something never liked is
`AlreadyInThatState` and writes nothing rather than being a fourth outcome nobody could act on. The
alternative puts a row in the log recording a withdrawal of an opinion never held.

## A reaction publishes nothing, and it is the first menu write not behind `IMenuWorkflow`

Stated as a ruling rather than left to be inferred from an absence, in the composition root, in §7, and in
the wiring fact's own summary. §9's `MenuChanged` means *re-read the menu*. A like moves no name, no price,
no heading, no position, no availability flag and no photograph — there is nothing for a picker to re-read
— and this is **the one write in this application that can fire many times a minute at one table**, so a
broadcast would make one thumb re-read the whole menu on every phone in the building. The presser's own
feedback needs no announcement either: a static surface re-renders through post/redirect/get and an
interactive one re-renders itself.

`MenuWiringTests`' standing fact is therefore narrowed from *covers every write service* to **covers every
write service that changes the menu**, which is what it always meant, and the two reaction services get a
registration fact of their own. That separation is the interesting half: the twenty-eighth fact is outside
the workflow's body because `IMenuItemImageEventLog` is a *read*; the twenty-ninth is outside it because
`IMenuItemReactions` is a **write that is deliberately not behind the workflow**, and putting it in that
body would make the fact assert the negation of its own name.

## F-111 — the paragraph twelve lines below the DDL that contradicted it

Not in this feature. §8.2's note beneath `menu_item_event`'s DDL said the CHECKs bind `new_name` and
`new_price_amount`, that *"`activated`/`deactivated` therefore carry neither"*, and that **"integration
tests must assert all ten combinations (five types × payload present/absent)"**. `0004` took the table to
seven types and four payload columns; `0005` took it to eight and five. The DDL block twelve lines above the
note records all of it correctly and has done since each migration landed.

**The mechanism is the finding.** A quoted DDL block stays right because it is the thing a person adding a
table *copies*. The paragraph explaining it goes stale because nobody re-reads an explanation they have
already understood — and every gate over this document reads table shape, header versions or assertion
counts, none of which is a sentence.

**Two things lift it above a typo.** The sentence is **normative**: it states an obligation on the suite,
and the figure it computes that obligation from was never right even for the schema it was written against
— five types over two nullable columns is twenty states, not ten. And the obligation it states is one
**§16.4 separately rules against**: a payload the CHECK refuses is refused loudly and by name on the first
insert, and `MenuSectionEventLogTests`' own summary says in as many words that re-asserting a constraint is
a monument (F-47). So one section of this specification required a set of tests another section forbade,
the tree obeyed the second, and nothing anywhere could see the disagreement.

**F-77's shape for the eighth time, one register up.** That row deleted three stale counts of this same
vocabulary out of code comments where nothing looks; this is the same vocabulary miscounted in the document
those comments defer to. Found by opening §8.2 in order to add a table to it, which is how F-54, F-58 and
F-79 arrived, and which is **F-93's timing for the sixth time**: the slice that edits a section is the last
moment its content is free to be wrong.

**The repair, and the executable half.** The counts are **deleted rather than corrected**, which is this
project's standing pattern for a census that can be derived. The testing sentence is **reversed to agree
with §16.4** rather than restated. And the *quotation* is made executable:
`MenuEventVocabularyContractTests` gains a fourth fact comparing every **named** `event_type` vocabulary
this specification quotes against the one the migrations declare, **in both directions with the subject
computed on each side** (F-47, F-58) — so a migration that widens a vocabulary and forgets §8.2 fails here,
and so does one that adds a table §8.2 never records. **The residual is stated:** only *named* constraints
are in scope, because that is the only form a text scan can key on, so `menu_section_event`'s inline
vocabulary is outside the gate — which is precisely the reason `0006` began naming every constraint it
creates and the reason `0008` does.

## Test count

Baseline **1260**, verified from the terminal log rather than assumed. Slice 56 predicted 1260 and the run
returned 1260.

| Where | Facts | Running |
| --- | --- | --- |
| Baseline (verified) | — | 1260 |
| `MenuItemReactionTests` (new) | +9 | 1269 |
| `MenuWiringTests` (28 to 29) | +1 | 1270 |
| `MenuEventVocabularyContractTests` (3 to 4) | +1 | 1271 |
| `SchemaMigrationRunnerTests.KeyRelations` (15 to 17 rows) | +2 | 1273 |

**Predicted: 1273.** The two extra come from theory rows rather than from `[Fact]` methods, so §16.4's
count for `SchemaMigrationRunnerTests` stays at 7 — it counts methods, and both new relations are
`MemberData` rows on a method that already exists. The §16.3 suite stays at **twenty**: Stage 5a builds no
surface, so there is nothing for a browser to visit. Anything other than 1273 is the first thing to
investigate.

## What was verified before packaging, and what was not

**Verified mechanically.** The working tree was reconstructed from `dump.txt` and SHA-256 checked file by
file: 370 files, with the only differences being `export.sh`, which embeds its own file marker, and
`LICENSE`, which the dump elides to metadata by design. **Session drift was caught and corrected** — this
session opened two slices behind, and the tree said so before anything was authored. The test-count
arithmetic was rebuilt from the tree and reproduces the terminal exactly: 910 `[Fact]` methods, 329
`[InlineData]` rows and 21 `MemberData` rows is 1260, which is the number the run returned to the unit.
The §16.4 counted-class gate was emulated over the edited specification: **31** counted classes, no
disagreements — and it caught the one regression this slice created, `MenuWiringTests` at 28 against a file
holding 29, before the count was corrected. The Markdown table gate was emulated with the real
unescaped-pipe splitter over every tracked document: no problems. The version gate was emulated on both
versioned documents: headers matching their newest entries, entries descending. The new vocabulary gate was
emulated in both directions against the edited tree — three named vocabularies on each side, sets equal —
and **proven sensitive two ways**: a widened list planted in §8.2's quoted `menu_item_event` DDL is
reported, and deleting `menu_item_image_event_type_vocabulary`'s quoted CHECK outright is reported as a key
mismatch. Byte hygiene — no CR, exactly one final newline, no whitespace-only line, no context-dump
separator — was checked on every file in the archive.

**Not verified.** Nothing was compiled and nothing was run; there is no .NET SDK reachable from where this
slice was authored, so the C# is reviewed rather than built (F-71's standing caveat). The specific risks, in
order. `Dapper.ExecuteScalarAsync<Guid?>` against a `SELECT … FOR UPDATE` is the one call shape in the new
write service that this tree has no exact precedent for — `DapperMenuAvailability` uses
`QuerySingleOrDefaultAsync<T>` over a row type for the same purpose, and the scalar form was chosen because
the lock statement selects one column; if it misbehaves it will do so as a null where an identifier belongs,
which `AnUnknownItemReportsNotFoundAndWritesNothing` reaches from the wrong side. The new gate reads a
609 KiB document with a regex on every run, which is a cost rather than a risk but is worth knowing about.
And `count(*)::integer` is cast in SQL rather than widened in C# so that `MenuItemLikeCount.LikeCount` and
the column agree at the boundary; a reader expecting `long` would fail as an `InvalidCastException` from
Dapper rather than as a wrong number.

## Open items after this slice

**Stage 5b, and it is two surfaces with no decisions left in them.** §11.4's count on the administrator's
menu index, and §11.1's control in the guest's detail panel — the panel rather than the card, because the
card is a button that stages an item and a second interactive element inside a button is not markup this
application can write.

**Two reads and one write have no caller**, which Stage 5a re-opened deliberately and which 5b closes. The
write is the stronger of the two, on the standing rule that a write nothing calls is a code path no test can
reach through the interface meant to protect it — the same position `IMenuItemImageAdministration` was in
between Stage 4a and Stage 4b.

**The two menu resequencing verbs still have no §16.3 scenario.** With no picture work in front of them
they are now the largest end-to-end gap in the menu, for a second consecutive slice.

**Nothing reports which gates a failed build prevented from running.** F-82's residual, carried.

**Nothing treats a test that fails and then passes as evidence.** Carried.

**An inline unnamed CHECK is outside the new vocabulary gate.** F-111's stated residual — `0001` and `0003`
declare theirs inline, so `menu_section_event`'s vocabulary is unreachable by a text scan. Not a gap the
gate can close; it is the reason `0006` began naming every constraint it creates.

**`.sitting-meta` is declared by two components and the two have drifted.** Deferred a twenty-fourth time.

**A CI job that runs the canonical stack on the canonical engine.** Thirty-third consecutive slice.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past four thousand four hundred lines.

---

# M6 Slice 58 — the half of the like a guest can see, and a number in its third generation

**What shipped.** §11.1's like control, in the item's detail panel; §16.3 scenario 21; a four-fact contract
class; `SeatGuestAsync` moved into the harness; and **F-112**. Stage 5b-i of
`docs/MENU_AND_HANDHELD_PLAN.md`.

**The tree opened three slices ahead of where this session believed it was.** Session memory said Slice 54
with an unverified baseline near 1250. The SHA-256 reconstruction said Slice 57 with a **verified 1273**,
and it said so before anything was authored. That is the fourth time this ritual has caught drift and the
second time it has caught more than two slices' worth. The baseline was then rebuilt from the tree
independently of the terminal log and reproduces it exactly: 921 `[Fact]` + 329 `[InlineData]` + 17
`KeyRelations` + 6 `KeyColumnsAddedByAlter` = **1273**. A naive count of `[InlineData]` gives 330; the
extra one is inside a comment in `ProfileDetailsTests.cs` explaining why a bare `[InlineData(null)]` needs
a cast. Worth recording because §18's whole method is to chase a one-count discrepancy, and this one is a
scanning artefact rather than a defect — a distinction that costs ten minutes to establish and would cost
an hour to rediscover.

## Why the guest's control came before the administrator's count

Stage 5a closed with two reads and one write having no caller, and named which was worse: *a write nothing
calls is a code path no test can reach through the interface meant to protect it*. That settles the order on
its own. Two further arguments agree with it and are worth keeping because they generalise.

**A count surface shipped first would be a read with no writer**, which is the same defect inverted and
harder to see: the column renders, the page is correct, and every number on it is zero because the only
thing in the application that can produce a press is the surface that has not been built. A read with no
caller announces itself in a census; a read whose only writer is an integration test looks like a working
feature nobody uses.

**And only this surface can produce a press**, so the end-to-end scenario is writable in this slice. The
count slice then *extends* scenario 21 rather than inventing an arrangement — an administrator reading back
a number a guest really pressed, which is a stronger claim than either half alone.

## The placement was predicted; the failure mode was not

The plan has said since Stage 5a that the control belongs in the detail panel, on the ground that *a second
interactive element inside a button is not markup this application can write*. True, and one register short
of the reason worth having: the HTML parser does not **reject** a nested button, it **repairs** it. Meeting
the inner `<button>`, it closes the outer one — so the card becomes two elements, and the half carrying the
dish's name and price stops being a control at all. Nothing throws. The Razor compiles. §16.1 rules out
bUnit so nothing renders a component, and §16.3's barrier measures where controls *are* rather than whether
they still do anything. A guest would find it by tapping a dish and having nothing happen.

That is why the ruling became a test rather than staying a sentence. `MenuItemReactionSurfaceContractTests`
takes the card's opening tag to the first `</button>` after it and requires the like control's class not to
appear between them.

## Two paragraphs stopped being paragraphs

Stage 5a made two rulings and wrote both into §7, where each is **one line away from being improved into a
defect**.

**The count is staff-facing.** One span on a card renders it to every guest. The gate walks
`Components/Pages/Table/` — the subject computed rather than named (F-47), because the ruling is about the
guest's half of the application and not about whichever component holds the menu after the next re-layout —
and requires that nothing there **calls** `ListLikeCountsAsync`, with the positive half (something does call
`ListLikedByAsync`) as its own non-vacuity guard (F-41).

**A reaction publishes nothing.** One forwarding verb on `MenuWorkflow` makes a heart-tap re-read the entire
menu on every phone, kitchen board and display in the building. The symptom is **load, not an error**: no
test fails, nothing logs, and the tree stays green while the one write that can fire many times a minute at
one table starts broadcasting. Every other menu write is behind that interface, so a reader meeting this one
outside it will read the asymmetry as an omission and tidy it — which is precisely the shape a gate is for.

**Both keys carry an open parenthesis, and that turned out to matter.** The first draft keyed on the bare
identifier and failed against the tree — because the file that must not call the count read is also the
natural place to write down *why*, and the surface's own comment names it twice. A gate that reports a
finding on a component whose only offence is explaining the ruling it obeys is a gate that will be deleted.
The rule is that a guest surface must not **call** the read, a call cannot omit its parentheses, and the
narrower key is the accurate one rather than the lenient one. **F-67's shape**: a mention is not a use.

## The scenario shipped with the control, and that is F-109 rather than diligence

This plan deferred a picture scenario four times, each time with a recorded and reasonable-sounding reason,
and the cost was **F-106** — an upload that committed, a redirect onto a page answering HTTP 500, every
administrator view of a decorated dish broken *including the one carrying the Remove button*, and eleven
hundred unit facts, every integration fact and seventeen scenarios green throughout. The operator found it.

A like control has the identical profile: an interactive island, a circuit event, a toggle that looks right
in source. So scenario **21** ships here, and **the reload is the whole scenario**. Everything before it —
the control renders, reports unpressed, reports pressed after a tap — is satisfied exactly as well by a
`bool` field on a Blazor component that no database ever hears about. That implementation is not a straw
man: it is what *make the heart fill in when you tap it* produces, it is smaller than the real one, and
every unit fact and every other scenario stays green against it. Reloading destroys the circuit and every
field on it, so the second reading can only have come from `menu_item_reaction_current`.

Four further claims ride the same arrangement, each refusing an implementation that passes the ones before
it: nothing to press until an item is chosen; the *other* dish reports unpressed, so the opinion is about a
dish rather than about the surface or about whether this person has liked anything at all; and the press is
then withdrawn and reloaded again, because a verb that only appended `'liked'` rows passes every step above
— the fold would answer from the last row it wrote.

## F-112 — a number in its third generation

**F-73** ruled that the §16.4 counted-class census should be kept in prose and moved by habit. The habit
failed twice. **F-89** reversed it, deleted both prose copies, and kept `MinimumCountedClasses` as the only
place the number is written, on the stated ground that a constant asserted on every run can go stale only
*loudly*.

The doc comment **on that constant** then grew a narrative census of its own. By this slice it recited
*twelve, sixteen, eighteen, nineteen … twenty-five, and now twenty-seven*, one line above `= 29`, guarding a
§16.4 that stated **32**. Three numbers about one fact, two of them wrong, in the one place a ruling had
gone to the trouble of clearing.

**Nothing could see it, and F-89 had already written down why:** the gate compares *assertion counts per
class* against files, and a census is a count of *paragraphs*. Found by computing the census in order to
move it for a new counted class — **F-93's timing for the seventh time**.

The narrative is **deleted**, which is F-89's own remedy applied to the copy F-89 created, and the floor
moves **29 → 33** with the census. **No gate**, and the reason is F-89's rather than a shrug: the instrument
that would catch a stale floor is an *equality*, and an equality would report a finding on every §16.4
paragraph that describes a class without enumerating its assertions — which §16.4 legitimately does for the
three response-header classes covered as a group by directory. A floor can only be too low, and too low
costs nothing but the check it declines to make.

**The transferable claim is narrower than "keep one copy".** Twice a ruling has said *this number will be
moved by habit*, and twice the habit failed within three slices. The variable is not the diligence of the
person editing; it is that **a number written beside an enforced copy of itself reads as part of the
enforcement**. That is worse camouflage than an ordinary duplicate, not better.

## `SeatGuestAsync` moved, and it is the loudest change here by design

It was `private static` inside `EndToEndScenarios` from Slice 5, which was right while exactly one file
seated guests. A second scenario file needs one, and a private method cannot be called from a second file,
so the alternative to moving it was pasting it — F-59's mechanism, with **F-100's** ruling already written
against it one register up, for a walk that had lived inside a Razor component.

It is now `TableJourneys.SeatGuestAsync`, taking a patience parameter. **The old file keeps a one-line
forwarder supplying its own constant, so its eight call sites are untouched** — which is the whole reason
this was affordable in a slice about something else. It throws rather than asserting: every other journey in
that directory reports failure as an exception naming what the surface was showing instead, and only
`RestaurantHarness` references xUnit at all.

**Its failure mode is why it can ride along.** If the move is wrong, every scenario that seats a guest fails
at once, under names that have nothing to do with likes. The one-change-one-green-run rule permits a
passenger whose failure is distinguishable, and this one is not merely distinguishable but unmistakable.

## One consequence, recorded rather than repaired

**A guest cannot like an unavailable dish.** §7 renders a deactivated item on the menu, marked, with a
`disabled` card — so the detail panel never opens for it and the control is unreachable. *The salmon is off
tonight and it is still the best thing here* is a real opinion and this surface cannot record it. It follows
from the placement rather than from a decision, and it is not repaired here because the repair is a second
route into the panel for items that cannot be staged — a surface change with its own questions. Written down
so that a reader meeting the gap does not assume nobody noticed.

## §18 arithmetic

| Where | Facts | Running |
| --- | --- | --- |
| Baseline, verified from the terminal log and rebuilt from the tree | — | 1273 |
| `MenuItemReactionSurfaceContractTests` (new) | +4 | 1277 |
| `MenuReactionScenarios` (new, §16.3 scenario 21) | +1 | 1278 |

**Predicted 1278**, and the §16.3 suite moves **20 → 21**. Anything else is the first thing to investigate.

## What was verified, and what was not

**Verified mechanically.** The tree was reconstructed from `dump.txt` and SHA-256 checked file by file: 371
clean, the two differences being `export.sh` (it embeds its own file marker) and `LICENSE` (elided by
design). All four new contract facts were emulated against the edited tree and **each proven sensitive by a
planted defect**: nesting the control inside the card is reported by two facts at once, deleting the control
is reported as a count of zero, redirecting the guest's read to the count is reported both as a prohibited
call and as the positive half going vacuous, and a `SetLikedAsync` mention added to `MenuWorkflow` is
reported by name. The §16.4 counted-class gate was emulated over the edited specification — **33 classes,
no disagreements between a claimed count and a file** — and the floor was set to match. The Markdown table
gate was emulated with the real unescaped-pipe splitter over all 25 tracked documents: clean. The version
gate was emulated on both versioned documents: headers match their newest entries, entries strictly
descending, 44 of them. A Razor tag-tree walk over the edited panel confirms the new `<div>`, `<button>` and
two `<span>` pairs balance inside the block `@if (PickedMenuItem is { } chosenItem)` opens. The standing
authoring scans ran over every changed file: no `await` in an interpolated hole (CS4007), every operand of
every `string.Create` chain an interpolated string (CS1620), no `stackalloc`, no `@section`, no CR bytes,
one final newline each, no whitespace-only or trailing-space lines.

**Not verified.** Nothing was compiled and nothing was run; there is no .NET SDK reachable from where this
slice was authored, so the C# and the Razor are reviewed rather than built (F-71's standing caveat). The
specific risks, in order. **The scenario is the largest one**: `PressLikeAsync` waits for `aria-pressed` to
change, and if the circuit re-render is slower than the poll interval in a way the other journeys have not
met, it fails as a timeout rather than as a wrong answer — the message says which state it is still
reporting, which is the diagnosis, but it would still be a red run for a reason that is about the harness.
**`ToHashSet()` on `IReadOnlyList<Guid>`** is the one call shape in the new component code with no exact
precedent in this file; the neighbouring read uses `.ToDictionary(…)` and the two resolve from the same
`System.Linq`. **The `\u2665` / `\u2661` escapes inside a Razor explicit expression** follow the same shape
as the `@(chosenItem.IsActive ? "…" : "…")` two lines above them, which compiles today, but they are the
only place in this tree where a Unicode escape sits inside markup content. And **the `SeatGuestAsync`
forwarder** changes the failure of a bad scan from an xUnit assertion to an `InvalidOperationException`;
both fail the test, and no scenario asserts on the exception type, but it is a behaviour change in eight
scenarios this slice is not otherwise about.

## Open items carried

**No end-to-end scenario drives either resequencing verb.** The 375px barrier measures those controls and
nothing presses them. Carried, and now the only such gap in the menu — scenario 21 closes the reaction one
on the way in.

**`/kitchen` has no §16.3 scenario at all.** Carried; the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls** on the administration index. Carried on two registers.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past four thousand six hundred lines.

---

# M6 Slice 59 — likes: §11.4's count, and the end of the menu enhancement's open list

**What shipped.** The like count on `/administration/menu`; a fifth fact on
`MenuItemReactionSurfaceContractTests`; scenario 21 extended with the read-back. Stage 5b-ii of
`docs/MENU_AND_HANDHELD_PLAN.md`. **No migration, no schema change, no CSS, no new scenario.**

**This slice stacks on Slice 58, and the baseline is therefore predicted rather than verified.** That is
weaker footing than this project normally accepts and it is stated first rather than buried: 58 has not
been built or run. If its run does not return **1278**, that is the thing to chase before this archive is
applied — the two slices touch different surfaces and different test classes, so a deviation is
attributable, but §18's method depends on knowing which number was real.

## Where a number goes, which is most of what this slice decided

The read has existed since Slice 57 and the surface is a chip. What took the thinking was where the chip
goes, and all three answers are rulings a later slice would reverse without noticing.

**Beside the name rather than in a column of its own — Stage 4d's ruling a second time.** A column empty on
most rows puts a `data-label` reading *Liked* beside nothing on the handheld card, which is exactly the
failure §11.12's label rule exists to prevent. Stage 4d refused two columns that would have been empty on
*half* their rows; this one would be empty on most of them. What a column buys is sortability, and that is
not on offer anyway — the index sorts by heading and position, and adding a sort is a feature rather than a
cell. On a menu of sixty the chips **are** the comparison this panel was asked for.

**Neutral rather than `-ok` or `-warn`.** A count of likes is neither good news nor a warning, and both
modifiers already mean something one cell over — available, currently unavailable. A `chip-ok` here would
read as *this dish is fine*, which is a different claim about the same row and one the page already makes.

**Nothing rather than a zero.** `ListLikeCountsAsync` lists the dishes that *are* liked instead of
left-joining the menu, and says so in its own summary. Rendering *0 likes* on fifty-eight rows of a
sixty-dish menu would be this surface inventing a fact the read deliberately declined to state, and would
bury the four rows that answer the question. `LikeCount` returns `int?` for that reason and not for a
null-safety one.

## The fifth contract fact is the half that fails plausibly

The index must call `ListLikeCountsAsync` and must never call `ListLikedByAsync`. **They are one keystroke
apart, and only one of them is about the person reading the page.**

An index calling the wrong one **renders perfectly**. Every chip says *1 like* or is absent, because the
page is showing the administrator their own opinion presented as the restaurant's. Nothing throws, no
number is malformed, no other test goes red, and the surface answers *which of these do I like* on a page
that asks *which of these is popular*. Two reads over one fold is the whole of Stage 5a's first ruling, and
the failure mode is that **both call sites compile**.

That is a different shape from the fact it mirrors. Fact three forbids the count on the guest's side, where
the defect is a *disclosure* — a number reaching an audience a ruling said it should not. Fact five is a
*substitution*, where the number reaches the right audience and is the wrong number. The first is caught by
reading the page; the second is not, because a restaurant where four dishes have one like each and the rest
have none is a plausible restaurant.

**Both halves are asserted**, because either alone is satisfied by an index that reads neither: an index
that had simply lost the read renders a menu with no counts on it, and a prohibition cannot see that.
Proven sensitive both ways before delivery — swapping the read is reported twice over, deleting it is
reported once.

## Scenario 21 was extended, and the prediction is worth checking rather than noting

Slice 58's open list said: *"21 already presses a heart, so the count slice adds an administrator reading
the number back."* That is what happened, and it is worth recording that the prediction held, because this
log more often records where one did not.

**The extension is stronger than a second scenario would have been.** It is the only place in this
repository where §11.1's write and §11.4's read meet — two different queries against the same rows, written
for two different people on two different surfaces. Nothing but a browser can say they describe the same
event.

Three assertions, each refusing an implementation that passes the others. One like against the dish while
the press stands. **None against the other dish**, because *the count is 1* is also what a page hard-wired
to report 1 would say. And **none against either once the press is withdrawn** — a count over `'liked'`
*events* rather than over current opinions passes every step before this one, which is precisely the
plausible wrong implementation `MenuItemLikeCount`'s own summary names.

The suite stays at **twenty-one**, which is the point: extending a scenario that already arranges a seated
guest and a pressed heart is cheaper than arranging a second one, and it asserts something neither half
could alone.

## The hook is an attribute, and the reason is not convenience

`data-like-count` rather than a marker class, for two reasons that agree.

The harness reads an **integer** instead of parsing *"3 likes"*, so the assertion does not depend on the one
part of the chip that is free to change. Wording is exactly the sort of thing that gets improved.

And `.record-` is §11.12's shared vocabulary prefix. A hook named `.record-like-count` would put a name in
the shared namespace that `app.css` has never heard of — not a re-declaration, so no existing gate would
report it, but a name whose only definition is the fact that somebody typed it. That is F-67's
neighbourhood: the rule there is that shared vocabulary is *declared* rather than merely referenced, and the
cheapest way to obey it is not to reach for the shared prefix at all.

**This slice adds no CSS**, which is worth stating because a count is exactly the kind of thing that
acquires a rule. `.chip` has been declared since Slice 30.

## One small thing that changed during authoring

The pluralisation started as a `LikeCountText` helper using `string.Create(CultureInfo.InvariantCulture, …)`
and `CultureInfo` is not imported in that component. Adding `@using System.Globalization` would have worked
and would have been the third thing in that file's header for a two-word decision. The helper is gone
instead: the markup writes `@likes @(likes == 1 ? "like" : "likes")`, which is Razor rendering an integer
the way it already renders `@item.DisplayOrder` twenty lines up, and the culture question does not arise.
**The smaller change was available because the helper was not earning its place** — it existed to hold a
`?:` that reads better inline.

## §18 arithmetic

| Where | Facts | Running |
| --- | --- | --- |
| Baseline — **predicted by Slice 58, not verified** | — | 1278 |
| `MenuItemReactionSurfaceContractTests` (4 → 5) | +1 | 1279 |

**Predicted 1279**, and the §16.3 suite stays at **21**. If the number that comes back is 1279 then Slice
58's prediction of 1278 was also right, because this slice adds exactly one; any other number is a question
about *both* slices and 58's is the one to answer first.

## What was verified, and what was not

**Verified mechanically.** All five contract facts were emulated against the edited tree and the new one
**proven sensitive both ways** — an index calling `ListLikedByAsync` instead is reported twice over (the
requirement fails and the prohibition fires), and an index that has lost the read entirely is reported
once. The §16.4 counted-class gate was emulated over the edited specification: **33 classes, no
disagreement between any claimed count and its file**, the census unchanged because the new assertion
joined an existing class. The Markdown table gate was emulated over all 25 tracked documents: clean. The
version gate was emulated: header 1.44, newest entry 1.44, 45 entries strictly descending. A Razor tag-tree
walk over the new chip block confirms its one `<span>` pair balances, and the `@code` block's braces close
with nothing after them. The standing authoring scans ran over every changed file: no `await` in an
interpolated hole, no `string.Create` chain with a plain literal, no `@section`, no tabs, no CR bytes, one
final newline each, no whitespace-only or trailing-space lines.

**Not verified.** Nothing was compiled and nothing was run (F-71's standing caveat), **and this slice's
baseline is a prediction rather than a measurement**, which is the larger of the two gaps. The specific
risks, in order. **The harness's row locator** — `tr:has(a.record-link[href*='{identifier:D}'])` — is the
one selector in this slice with no precedent in the file: `ReadMenuIndexAsync` walks groups and reads all
link texts, and nothing has previously reached a row *by* its item. `:has()` is supported by the Chromium
Playwright ships, and the fallback if it is not is to walk rows and compare hrefs. **`int.TryParse` with
`NumberStyles.Integer`** on an attribute Razor wrote from an `int` cannot fail, so the throw arm is
unreachable and is there to make the reader total rather than because it is expected. And **the chip's
placement inside `td.record-primary`** puts a second element in a cell whose handheld card layout was
designed around a link and an optional sentence; it is `display: inline-block` by `.chip`'s existing rule
and should flow, but nothing here measured it at 375px — §16.3 scenario 16 visits this page and asserts the
document is not wider than its viewport, which is the check that would catch it.

## Open items carried

**No end-to-end scenario drives either resequencing verb.** The 375px barrier measures those controls and
nothing presses them. Carried, and now the only such gap in the menu.

**`/kitchen` has no §16.3 scenario at all.** Carried; the largest end-to-end gap in the application.

**The wide layout stacks each row's three controls** on the administration index. Carried on two registers.

**A guest cannot like an unavailable dish.** Carried from Slice 58 with its reason.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past four thousand nine hundred lines.

# M6 Slice 60 — likes: a dish that is off tonight, and a read that had no reader

**The last item on the menu enhancement's open list.** Stage 5b-i put §11.1's like in the detail panel for
a mechanical reason, recorded what that placement costs, and declined to pay it: the panel opens only for a
*chosen* item, §7 renders a deactivated item's card `disabled`, and so a guest could not like an
unavailable dish. *The salmon is off tonight and it is still the best thing here* is a real opinion and
this surface could not record it. Stage 5c is the repair the paragraph itself predicted.

**The baseline this slice starts from is measured rather than predicted**, which has not been true for
three slices. `claude-terminal.txt` shows `dotnet test` at **1279** green, `scripts/ci_local.sh --with-all
--with-e2e` clean end to end, twenty-one §16.3 scenarios, the restore drill, the boot smoke and a quick
tunnel. Slice 59's prediction of 1279 was therefore right, and so was Slice 58's of 1278.

**Session-memory drift, recorded because it keeps happening and the instrument keeps catching it.** The
session opened believing the tree was at Slice 54 — picture history, roughly 1250 tests, ledger through
F-105. The SHA-256 reconstruction from `dump.txt` said Slice 59, v1.44, 1279, F-112: **five slices of
drift**, the second-largest yet. 374 of 375 files verified byte-exact; the two that did not are `export.sh`
(the dump rewrites its own header into the copy it embeds) and `LICENSE` (elided to metadata by design).
Nothing was reconstructed on a guess. This is the fourth time the reconstruction has caught drift and the
first time it has caught five slices of it.

## The repair is a path rather than a looser refusal

The obvious change is to drop the card's `disabled` so that one control both stages and opens the panel. It
works, and that is why it is worth arguing against rather than merely not doing. §7's "cannot be added to a
send" would still hold: `OrderStaging.Stage` refuses an inactive item **by name**, and the send transaction
re-reads the menu under the lock. The markup would be smaller. Every existing test would stay green.

**What it costs is a sentence.** §7's rule is about *staging* and the card is the staging control, so a
card that answered a tap on a dish the surface already knows is off would be inviting somebody to press
*Add to basket* and be told no. The thing that was missing was never a looser refusal — it was a second
**path**. The card keeps `disabled` and gains a sibling inside the same `<li>`.

## A sibling and not a child, asserted structurally

Stage 5b-i's argument applies again unchanged: a card *is* a `<button>`, the HTML parser does not permit a
button inside a button and does not report the attempt, so a nested control silently splits the card and
the half carrying the dish's name stops staging anything. Nothing throws, the Razor compiles, §16.1 rules
out bUnit.

**So the contract fact asserts an index rather than an absence.** The control's position must fall between
the card's `</button>` and the `</li>`, which is the only place a sibling can be. An absence assertion —
"not inside the card" — is satisfied by a control that has drifted out of the list item entirely, and the
structural form costs one extra `IndexOf`.

## Three smaller rulings, and one of them is about voice control

**Rendered only where the card is refused.** An available dish already has a way into its panel. A second
control beside every card is sixty controls on a menu of sixty, read from a phone.

**The accessible name carries the dish; the visible text does not.** A column of buttons all reading *Read
about* is unusable to anybody navigating by control, so the dish's name is appended in a
`.visually-hidden` span. **Not an `aria-label`, and the direction of that difference is the ruling**: an
`aria-label` *replaces* the element's content, and voice control matches on what is on screen — so a label
would break *"click Read about"* for exactly the population most likely to be using it. The visible words
stay a prefix of the accessible name, which is what §11.4's own record ticks already do.

***Add to basket* is never disabled, and that is now asserted.** It is the same ruling read backwards. Now
that a guest can choose a dish that is off, the next tidy-up is to disarm that button while such an item is
chosen. It looks considerate and costs two things: a dead control with no reason on it, where
`OrderStaging` would have named the dish; and a second opinion about availability inside a component whose
staging area already holds one, which is F-65's mechanism. The Send button one region down *is* disabled
while the basket is empty, and the distinction is why this fact names its subject by the words on the
control — an empty basket has no refusal to explain.

## One layout consequence that is invisible in the markup

`.order-menu-item` was `display: flex` with a single full-width child, and the default `align-items:
stretch` is what made every card in a row the same height. A second child makes it a **column**, where the
axis that stretches is the other one — so the card takes `flex-grow: 1` and the row stays level. Without
that one line the change is correct HTML that looks broken on the first menu holding two cards of different
lengths side by side, and nothing in this repository measures §11.1 at any width.

## F-113, and the shape of it is a scope claim rather than a number

`ChosenItemDetail.Facts` is keyed by the detail panel's `<dt>` terms and its own paragraph names them
*Price*, *Available* and *On the menu since*. `ReadChosenItemDetailAsync` built the dictionary with
`InnerTextAsync`, which returns what layout produced, and `app.css` declares `text-transform: uppercase` on
`.order-menu-facts dt`. So the reader produced `AVAILABLE` while the record promised `Available`.

**F-88's mechanism a second time inside the file F-88 was found in.** That fix corrected
`ReadMenuAsync`'s section-name read and, forty lines further down, `ReadTotalsAsync` — two instances in one
slice — and then wrote *"Only this one read is affected: it is the only place the suite compares a value
against text a `text-transform` rule reaches."* Wrong by one at the moment of writing.

**And it was the kind of wrong nothing could report, for a reason this project already has a rule about.**
`Facts` was a **read with no reader**: nothing in the suite had ever looked a term up, so the disagreement
between the record's documented keys and the keys its reader produced was unobservable rather than merely
unobserved. The standing rule is that a read with no caller is a defect; here the absent caller was also
the absent instrument.

The remedy is `ScreenText.DeclaredAsync`, which already exists for this and which `ReadTotalsAsync` already
uses — one decision procedure at both `<dt>` sites. **The `<dd>` beside it deliberately stays on
`InnerTextAsync`**, because that is `ScreenText`'s own stated distinction between a label and content, and
a blanket replacement would be the wrong subject (F-46). The false sentence is corrected rather than
deleted (F-77's cheaper direction) and corrected **into a rule rather than a census**, since a count of
affected sites is the artefact that went stale in the first place.

**No gate**, on F-104's reasoning: deciding which reads a `text-transform` rule reaches needs a CSS
selector engine resolved against a component tree, which is not decidable from text, and a lexical
approximation would report findings on correct reads while missing transformed ones. What closes the hole
is that `Facts` now has a caller.

## The plan's header lost a date, and it is not a finding

`MENU_AND_HANDHELD_PLAN.md` opened with *"Last moved 2026-08-18, at the close of Slice 51"* while the
document below it had been moved by Slices 52 through 59 — eight slices and six days stale, in a document
three gates read for structure and none reads for meaning. **Deleted rather than corrected**, on F-112's
ruling about a number written beside an enforced copy of itself: the durable form of *when did this last
move* is the struck-through stage headings, each of which names its slice, and this log.

It gets no F-number. The ledger is for findings, and a document's own metadata going stale is not a claim
anything depended on — the distinction Slice 57 drew when it recorded Stage 5a as an enhancement rather
than a defect.

## Scenario 21 was extended rather than a scenario added

**Four steps, on Slice 59's reason.** The kitchen 86s the salmon, the guest's open menu marks the card
unavailable, and the panel is reached through the second control.

**The pudding is chosen first, and that is arrangement rather than decoration.** The salmon's panel is
still open from step (e) — `_pickedMenuItemIdentifier` is component state and going off the menu does not
clear it — so without moving the panel off it, the claim would be satisfied by a panel that had simply
never gone away. That is the shape of a scenario that proves nothing, and it is worth naming because it is
invisible when the steps are read in order.

The closing assertion is §11.4's index reporting **one** like against a dish that is off the menu. A
surface that had merely opened a panel and toggled a field passes every step before it.

The cost of a scenario 22 would have been a second container, a second passkey registration and a second
join, for an arrangement this scenario already has standing.

## §18 arithmetic

| Where | Facts | Running |
| --- | --- | --- |
| Baseline — **measured, `claude-terminal.txt`** | — | 1279 |
| `MenuItemReactionSurfaceContractTests` (5 → 7) | +2 | 1281 |

**Predicted 1281**, and the §16.3 suite stays at **21**. This is the first slice in four whose baseline was
measured rather than carried, so a deviation here is attributable to this slice alone.

## What was verified, and what was not

**Verified mechanically.** All seven contract facts were emulated against the edited tree, and the two new
ones **proven sensitive against six planted defects** — the card's `disabled` dropped; the control moved
inside the card's `<button>`; the guard removed so it renders beside every card; *Add to basket* given a
`disabled` binding; and the control deleted outright. Every one was reported, and by the assertion that
should report it. The §16.4 counted-class gate was emulated over the edited specification: **33 classes,
no ambiguity, no disagreement between any claimed count and its file**, the census unchanged because both
new assertions joined an existing class. The Markdown table gate was emulated with the real
unescaped-pipe splitter over all **25** tracked documents: clean. The version gate was emulated: header
1.45, newest entry 1.45, **46** entries strictly descending. Brace and parenthesis balance was checked on
every changed C# file, with the two-parenthesis surplus traced to the pre-existing `"ListLikedByAsync("`
and `"ListLikeCountsAsync("` literals. The standing authoring scans ran over every changed file: no
`await` in an interpolated hole (CS4007), no `string.Create` chain with a plain literal (CS1620), no
`@section`, no tabs, no CR bytes, one final newline each, no whitespace-only or trailing-space lines.

**Not verified.** Nothing was compiled and nothing was run (F-71's standing caveat). The specific risks, in
order. **The layout change is the largest**, and it is the one thing here no gate in this repository can
see: `.order-menu-item` becomes a column and the card takes `flex-grow: 1` to keep a row level, and nothing
measures §11.1 at any width — §16.3 scenario 16's 375px barrier visits §11.4's surfaces only. If a row of
cards looks ragged, that line is where to look. **The `>` child combinator** in `MenuInspectSelector`
asserts that the control is a direct child of the `<li>`; it is, because the `@if` block sits at that
level, but a Razor construct between them would break the selector while the contract fact still passed.
**`KitchenJourneys.OpenAsync` on the administrator's page** navigates away from `/administration/menu` and
the closing assertion navigates back; the administrator is permitted on `/kitchen` by §3.7 and by that
method's own summary, but no scenario had previously used that page as *both*. And **`Facts["Available"]`
is an indexer rather than a `TryGetValue`**, deliberately: after F-113 a missing key means the panel
stopped rendering that row, and a `KeyNotFoundException` naming the key is a better failure than a null.

## Open items carried

**No end-to-end scenario drives either resequencing verb.** The 375px barrier measures those controls and
nothing presses them. Carried, and now the only such gap in the menu.

**`/kitchen` has no §16.3 scenario at all.** Carried; the largest end-to-end gap in the application —
though scenario 21 now opens that board and presses one control on it, which is the first time any scenario
has.

**The wide layout stacks each row's three controls** on the administration index. Carried on two registers.

**Nothing in this repository measures §11.1 at 375px.** New, and named rather than carried silently: the
handheld barrier is scoped to §11.4's surfaces, and this slice is the first to change the guest menu's box
model. A scenario 16 for the guest surface is the repair, and it needs a seated guest, which is why it is
recorded rather than done here.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past five thousand one hundred lines.

---

# M6 Slice 61 — the controls the barrier had been measuring, and a comment that described somebody else

**The oldest open item this project carried, and it outlived four stages.** Stage 3a shipped
`ResequenceMenuSectionsAsync` and its two buttons in Slice 47; Stage 3b shipped
`ResequenceMenuItemsAsync` and its two in Slice 48, and closed with the sentence this slice exists to
discharge: *"No end-to-end scenario drives either resequencing verb. §16.3's scenario 17 is not extended,
so nothing asserts through a browser that a heading or an item moves. The barrier measures the controls;
nothing exercises them."* Stage 3c repeated it, Stages 4a–4f and 5a–5c carried it, and by Slice 60 it was
the only end-to-end gap left in the menu.

**No session-memory drift, for the first time in five sessions.** The SHA-256 reconstruction from
`dump.txt` verified **374 of 375 files byte-exact** and agreed with the incoming belief on every fact:
Slice 60, specification v1.45, ledger through F-113, twenty-one §16.3 scenarios, carried prediction 1281.
The two files that did not verify are the two that never do — `export.sh`, whose dump rewrites its own
header into the copy it embeds, and `LICENSE`, which the dump elides to metadata deliberately. Nothing was
reconstructed on a guess.

**The baseline is a prediction rather than a measurement, and that is stated first.** Slice 60 measured
1279 and predicted 1281; no run of 1281 exists. So this slice's arithmetic rides on an unverified number,
and reconciling 1281 against a real run is the first thing to do before reading anything below.

## Why the open item was so easy to carry

**The controls were never unasserted.** §16.3 scenario 16 has measured them since the slice each landed in
— where they sit, how tall they are, that they lie inside a 375px viewport — and Stage 3b even recorded a
small finding about that: `.record-actions button` had matched *nothing* until the item rows became the
first submit controls to render in one. So every re-reading of the open item met a page whose controls were
demonstrably on the screen, in a repository whose data-access layer asserts both verbs against a real
PostgreSQL. The deferral read as diligence, and the sentence justifying it was never re-examined — which is
**F-109's mechanism**, recorded in Stage 4f and now observed on a second kind of deferral.

**What the two existing instruments have in common is that neither presses anything.** A barrier measures
where a control *is*. An integration fact calls the write service directly. The gap between them is
precisely what a browser adds, and naming it is what makes the scenario worth its minutes.

## The three claims only a browser can make

**A press reaches the form that owns it.** Every heading renders two static-SSR forms named from its own
identifier and every item row two more from its own, so scenario 17's menu carries twelve distinct
`@formname` values on one page. Blazor dispatches a POST to the form that names it; a dispatch that routed
a press to the wrong one would move the wrong heading and **report success**. Nothing below the browser can
see it, because nothing below the browser renders a form.

**An already-open menu re-orders itself.** Both verbs publish `MenuChanged` on `Resequenced` and on nothing
else, and §11.1 renders headings and items in stored order — so a resequence changes the shape of every open
guest picker without a name, a price or an availability flag having moved. `MenuWiringTests` asserts the
publish against a fake broadcaster; whether a phone at a table re-reads is a different claim.

**An item moves within its heading and nowhere else.** §7 makes a position a position *within* a heading, so
the index sends that heading's ordering and not the menu's. The failure this catches is a page that sent the
whole menu and renumbered the starters because somebody moved a pudding — caught only by asserting the
heading that was **not** touched, which is why both halves are read.

## Three rulings about the scenario's shape

**Scenario 17 is extended rather than a scenario 22 added**, on the reason Slices 59 and 60 both gave and
which is now this project's default: the arrangement already exists. Seventeen ends with three headings, a
two-item heading, an empty heading, and a guest whose circuit has been open across five broadcasts. A
scenario 22 would have cost a second container, a second passkey registration and a second join to arrange
what is already standing. The suite therefore stays at **twenty-one**.

**Both directions of both controls, each with its restoration**, and the restoration is the stronger half.
A resequence writes **absolute** positions `0…n-1` over the list it was sent, so an implementation writing a
relative offset — or the right rows in the wrong order — gets the first move right and cannot get the move
back right as well. And a page that wired Up and left Down inert passes every assertion scenario 17 held
before this slice.

**The count of `reordered` events is deliberately not asserted.** One event per row that *actually moved* is
the no-op rule, and it belongs to `MenuSectionResequenceTests` and `MenuItemResequenceTests`, which run
against a real database and can count rows. A browser reading the *Recent activity* feed would be a weaker
instrument for the same claim, and the section half is not even visible there — `menu_section_event` has no
cross-section feed, on the standing rule that a read with no caller is a defect.

## A §11.4 ruling that turned out to have no assertion anywhere

**"Disabled rather than omitted" had never been checked.** Both controls are rendered on every group and the
one that would exchange with nothing is disabled, because a control that vanishes at the end of a list moves
every other control up a row on the render after a move — and scenario 16 measures where controls *are*. The
ruling is in §7, in §11.4 and in the component's own comment, and nothing in the tree had an opinion about
it. A page that omitted the edge control would have satisfied every existing assertion including the
barrier's, whose floor merely counts controls and would have counted fewer.

Discharged in two halves, deliberately. **Presence is the reader's**: `ReadMenuIndexAsync` refuses a group
carrying anything other than two move controls, so the omit-at-the-edge implementation fails in the harness
with a sentence naming the heading. **Enabled-ness is the scenario's**: the first heading offers no Up, the
last offers no Down, the middle offers both. The split is the one `MenuCard` already makes between §7's
`disabled` and the chip beside it — whichever of the two is the contract is the one to read.

## Two harness journeys, and one selector that was refused

`MoveMenuHeadingAsync` and `MoveMenuItemAsync` find the group by its own *Manage this heading* link and the
row by its own management link, which are the only identifier-keyed things in each — matching on a visible
name would make a journey depend on copy, which is the mistake choosing a guest menu card by its formatted
price would be. The item journey is scoped to `div.menu-group-body`, which keeps the row out of the *Recent
activity* feed at the foot of the same page: that table links to the same route with the same class and has
no move controls at all, so an unscoped match would find a row and then fail looking for a button, naming
the wrong thing.

**Blazor's reserved `_handler` field was the obvious selector and is refused.** Static SSR renders each
`@formname` into a hidden input, so `input[value='menu-section-move-up-{id}']` would name the exact form —
and it would make a harness selector depend on a framework's private wire format rather than on anything
§11.4 promises. What is read is what an operator sees.

**A disabled control is refused immediately rather than clicked.** Playwright waits for a control to become
enabled and then times out, so pressing the first heading's Up would cost thirty seconds and report a
timeout on a page behaving exactly as specified. One line instead.

**The confirmation is matched case-sensitively, and that is what makes it decidable.** A resequence has
three outcomes and §11.4 writes a sentence for each; only one wrote a row. The stale-set sentence ends *so
nothing was moved*, so a case-insensitive search for the word would accept the one outcome the journey
exists to reject. `Moved.` with a capital and a full stop occurs in exactly one of the three. What the flash
cannot say is **which verb ran** — §11.4 renders the same sentence for a heading and an item, correctly,
because an operator knows which button they pressed — so the scoping carries that claim instead.

## The finding found on the way in — F-114

Opening `AdministrationJourneys.cs` to add the journeys turned up something better than the slice's own
subject. **A documentation comment can describe a member other than the one it is attached to.** A `///`
block binds to the next declaration; C# has no file-level documentation comment; and a block holding two
`<summary>` elements compiles, publishes malformed XML documentation, and renders whichever one the tooling
reaches first. **Eight were in the tree, in five files, one under `src/`.**

| Site | What it did |
| --- | --- |
| `HiddenRecords.razor` | `ListPath`'s comment on `IsExpanded` — a production component |
| `OrderTestWorld.cs` (INSERT) | **a falsified claim preserved above its own correction** |
| `OrderTestWorld.cs` (`AddMenuItemAsync`) | the Slice 38 account stacked above the Slice 40 one |
| `AdministrationJourneys.cs` (head) | the class's essay bound to a three-member record |
| `AdministrationJourneys.cs` (index reader) | orphaned by Slice 59 inserting a method between comment and subject |
| `RestaurantInstance.cs` | several hundred words on child processes bound to a four-member record |
| `CounterJourneys.cs` | a forward and an inverse whose comments were swapped |
| `TableOrderJourneys.cs` | `ReadBadgeAsync`'s comment on `ReadPriceAdjustmentsAsync` |

**The second row is what gives this a number rather than a tidy-up.** `OrderTestWorld`'s
`menu_item_event` INSERT carried its own pre-F-86 description — *the payload columns `0004` and `0005` added
are omitted rather than passed as NULL*, and *the casts on the two columns that remain* — six lines above a
statement that lists all five and casts all five. **F-86 wrote its correction underneath the claim it
falsified instead of over it**, and because two summaries are legal the falsified sentence stayed first for
twenty-two slices. So this mechanism does not merely misplace prose: it preserves a refuted claim in the
position a reader meets first, with nothing in the repository able to report it. That is F-109's lesson
applied to a **repair** rather than to a deferral — a justifying sentence is not re-examined, because
re-examination is not what re-reading is for.

**All eight are repaired.** An orphan moves onto the member it describes; where two summaries describe the
**same** member the superseded one is **deleted** rather than merged, on F-77's ruling and F-89's precedent,
because a stale account of a member is the same artefact as a stale count of one. Each repair leaves a
paragraph saying what moved and why (F-70).

**And the rule is made executable, because it is total.** XML documentation gives a member one summary and
every other element it may carry is unaffected, so there is no legitimate second one to exempt. That puts it
in **F-81's class rather than F-104's**: decidable from text with certainty, and therefore a consequence of
the language rather than of anybody's preference. Subject computed, no file named (F-58). An escaped mention
is outside the rule by construction rather than by exclusion, which matters because every repair above
refers to the tag that way — **F-67's distinction between a use and a mention, in a third form**.

**Writing the sensitivity proof found this gate's own instance of its subject.** The synthesised defect,
written as a raw string literal, would have put two consecutive `///` lines carrying a summary each into the
test file — which the walk reads as text and cannot tell from a real comment. The first emulation reported a
finding on the file proving the gate works. The fixtures are composed at run time through a helper instead,
and the marker never appears in the file.

## Why two changes in one slice

The scenario fails as a named step of one Playwright fact in `MyRestaurant.EndToEnd.Tests`. F-114 fails as
one of two named unit facts in `MyRestaurant.WebApplication.Tests`, computing over source text, and its
eight repairs change no behaviour whatsoever. Neither can make the other red and a red run names which,
which is v1.32's distinguishable-failure exemption. **The gate could not have shipped later than the
repair**, because a gate on a tree that violates it is red on arrival — and the finding was found inside the
file the scenario needed, which is F-93's timing for the ninth time.

## §18 arithmetic

| Where | Facts | Running |
| --- | --- | --- |
| Baseline — **predicted, not measured** | — | 1281 |
| `DocumentationCommentContractTests` (new) | +2 | 1283 |

**Predicted 1283**, and the §16.3 suite stays at **21** — scenario 17 is extended, not joined. Two facts
rather than three: the resequencing work adds assertions *inside* an existing `[Fact]`, and the eight F-114
repairs add none at all.

**A deviation here is not attributable to this slice alone**, and that is the honest statement. The baseline
was carried rather than measured, so a run returning 1281 means the new class did not execute, a run
returning 1279 means Slice 60's two facts are also missing, and anything else needs Slice 60 reconciled
first.

## What was verified, and what was not

**Verified mechanically.** The new gate was emulated over the edited tree with both non-vacuity floors:
**302 files opened, 2,389 documentation comments parsed, no comment holding more than one summary** — and
**proven sensitive by a planted defect**, reintroduced into `HiddenRecords.razor` and reported at the right
line, then removed. Its three synthesised shapes were run through the same reader: the stacked defect
reports two summaries in one block, the escaped mention reports one, and two adjacent members read as two
blocks. The §16.4 counted-class gate was emulated over the edited specification: **34 classes, no
ambiguity, no disagreement between any claimed count and its file**, with `MinimumCountedClasses` moved
33 → 34 in this slice per F-73's surviving habit. The Markdown table gate was emulated with the real
unescaped-pipe splitter over all **25** tracked documents — **45 tables, 440 rows, clean**. The version gate
was emulated: header 1.46, newest entry 1.46, **47** entries strictly descending. The standing authoring
scans ran over every changed file: no `await` in an interpolated hole (CS4007), **no plain literal in a
`string.Create` chain (CS1620** — three were introduced and all three corrected, and the scan confirmed the
tree had no prior instance), no `@section`, no tabs, no CR bytes, one final newline each, no whitespace-only
or trailing-space lines.

**Not verified.** Nothing was compiled and nothing was run (F-71's standing caveat). The specific risks, in
order. **The scenario's four new waits are the largest**, because each depends on a §9 broadcast reaching an
open circuit and none of them has ever been observed for these two verbs — if a wait times out, the
question is whether the publish happened or whether the predicate is wrong, and the predicates read
`observed[0].SectionName`, which is DOM order rather than anything the surface promises by name.
**`ReadMenuIndexAsync` now throws on a group with anything but two move controls**, which is a new way for
scenario 17 to fail that has nothing to do with ordering; it is the right place for that claim but it means
a §11.4 markup change now fails in the harness rather than on the page. **`MenuHeadingOnTheIndex` gained two
members**, and although the only construction site is inside the reader itself, a positional record is a
positional record. **The `[href$='/{id:D}']` suffix match** on the item row assumes no other link on that
page ends with the same identifier; the *Recent activity* feed does, which is why the selector is scoped —
if the scoping is ever loosened that selector becomes ambiguous. And **F-114's eight repairs moved prose
between declarations**, so a mis-anchored move would be a comment describing the wrong member again, in the
slice whose subject is exactly that; the gate cannot see it, because one summary in the wrong place is still
one summary.

## Open items carried

**`/kitchen` has no §16.3 scenario at all.** Now the largest end-to-end gap in the application by a clear
margin. Scenario 21 opens that board and presses one control on it, which is the only thing any scenario has
ever done there.

**The wide layout stacks each row's three controls** on the administration index. Carried on two registers
since Slice 47 — and this slice pressed those very controls without opening `app.css`, which is one more
slice of evidence that nobody minds enough to.

**Nothing in this repository measures §11.1 at 375px.** Carried from Slice 60. The handheld barrier is scoped
to §11.4's surfaces and the guest menu's box model changed in that slice.

**A member with no summary at all is not reported by the new gate.** Named on arrival rather than
discovered: asserting that every member is documented would be a gate about how much prose this project
writes, and it would report findings on hundreds of correct one-line helpers.

**`run.sh --containers-only` prints two `Error:` lines about a container that does not exist yet, then
starts it successfully.** Carried.

**Nothing decides when the next tranche of the log moves to the archive.** Carried. `BUILD_PROGRESS.md` is
past five thousand three hundred lines, and this entry is the longest addition in six slices.

---

# M6 Slice 62 — the wall that was documented for eleven slices, and the refusal the endpoint now decides

**Session started with the reconstruction ritual, and it caught drift for the fifth time.** The tree was
rebuilt from `dump.txt` with SHA-256 verified per file: **374 of 375 verified, one elided by the exporter
(`LICENSE`, metadata and digest only), zero unexplained mismatches.** Two apparent mismatches, both
accounted for and both an artefact of the reader rather than of the dump — `LICENSE`, whose metadata block
was briefly reconstructed as content, and `RestaurantTimeTests.cs`, which is the last file in the dump and
had swallowed the `DUMP SUMMARY` footer; trimmed, its digest then matched
`a378f355cbe0…` exactly.

**The drift was one slice, and it was the session's own memory that was behind.** Carried state said Slice
60, specification v1.45, 1281 predicted, `MinimumCountedClasses` 33, highest finding F-113. The tree at
commit `ff2155d` said **Slice 61, v1.46, 1283 predicted, floor 34, F-114**. Nothing was authored before
that was established.

## What this slice is, and why it is a menu slice with no menu in it

`docs/MENU_AND_HANDHELD_PLAN.md` has had an **empty open list since Slice 60** — every read and write
`0008` introduced has a caller, and no verb in §7 lacks a surface. The only thing left in the plan is
**Stage 6, comments**, recorded as *not startable* on four prerequisites, of which the first reads: a
comment needs a rate limit, and §17 says the rate limiter cannot take a second policy. The plan also
predicted the shape of the fix — *"a rate-limiting slice with no menu in it"*.

So this is that slice. It lands on `/register` rather than on comments, because `/register` is the surface
that needed a limit **on its own merits** and whose absence of one was already a recorded risk (F-37),
and because a limit on a surface that does not exist yet is not testable. Comments inherit the
**mechanism**, not the policy.

## F-115, and the finding is the eleven slices rather than the arrangement

§17 has said since **v1.1** that `/register` has no rate limit; that the reason it is not a two-line
addition is that `RateLimiterOptions.OnRejected` and `RejectionStatusCode` are single-valued, so a second
`AddRateLimiter` silently takes the refusal wording from the first and a refused registration would answer
with §4.2's *"Too many pairing attempts from this device"*; and that doing it properly means `OnRejected`
dispatching on the endpoint. **Every one of those three was correct when written and stayed correct.**

The limiter meanwhile was configured inside `AddRestaurantDisplays`, where the only policy happened to
belong — which made a display-device extension the owner of the rejection handler for every surface that
might ever acquire a limit, and put the wall in a file neither `/display/pair` nor `/register` mentions.

**What earns this a number is not the arrangement, it is that nothing could tell a documented wall from a
closed one.** §17 is a list of *accepted risks*, and in that list an accepted risk and an unstarted repair
are the same shape. F-37's ledger row said *no rate limit in v1, with the reason it is not a two-line
addition recorded* — which reads as a decision somebody made, not as work in a queue. It surfaced only
because a **plan** named it as prerequisite 1 of something else, which is the third instance of a pattern
F-35 and F-37 already established: found by somebody trying to *use* the thing.

## The mechanism, in one sentence per decision

**One `AddRateLimiter`**, owned by `Security/RateLimitingServiceCollectionExtensions.cs` rather than by
any surface's extension method, reading nothing but `RateLimitedSurfaces.All`.

**A policy with no sentence does not compile.** `RateLimitedSurface` has three `required` members —
policy name, refusal sentence, partitioner — so the thing §17 was afraid of is unrepresentable rather
than discouraged, and that cost nothing to get.

**The dispatch reads the middleware's own metadata.** `OnRejected` resolves the refused policy through
`GetEndpoint()?.Metadata.GetMetadata<EnableRateLimitingAttribute>()?.PolicyName` — *the same read the
middleware performed one instant earlier to select that policy*. This is not a heuristic recovering lost
information: a lookup that failed would be describing a request that could not be being refused.

**The fallback is about honesty rather than coverage.** It is kept because
`EnableRateLimitingAttribute.PolicyName` is nullable and because a global limiter would refuse with no
attribute in scope — and its stated property is that an unidentifiable policy is answered **vaguely,
never wrongly**. §17's objection was never to a vague sentence; it was to a wrong one that looks
deliberate.

## Two rulings about where a name lives, and one about a keyword

**The pairing policy name moved; the pairing budget did not.** A policy name is a key three unrelated
readers agree on (the page's attribute, the registration, the dispatch) and there are now two of them, so
the list is its only honest home. The budget is §4.2's normative number about one area with no operator
decision in it, so it stayed on `DisplayRoutes`. That line — *names the limiter owns move, numbers §4.2
owns stay* — is the reason `DisplayPair.razor` changed in this slice and `DisplayRoutes`'s two integers
did not.

**`GenericRefusal` is `static readonly` and not `const`, and that keyword is load-bearing.** It keeps the
set of public string *literals* on the type equal to the set of policy names, which is what lets the gate
assert *every public string constant here is a policy* rather than *every one whose name ends in a word
somebody chose*. A convention would have made it a gate about spelling; the keyword makes it a gate about
the type — F-67's use/mention distinction one register down.

## The budget, which is a ruling about a NAT and not about a threat model

**The partition is a client address, and over the tunnel a client address is a whole dining room.** Guests
reach `/register` from the restaurant's own wifi through Cloudflare, so `UseForwardedHeaders` faithfully
reports **one public address for every one of them**: a per-address limit on this surface is a
**per-venue** limit. §4.2's surface has no such property — a member of staff installs one tablet — which
is why 5 per minute is right there and would be indefensible here.

Two consequences, both of which look like laxity and are not:

- **The default is sized for a full room rather than against an attacker.** 60 attempts per 10 minutes;
  six a minute sustained with the whole window available as a burst. There is no secret to guess at this
  endpoint, so the limit is a **volume ceiling**, and F-37's finding stands that the worst outcome of
  exceeding it is *rows* rather than access.
- **The floor protects guests, not the server.** Ten attempts minimum — the inverse of every other bound
  in §13, and stated as such in the constant's own summary. The costs are asymmetric: too loose is spam
  rows, accepted on the record by F-37 and holding no capability; too tight is a *seated guest who cannot
  create the account they need in order to order dinner*, at a table where staff have no remedy and no
  diagnosis, because the browser shows a plain-text refusal and nothing anywhere names the knob.

**Configuration rather than a constant, because the right number is a property of the room** — which this
repository cannot know and must not guess on an operator's behalf. That asymmetry with pairing's constant
is written into `RateLimitedSurfaces`' summary so it is not tidied into symmetry later.

## What this slice deliberately did NOT do

**No `REQUIREMENTS.md` revision.** Revs 3 through 6 each added exactly one cross-cutting §8 principle for
**new intent**. A limit on `/register` is a mechanism catching up to intent §17 had already recorded, so
this is rev 2's reasoning rather than rev 3's. Nothing in that document moved.

**Stage 6 is not struck through.** It had four prerequisites and this discharges one. The plan now reads
*one of four discharged*, gains **Stage 6a** recording what landed, and strikes through prerequisite 1
only. Striking the stage would claim it is startable, and it is not: the guest-privacy revision, the
moderation surface and §11.11's rendering rule all still block it.

**No comment budget was chosen.** Stage 6a says explicitly that a comment's number will not be this
number — the *shape* of the question transfers (per-venue partition, generous default, floor protecting
guests) and the arithmetic does not.

**`0008_menu_item_reactions.sql` line 57 was left alone.** The hygiene emulation found a trailing space
there. It is pre-existing, it is **outside the tree gate by that gate's own explicit ruling** — gate 2
fails only on lines made *entirely* of whitespace, because two trailing spaces in Markdown are a hard line
break and forbidding those would be wrong about Markdown rather than right about whitespace — and
repairing it here would be an unexplained edit to a migration in a slice about rate limiting. Recorded,
not fixed, and not a finding.

## §18 arithmetic

| Where | Tests | Running |
| --- | --- | --- |
| Baseline — **carried from Slice 61, predicted, not measured** | — | 1283 |
| `DisplaysWiringTests` — the limiter fact moves out | −1 | 1282 |
| `RateLimitingContractTests` (new) — six facts | +6 | 1288 |
| `RestaurantOptionsTests` — two facts, two theories at three and two cases | +8 | 1296 |

**Predicted 1296**, and the §16.3 suite stays at **21** — no scenario was touched.

**The theory arithmetic is the part to read twice.** Five new attributes produce **eight** tests, so a run
returning **1293** means the theories were counted as facts rather than that anything failed. And the
baseline was carried rather than measured for the second consecutive slice: **1281 means
`RateLimitingContractTests` did not execute, 1279 means Slice 61's two facts are also missing**, and
anything else needs Slice 61 reconciled before this slice is blamed.

## What was verified, and what was not

**Verified mechanically, all green.** The §16.4 counted-class census was emulated over the edited
specification: **35 classes, no ambiguity, no disagreement between any claimed count and its file**, with
`MinimumCountedClasses` moved 34 → 35 in this slice per F-73's surviving habit — and the emulation is
**exact at the floor**, not merely above it. The Markdown table gate was emulated with the real
unescaped-pipe splitter over every tracked document: **48 tables, 460 rows, clean.** The version gate was
emulated: header **1.47**, newest entry **1.47**, **48** entries strictly descending, and
`REQUIREMENTS.md` still self-consistent at rev 6. The configuration-surface gate was emulated in all five
of its assertions: **19 keys** read out of `FromConfiguration`, none bound twice, every one of them
present in `compose.yaml`'s `web` environment mapping, in `.env.example`, and in §13's table, and every
name a refusal message in `Validate()` uses is a name the binding method reads. The compose-substitution
gate was emulated: every variable interpolated in that mapping is assigned in `.env.example`. Byte hygiene
was checked against the repository's **own** rule over all 373 authored files — no CR, exactly one final
newline, no line blank-but-not-empty — and against the stricter `.editorconfig` rule over this slice's
seventeen files only. The standing authoring scans ran over every changed file: no `await` in an
interpolated hole (CS4007), no plain literal in a `string.Create` chain (CS1620), no `section` identifier
in any Razor file.

**Two of those scans were wrong before they were right, and both are worth recording.** The CS4007 scan
initially matched *any* brace block containing `await`, which is every async method in the tree; it now
walks each `$"…"` literal and inspects only its holes. The `@section` scan initially ran over `.cs` files
and reported two contract tests with a perfectly legal local named `section`; RZ2005 is a **Razor**
diagnostic, so the scan is now scoped to `.razor`. A gate emulation that reports findings on a correct
tree is F-41 from the other direction, and both would have wasted a real session.

**The census gate caught a defect in this slice's own authoring, which is the best thing that happened
here.** The first insertion of §16.4's new paragraph put a blank line before it and none after, so it
fused with the compose-dependency paragraph below. The emulation reported
`ambiguous: [RateLimitingContractTests.cs, ComposeDependencyContractTests.cs]` and the count fell to
**33** — the new paragraph uncounted *and* an existing one knocked out of the census. That is F-72's
mechanism exactly: nothing was wrong in the source, it was wrong only once **rendered**.

**All six new assertions were proven sensitive by planted defects, none vacuous.** Each assertion was
re-implemented over the same inputs the C# reads — the surface list parsed out of `RateLimitedSurfaces.cs`,
the tree scan walking the same files with the same pattern — then run against the tree and against nine
planted defects. Deleting a surface from the list was reported by assertions 1 and 5; giving both surfaces
the pairing sentence, and giving registration the fallback sentence, by assertion 2; a policy constant no
entry registers, by assertion 5; the page opting in with a bare string literal, and with an unregistered
member, by assertion 4; and leaving `RejectionStatusCode` at the framework default, never assigning
`OnRejected`, and adding policies from anywhere but the list, all three by assertion 6.

**Not verified, and one of these is a gap in the emulation rather than in the tree.** Nothing was compiled
and nothing was run (F-71's standing caveat). The specific risks, in order.

**`Register.razor` is the largest**, because Razor is where this tree's compiler errors live: it gained two
`@using` directives and an `@attribute` whose argument is a member access on a type in a namespace that
page had never imported. F-104 and F-81 were both one character in a `.razor` file.

**Assertion 3's sensitivity is argued rather than demonstrated.** The emulation *reimplements*
`RefusalFor` rather than executing it, so planting into that method proves the emulation sensitive and not
the C#. What was checked instead is textual and weaker: the method returns `GenericRefusal` for null and
empty, matches with `StringComparison.Ordinal`, contains no case-insensitive comparison, and falls through
to `GenericRefusal` after the loop. The assertion itself is the strongest one in the class on paper and
the least proven here.

**No assertion anywhere in this repository proves that a static-SSR Razor endpoint carries
`[EnableRateLimiting]` in its endpoint metadata.** Everything asserted here is about the list, the lookup,
and the tree; none of it proves a 429 was ever produced by a request, or that the middleware ever selected
either policy. **If that assumption were false, both surfaces are unlimited and every test still passes** —
and `/display/pair` has run on it since Slice 22, which is why it is recorded as carried rather than as
new risk.

**The registration partitioner resolves `RestaurantOptions` from `RequestServices` per request**, which is
correct for a singleton and untested: nothing here proves the service is resolvable from that scope at the
moment the limiter runs, and a failure there is an exception inside a rejection path.

**Whether `Security` referencing `Configuration` and `Displays` creates a folder-convention cycle** was
not checked. It is legal C# — one assembly — but this tree has a dependency direction it takes seriously
and no gate expresses the intra-assembly half of it.

## Open items carried

**`/kitchen` has no §16.3 scenario at all.** Carried, and still the largest end-to-end gap in the
application by a clear margin.

**The wide layout stacks each row's three controls** on the administration index. Carried on two registers
since Slice 47.

**Nothing in this repository measures §11.1 at 375px.** Carried from Slice 60.

**Nothing decides when the next tranche of the log moves to the archive.** Carried, and now more pressing:
`BUILD_PROGRESS.md` is past five thousand six hundred lines.

**Three of Stage 6's four prerequisites.** New, and the only open item this slice created — the
`REQUIREMENTS.md` revision about guest privacy, the moderation surface, and §11.11's rendering rule. The
menu enhancement's own open list is still empty.

---

# M6 Slice 63 — a gate that could not tell a use from a mention, and the menu plan's rendering rule stops being a sentence

**Two changes and one instrument.** The instrument is a comment-blind source reader; the changes are the gate
that shipped broken in Slice 62 and Stage 6b of the menu plan. Their failure modes are unrelated — one is a
policy-name scan reporting a horizontal ellipsis, the other is an equality against a recorded set of markup
sites — so the "one change, one green run" rule is satisfied by them being distinguishable rather than by
being separated.

## Drift, and it was two slices this time

The session began, as every session must, by reconstructing the tree from `dump.txt` and verifying every
file's SHA-256. **380 files, two mismatches, both benign**: `export.sh`, which contains its own
`${SCRIPT_NAME}` record and therefore cannot hash to itself, and `LICENSE`, which the dump elides by design.

**Carried session memory said Slice 60 and specification v1.45. The tree is Slice 62 and v1.47** — drift of
two slices, caught by the ritual for the fifth time. Baseline test count **1296**, predicted at Slice 62 and
carried rather than measured for the third consecutive slice. §16.3 stands at **21** scenarios.

## F-116 — the failure that arrived, and why it is not a bad regex

The reported failure was one assertion:

```
failed RateLimitingContractTests.EveryOptInInTheTreeNamesARegisteredPolicy
  src/MyRestaurant.WebApplication/Security/RateLimitedSurfaces.cs opts in with '…',
  which is not a member of RateLimitedSurfaces.
```

`RateLimitedSurfaces.cs` line 23 is a documentation comment: *"The page opts in with
`[EnableRateLimiting(…)]` naming this value."* The scan's pattern is `EnableRateLimiting\(`, and its own
summary said the open parenthesis was load-bearing on **F-67's** authority — *it distinguishes a use of the
attribute from a mention of it in the prose explaining one, and this file's own subject guarantees such prose
exists.*

**The second clause is true and the first does not follow from it.** F-67 is a ruling about an *identifier*:
a gate keying on `Foo` reports every sentence containing the word and one keying on `Foo(` does not. It does
not transfer to a *form*, because a documentation comment explaining an attribute writes the attribute out,
placeholder argument included — that is what an explanation is. So the gate and the prose it could not read
shipped in the same archive, and the first run against a real tree reported **a finding on a correct tree**,
which is F-41 arriving from the side that costs a session rather than the side that costs coverage.

**This was not the operator's hand-fix.** The commit under review is *initialize required members*, which is
`RestaurantOptions`' two new `required` properties reaching their construction sites — an authoring omission
of Slice 62's, and correctly repaired. The scan defect was already in the tree it repaired.

**Two things lift it to a numbered finding.** Slice 62's own log records that two of its *emulation* scans
had this exact defect, were caught, and were fixed before delivery, with the observation that *a gate
emulation that reports findings on a correct tree is F-41 from the other direction* — one paragraph from the
same defect shipping in the gate. And that log states the sensitivity proof walked *the same files with the
same pattern*, which it cannot have done, because doing so would have failed. **An emulation shares an author
with the thing it checks, so it inherits whatever the author believes about the tree — and the belief is what
is wrong when a gate is wrong on arrival.** That went into `DOCUMENTATION_REVIEW.md`'s *Going forward* with
two cheap habits: run the emulation over the reconstructed tree rather than over a summary of it, and treat a
session catching this defect in its own emulation as a report about the gate.

### The remedy is the input, not the pattern

`SourceCode.WithoutComments` — a comment-blind reader of source text. The pattern is untouched; what changes
is what it is given. Both tree scans in this slice go through it, so the repository holds **one decision
procedure for *is this occurrence code*** rather than one per gate, which is F-50, F-56, F-65 and F-107's
shape refused before it forms.

**The prose is deliberately not reworded**, and this is the ruling most likely to read as laziness. Deleting
one parenthesis is a one-character fix that works today and fails on the next correct sentence somebody
writes. Leaving the mention where it is makes the reader *load-bearing*: planting a no-op reader reports both
of the tree's mentions at once, so the tree now carries its own permanent sensitivity proof. §18 records the
habit, and records that keeping a mention a gate must not see is a decision rather than an oversight.

**It is a lexer for four comment forms and not a C# parser, and the residual is stated in §18.** A multi-line
verbatim or raw string literal is read as code on its inner lines; a literal opened inside an interpolation
hole is mis-paired for the rest of its line. **Both failures lose code**, which is the safe direction, and
every consumer asserts a floor on what it found so that losing a real site fails loudly. Prose surviving as
code cannot happen, because a comment marker outside a literal always wins.

## Stage 6b — the menu progress, and it is a prerequisite rather than a feature

Stage 6 (guest comments) has four prerequisites. Slice 62 discharged the first. **This discharges the
fourth**, and the menu enhancement's own open list was empty, so a prerequisite was the only menu work
available that was not new intent.

Prerequisite 4 said comment text goes through Razor's default encoding and must never reach a
`MarkupString`. ADR-0014 says the same about an item description. §17 says something stronger and depends on
it: `script-src 'self'` with no hash, nonce or `unsafe-*` is a **second line of defence**, which is only true
if the places this application bypasses Razor's escaping are a small closed set of values it computed itself.

**That claim was written as a count — *the six `MarkupString` sites* — in four places and enforced in none**:
§17's threat paragraph, `ResponseSecurityHeaders`' summary, and the two F-49 ledger rows. Correct on all
thirty-nine slices since it was written, and exactly the artefact recorded under F-73, F-77, F-89, F-105,
F-111 and F-112.

**A seventh site is one line of markup** — it compiles, renders, and reviews as unremarkable, and it turns an
escaped field into an injection point. The policy would keep injected script inert and keep nothing else
inert, because markup this application serves from its own origin sits inside `'self'` and no directive
distinguishes it from markup this application wrote. A comment is the first content one guest writes for
another guest to read, so the first line of markup that ever wants to be raw is the one Stage 6 would write.

`RawHtmlContractTests` holds the set as a `path → count` record and compares it against the tree in both
directions. All six recorded sites render an SVG QR code built from a value this application minted — a
rotating join token (§4.3), a pairing code (§4.2), a TOTP enrolment URI (§3.4).

**The undecidable half is refused rather than approximated.** Whether a value was authored by a person is a
fact about where it came from several calls away, not a property of the text, so asserting it would be
reaching past what the gate can decide (F-41). What is decidable is *where* raw HTML is produced, and a
closed set converts the undecidable question into a **human** one asked in the commit that adds a site.

**The two F-49 ledger rows keep their count.** A ledger row is a dated account of what was true on a date;
editing one is rewriting history rather than removing a duplicate. Only live claims lost the number.

## F-117 — found on the way in, and it is the cheapest instance of an old shape

§16.4's paragraph on the response-header tests read *"(`…/Security/`, three classes in the `unit` job) … they
are three rather than one because they assert three different kinds of thing."* **Slice 62 made it four. This
slice would have made it five.**

Nothing in this repository can see it, and the reason is exact rather than accidental:
`TestingSectionContractTests` compares *assertion* counts against `[Fact]` attributes, so it reads `three
classes` and `three different kinds of thing` as ordinary prose and discards both — correct behaviour, since
neither is the claim it exists to check. **F-77's shape for the ninth time and F-112's for the second**, in
its cheapest possible instance: a number `ls` answers. Deleted rather than corrected, on F-89's ruling.
Nothing of the argument is lost, because *several classes rather than one because they assert different kinds
of thing* is the argument and *three* was never part of it.

## What this slice deliberately did NOT do

**No `REQUIREMENTS.md` revision.** Stage 6b is a mechanism catching up to intent §17 already recorded, which
is rev 2's reasoning rather than rev 3's. Nothing in that document moved.

**No ADR edit.** ADR-0014's sentence about an item description never reaching a `MarkupString` is now
enforced by a gate rather than by prose, and the ADR carries rationale rather than mechanism — the
correct place for *what enforces it* is §16.4, which has it.

**Stage 6 is not struck through.** Two of four prerequisites stand, and they are the two that were always the
hard ones: the guest-privacy revision, which is new intent and therefore the owner's to make, and the
moderation surface, which is a slice of real work.

**No reflection assertion over `EnableRateLimitingAttribute` was added**, though it was considered and is the
obviously stronger instrument for *which policies the compiled application names*. It was declined because it
does not close the gap the plan actually records — Razor's `@attribute` compiling to a class attribute is not
the same claim as the **endpoint metadata** carrying it, and only the second is what makes the middleware
select a policy. Adding it would have looked like closing that gap while leaving it exactly where it is.

**`0008_menu_item_reactions.sql` line 57 was left alone** for the second slice running. Pre-existing trailing
space, outside the tree gate by that gate's own explicit ruling, and repairing it here would be an
unexplained edit to a migration in a slice about gates.

## §18 arithmetic

| Where | Tests | Running |
| --- | --- | --- |
| Baseline — **carried from Slice 62, predicted, not measured** | — | 1296 |
| `SourceCodeTests` (new) — four facts | +4 | 1300 |
| `RawHtmlContractTests` (new) — two facts | +2 | 1302 |

**Predicted 1302**, and the §16.3 suite stays at **21** — no scenario was touched. `RateLimitingContractTests`
keeps its six facts: the failing one was repaired, not replaced, and none was added.

**The reconciliation to do first.** The reported run showed one failure and did not state a total, so **1296
is still a prediction and not an observation**. If the run returns **1302**, both the baseline and this slice
are confirmed at once. **1298 means Slice 62's eight `RestaurantOptionsTests` additions counted as four** —
the theory arithmetic that slice flagged. **1296 means neither new class executed.** Anything else needs
Slice 62 reconciled before this slice is blamed.

## What was verified, and what was not

**Verified mechanically, all green.** The reconstruction was verified by SHA-256 before anything was authored.
The §16.4 counted-class census was emulated over the edited specification: **37 classes, exact at the floor**,
no ambiguity, and **no disagreement between any claimed count and its file** — `MinimumCountedClasses` moved
35 → 37 in this slice, per F-73's surviving habit. The Markdown table gate was emulated with the real
backtick-and-escape-aware splitter over every tracked document: **49 tables, 525 rows, no width mismatch**.
The version gate was emulated: header **1.48**, newest changelog entry **1.48**, **49** entries strictly
descending, `REQUIREMENTS.md` still self-consistent at rev 6. The documentation-comment gate was emulated over
all 308 source files: **2439 comments parsed, no comment holding two `<summary>` elements** — which matters
because this slice adds three files of dense documentation. Byte hygiene was checked over every changed file:
no CR, exactly one final newline, no trailing whitespace, no whitespace-only line, no dump separator. The
standing authoring scans ran: no plain literal in a `string.Create` chain (CS1620), no `await` in an
interpolated hole (CS4007), no `section` identifier in any Razor file — and no Razor file was touched at all
in this slice, which is the first time in several.

**The reader was verified by transcription rather than by argument, and that is the one methodological change
here.** `SourceCode.WithoutComments` was written in C#, then transcribed back into Python **line for line**
and run over all 169 `.cs` and `.razor` files under `src/`. Results: `EnableRateLimiting\(` matches **3 → 2**,
with both surviving arguments correct; `MarkupString` occurrences **7 → 6**, in exactly the six recorded
files; **newline count preserved in every one of the 169 files**; no file emptied; and structural tokens
confirmed present after stripping in the highest-risk files — the raw-string SQL reader, the component with
CSS comments inside a scoped `<style>` block, and the page with a multi-line Razor comment block.

**Seven planted defects, each caught by the intended assertion.** A new raw-HTML site added to the guest menu
→ *unrecorded*. A recorded site deleted → *departed*, and the floor. A second production inside a recorded
file → *miscounted*. An opt-in written as a bare string literal → *not a member*. An opt-in naming an
unregistered constant → *not a policy-name constant*. **The reader replaced by a no-op** → both of the tree's
prose mentions reported at once, which is the proof that leaving them in place makes the fix load-bearing.
**The reader replaced by one returning nothing** → the total floor and the opt-in argument floor, both.

**Not verified.** Nothing was compiled and nothing was run (F-71's standing caveat). The specific risks, in
order of what they would cost.

**`SourceCode.WithoutComments` is the largest**, because everything else in this slice depends on it and it is
a hand-written state machine over indices. The transcription proves the *algorithm* against 169 real files and
eight synthesised fixtures; it does not prove the *C#*, and the two places a transcription is weakest are the
clamp on the escape advance (`Math.Min(index + 2, lineEnd)`, which is what stops a trailing backslash reading
past a newline) and the `emitted` flag that decides whether a segment is appended after a block comment
opens. Both were transcribed deliberately rather than paraphrased, and both are exercised by the fixtures.

**`Assert.Contains(string, string, StringComparison)` and `Assert.DoesNotContain(string, string,
StringComparison)`** are used throughout `SourceCodeTests` on the pattern already present in
`ContentSecurityPolicyContractTests` and `ResponseSecurityHeadersTests`, so the overloads exist in this
xUnit v3; that is evidence from the tree rather than from a compile.

**`SourceCode` sits in namespace `MyRestaurant.WebApplication.Tests` and is used from
`...Tests.Security` with no `using`**, relying on C#'s outward namespace search. Correct by the language rules
and untested here; a stray `using` would be needed if the file were ever moved into a folder.

**`RecordedSites` is `IReadOnlyDictionary<string, int>` and is read three ways** — `ContainsKey`,
`TryGetValue` and the indexer. All three are on the interface. `CA1859` may suggest the concrete type; it is
informational by default and not an error even under `ContinuousIntegrationBuild=true`.

**Nothing proves the six recorded paths are spelled correctly**, and a typo in one would present as *departed*
plus *unrecorded* on the same file — an ugly failure with an obvious cause. The paths were taken from the
scan output rather than typed.

## Open items carried

**`/kitchen` has no §16.3 scenario at all.** Carried, and still the largest end-to-end gap by a clear margin.

**The wide layout stacks each row's three controls** on the administration index. Carried since Slice 47.

**Nothing in this repository measures §11.1 at 375px.** Carried from Slice 60.

**No assertion anywhere proves a static-SSR Razor endpoint carries `[EnableRateLimiting]` in its endpoint
metadata.** Carried from Slice 62, and this slice declined the reflection assertion that would have looked
like closing it. If the assumption is false, both rate-limited surfaces are unlimited and every test passes.

**Nothing decides when the next tranche of the log moves to the archive.** Carried, and `BUILD_PROGRESS.md`
is now past five thousand eight hundred lines.

**Two of Stage 6's four prerequisites**, and neither is a mechanism: the `REQUIREMENTS.md` revision about
guest privacy is new intent, and the moderation surface is a slice of work. The menu enhancement's own open
list remains empty.

---

# M6 Slice 64 — the surface the contract was written for, measured last, and the control no gate could reach

**One change and one instrument, and they found each other.** The change is Stage 1d: §11.1's guest ordering
surface is laid out at 375×667 by a browser for the first time. The instrument is the handheld barrier
generalised from *§11.4's barrier* to *a barrier over a named surface*. The first run of the second against
the first is what produced **F-118**, which is a barrier doing the only thing a barrier is for.

## The reconstruction agreed with the tree, and the baseline is finally a measurement

The session began by rebuilding the tree from `dump.txt` with SHA-256 verified per file: **381 of 383
byte-exact**, and the two that never verify are the two that never verify — `export.sh`, whose dump rewrites
its own header into the copy it embeds, and `LICENSE`, which the exporter elides to metadata by design. One
file needed trimming before it would hash: `RestaurantTimeTests.cs` is last in the dump and swallows the
`DUMP SUMMARY` footer; trimmed, it matched `7575227f6bf4…` exactly.

**Carried session memory said Slice 60, v1.45, 1281, floor 33, F-113. The tree said Slice 63, v1.48, 1302,
floor 37, F-117** — drift of three slices, caught by the ritual for the sixth time. Nothing was authored
before that was settled.

**And the baseline stopped being a prediction.** The operator ran the suite: **1302 passed, 0 failed, 0
skipped**, across all four assemblies. That is the number Slice 63 predicted, which confirms Slice 62 and
Slice 63 *at once* — the two reconciliation branches that slice named (1298 for the `RestaurantOptionsTests`
theory arithmetic, 1296 for neither new class executing) are both ruled out. This is the first slice in four
whose baseline is an observation.

## Why §11.1 was the last surface measured, and it is not an oversight

Stage 1 of the menu plan is **the handheld contract**. Its 1a gave the tree a vocabulary, 1b converted the
`/administration` area, 1c built the 375px barrier. And 1b's closing sentence said *"what remains is the
counter, kitchen and table surfaces, which were never record lists and were never the subject of F-59"* —
true, and it quietly retired the table surface from the stage.

**But §11.12 is justified by R§1, and R§1 is one sentence about the phone in a guest's hand.** Every slice of
Stage 1 measured the surfaces *staff* use, because that is where F-59 was found. Meanwhile §11.1 acquired
headings and descriptions, a thumbnail on the card and an uncropped picture in the panel, a like inside that
panel, and a second control beside a refused card — **six stages of box model, none of it ever laid out at
the width it is read at.** The plan carried the one-line gap from Slice 60 for four slices while the
enhancement's own open list was empty, which is the same shape of deferral Slice 61 recorded about the
resequencing verbs: every re-reading met a surface that demonstrably worked, and the sentence justifying the
deferral was never re-examined (**F-109's mechanism**, third observation).

## F-118 — a control outside the arrangement the rule is declared against

§11.1's basket renders its staged line's quantity box like this:

```razor
<label class="order-basket-quantity">
    <span>Quantity</span>
    <input type="number" inputmode="numeric" … />
</label>
```

`app.css` declares §11.12's nine control declarations against exactly two selector lists — `.form-field
input, .form-field select, .form-field textarea` and `.manage-inline-form input, .manage-inline-form select`
— and that label is neither. **Exactly one rule in the whole stylesheet matched the control**, `max-width:
8rem`. So it carried **neither half** of §11.12's control rule: no `--touch-target` floor and no 16px font
floor, rendering at a user-agent default of roughly 13px of Arial in roughly 21px of height.

**Where it is matters more than what it is.** This is the guest's own basket. R§1 says guests order from
their own phones, which is the sentence §11.12 exists because of, and on that platform the font floor is a
behaviour rather than a preference: iOS Safari zooms the whole viewport when a focused control's text is
under 16px and does not zoom back out. One staged line therefore breaks the layout of the page around it and
the guest cannot get it back.

**It is F-66's shape a second time.** That finding was four administration detail surfaces declaring their
form controls inline, where *"`.manage-inline-form`'s `input` and `select` carried no `min-height` and no
font floor at all"*. Same defect, same cause, different area — and the second instance is what makes it worth
a section edit rather than a repair.

### Why nothing could see it, stated exactly

`HandheldLayoutContractTests` asserts that `app.css` **declares** the control height and the font floor.
That is arithmetic on text and it is correct; what it cannot produce is the fact that some page put its
`<input>` where the selector does not reach. The 375px barrier reads a real browser and could have seen it —
and was scoped to §11.4's ten surfaces. **The defect sits precisely in the gap between the two levels §11.12
says the contract is asserted at**, which is why the repair comes with a new paragraph in that section rather
than only a line of CSS:

> whether a declared rule *reaches* a rendered element is a third question, sitting between the two levels,
> and only the browser level can answer it.

### And the markup reads as symmetric where it is not

```css
.order-picker-quantity input,
.order-basket-quantity input {
    max-width: 8rem;
}
```

Two quantity boxes named side by side, which reads as a pair of controls treated alike. The declarations that
decide whether they *are* alike sit two hundred lines above: the picker's box is inside a `.form-field` and
inherited the rule; the basket's inherited nothing. **A pair of selectors written together is not evidence
that a pair of controls is covered together**, and that is the transferable half.

### The repair is a selector and never a copy

`.order-basket-quantity input` joins the `.form-field` list, and its focus ring joins the matching one. A
third copy of those nine declarations is the mechanism F-48, F-50 and F-56 each are, and this tree already
carries a second in `.manage-inline-form`. **That second copy is deliberately not folded in**: four
administration surfaces, in a slice about the guest's menu, is a second change with a second failure mode.
Recorded as an open item rather than left to be noticed.

## The barrier is now a barrier over a named surface

`HandheldReach` was named for §11.12 — normative for *every surface, every screen* — while its anchor, its
selector list and its refusal message were §11.4's. The scope was never hidden: §11.12's own closing
paragraph said the browser level *"walks §11.4's surfaces"*. But **the only place it was written in code was
an exception message** telling a reader their page *"is not one of §11.4's administration indexes"*, which a
guest surface arriving at reads as a broken page rather than an out-of-scope one.

A surface is now a value carrying an anchor, three selector groups — reach, height-only, font-floor — and the
membership argument for each. Two entry points:

- **`MeasureAsync`** navigates and waits for the anchor. That is how you arrive at a static-SSR page, and
  scenario 16's ten call sites did not move, because a surface argument threaded through a caller that only
  ever passes one value is an argument that exists to be got wrong.
- **`MeasureHereAsync`** measures the page as it stands. §11.1 needs it: the chosen dish, the open panel and
  the staged line are *circuit state*, so a navigation would destroy the whole arrangement in order to look
  at it.

### The residual scenario 16 named is closed on one surface

That scenario's comment recorded it in as many words — a floor cannot notice a group that grew, only one that
vanished, and attributing each control to the selector that found it was *"a real gate, deliberately not
built in the slice that found the defect"*. It is built. Each selector declares whether the surface **must**
render something it matches, and the census is seeded from the **declared** set rather than counted up from
what was found, so a silent selector appears as a zero — a census assembled from results can only ever list
what exists.

The failure it catches is one this repository has actually had: **`.record-actions button` was in the barrier
from the day it was written and matched nothing until Slice 48**, with nothing able to say which of the two
it was.

**Every guest selector is required and every administration selector is optional**, and that is a recorded
decision. Requiring the other ten would be a claim about ten pages and the rows one scenario happens to
arrange, made by an authoring session reading a tree rather than running against one — **F-116 with the name
changed**, one slice after F-116. The census is printed in every failure message either way, so the next
slice can widen it from evidence.

### The refusal is thrown, not asserted

A required selector matching nothing throws from the harness rather than returning a report the caller has to
remember to check. That is this directory's standing convention: a journey reports an arrangement failure as
an `InvalidOperationException` naming what the surface was showing, and only claims about the product live in
a scenario. **A group that went quiet is an arrangement failure** — nothing about the product is wrong, and
every verdict computed from it is true of a smaller page than the one the scenario meant to measure.

## What this slice deliberately did NOT do

**No picture on a card.** The `has-picture` grid is a real box model this barrier does not exercise, and
attaching a photograph inside scenario 21 means extracting the upload journey into the harness — a second
change with a different failure mode, in the slice whose own change has to be proven first. It is the
cheapest remaining thing in the plan and it is named there.

**No font floor on §11.4.** The obvious next move, declined on F-116's remedy: those ten pages surely comply,
and *surely* is the word that cost a session one slice ago.

**No `.manage-inline-form` fold.** Above.

**No `EndToEndScenarios.cs` edit.** `MeasureAsync(page, path)` keeps its signature and `MeasuredControl`
gained fields rather than losing any, so scenario 16 compiles and means exactly what it meant. A file of
three thousand lines not touched is three thousand lines that cannot have been broken.

**No `REQUIREMENTS.md` revision and no ADR edit.** R§1 already says guests order from their own phones and
§11.12 is already normative for every surface; this is a mechanism catching up to intent, which is rev 2's
reasoning rather than rev 3's.

## §18 arithmetic

| Where | Tests | Running |
| --- | --- | --- |
| Baseline — **measured, 1302 passed / 0 failed** | — | 1302 |
| Scenario 21 extended in place — steps (k), (l), (m) inside the existing `[Fact]` | +0 | 1302 |
| `app.css`, `HandheldReach`, `TableJourneys` — no test method added or removed | +0 | 1302 |

**Predicted 1302**, and the §16.3 suite stays at **21** — no scenario was added and none was removed.
`MinimumCountedClasses` stays **37**: no test class is added, and the two §16.4 paragraphs this slice writes
cite `HandheldReach.cs`, which is not a `*Tests.cs` and is therefore not a counted class.

**The count not moving is the thing to check first.** If the run comes back at 1302 with a red assertion, the
red one is the finding and this slice worked. If it comes back at anything other than 1302, something was
added or lost that nobody in this session intended.

## What was verified, and what was not

**Verified mechanically.** The reconstruction was SHA-256 verified before anything was authored. The §16.4
counted-class census was emulated over the edited specification: **37 classes, exact at the floor**, no
ambiguity, no disagreement between any claimed count and its file. The new §16.4 paragraphs were checked
against the census gate's own parser rather than against a belief about it — `CitedTestClass` matches
`` `…Tests.cs` `` and `HandheldReach.cs` does not match it, so both paragraphs are skipped entirely; the
scenario 21 text contains the phrase *"no assertion"*, which `AssertionCount` matches and `ValueOf` discards
because *no* is not in `NumberWords`. The Markdown table gate was emulated with the backtick-aware splitter
over every tracked document. The version gate was emulated: header **1.49**, newest changelog entry **1.49**,
entries strictly descending, `REQUIREMENTS.md` still self-consistent at rev 6. Byte hygiene was checked over
every changed file: no CR, exactly one final newline, no trailing whitespace, no whitespace-only line, no
dump separator. The standing authoring scans ran: no plain literal in a `string.Create` chain, no `await` in
an interpolated hole, no `section` identifier in any Razor file — and no Razor file was touched.

**Eight planted defects, each caught by the intended verdict, and the eighth is why the proof was worth
running.** The new decision logic was transcribed out of C# into Python and driven against synthesised
reports: a basket with no staged line, a renamed `.order-menu-choice`, a card pushed off the right edge,
a 34px way-in control, F-118 itself as it stood before the repair, and a reader returning nothing — which
reported all ten selectors silent at once, so the whole instrument cannot pass vacuously.

**The eighth was a field at 15px, and on the first run it reported GREEN.** The font-floor comparison had
been written as `font < Minimum - PixelTolerance`, copied from the touch-target comparison directly above
it, and one pixel of slack passes a 15px control — which is a control iOS Safari zooms. **The two
comparisons are about different kinds of number**: a bounding box is a layout engine's output carrying
sub-pixel rounding, a fractional `clamp()` padding and a scrollbar's width, and a computed font size is
none of those, because `max(1rem, 1em)` against a 16px root computes to exactly 16 and every value under it
was written under it. The floor is now strict, the reason is in the constant's own summary, and the
sensitivity proof is what found it — a gate that would otherwise have shipped believing itself sensitive,
one slice after F-116.

**Not verified.** Nothing was compiled and nothing was run (F-71's standing caveat). The specific risks, in
order of what they would cost:

**The barrier itself is the largest, and its failure mode is the good one.** If §11.1 has a second layout
defect this slice did not find, the scenario reports it and the report is the finding. **That is not a reason
to delete the barrier**, and it is written down here because deleting a gate that reports on arrival is the
tempting move and the wrong one. Send the message; the next slice is the repair.

**The `width: 100%` the repair brings with it** is the one thing about F-118's fix that is not purely
additive. `.order-basket-quantity` is a flex container and its input is a flex item, so a percentage width
resolves against an indefinite main size; `max-width: 8rem` caps it and `.order-basket-controls` carries
`flex-wrap: wrap`, so the worst case is the Take-out button wrapping to its own line. `.order-picker-quantity
input` has had exactly these declarations since the picker was written, which is evidence from the tree
rather than from a compile.

**`MeasureHereAsync` reads three selector groups out of one JSON shape**, and the grouped shape is new — the
previous script returned a flat array per group and this one returns `{selector, controls[]}` per group.
`ReadGroups` is where a mis-shaped read would surface, and it would surface as a `KeyNotFoundException` from
`GetProperty` rather than as a wrong number.

**`HandheldSelector` and `HandheldSurface` are new internal records in an existing file**, referenced from
`MenuReactionScenarios` in namespace `MyRestaurant.EndToEnd.Tests` with a `using …Harness;` already present.

**`string[][]` is passed as the script argument** where the old code passed `string[]`. Playwright serialises
it as a nested JSON array and the script indexes `groups[0..2]`; the old call passed a field rather than an
array literal to avoid CA1861, and this one builds the jagged array inside the method, where CA1861 does not
apply because it is not a constant argument at a call site.

**Nothing proves the eight guest selectors match what scenario 21 arranges.** They were derived by reading
the markup, and the required-selector refusal is precisely the instrument that will say so if any is wrong —
by name, with the census, rather than by a verdict quietly computed over a smaller page.

## Open items carried

**`/kitchen` has no §16.3 scenario at all.** Carried, and still the largest end-to-end gap by a clear margin.

**The wide layout stacks each row's three controls** on the administration index. Carried since Slice 47.

**`.manage-inline-form` keeps a second copy of the control declarations.** New, and named above.

**The font floor is asserted on §11.1 and nowhere else.** New, and it is a deliberate scope rather than a gap.

**Nothing measures §11.1 with a picture on a card.** New, and the cheapest remaining thing in the plan.

**No assertion anywhere proves a static-SSR Razor endpoint carries `[EnableRateLimiting]` in its endpoint
metadata.** Carried from Slice 62.

**Nothing decides when the next tranche of the log moves to the archive.** Carried, and this file is now past
six thousand lines.

**Two of Stage 6's four prerequisites**, and neither is a mechanism: the `REQUIREMENTS.md` revision about
guest privacy is new intent, and the moderation surface is a slice of work. The menu enhancement's own open
list is empty for the fourth time.
