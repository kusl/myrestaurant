# Documentation Review — Findings and Resolutions

**All findings F-01 through F-121 are resolved.** This is the numbered ledger: one row per finding,
stating what was wrong, what was ruled, and where the ruling lives. It is a register rather than an
essay — the reasoning that produced each ruling is in the commit that closed it and in the archived
long form, and the specification carries the mechanism.

**The long form is archived, not deleted.** Every finding's full narrative — the account of how it was
found, what it falsified, and what general lesson was drawn — is in
[`docs/progress/DOCUMENTATION_REVIEW_THROUGH_F_118.md`](progress/DOCUMENTATION_REVIEW_THROUGH_F_118.md).
That file is withheld from the context dump (`export.sh` `ARCHIVED_DIRECTORIES`) and is still tracked,
still hygiene-checked, and still the place to read when a row here is too terse to act on.

**How to read a row.** `R§n` is `docs/REQUIREMENTS.md`, `S§n` is `docs/TECHNICAL_SPECIFICATION.md`,
`O§n` is `docs/OPERATIONS.md`. A finding is closed when its ruling is embodied *and* something
mechanical holds it there; Appendix A of the specification maps every ruling to its embodiment, and
§16.4 names the gate.

**The standing rules this register has produced**, in the order they are most often needed:

| Rule | Finding | What it says |
|---|---|---|
| Gates must be sensitive | F-41 | Every assertion is proven able to fail, against a planted defect, before it ships. An emptiness assertion over a walk that read nothing passes. |
| Subjects are computed, not listed | F-47, F-58 | Where a rule can be executed against the tree, no hardcoded list of its subjects exists. A list of one is still a list. |
| Delete a stale count, do not correct it | F-77, F-89, F-112 | Prose stating a number no gate can check is deleted. A number written beside an enforced copy of itself is a second copy with better camouflage. |
| Declared, not merely mentioned | F-67 | A gate keys on a call, not an identifier — the open parenthesis is what tells a use from a mention. |
| A gate may not read prose | F-116, F-119 | No gate's correctness may depend on prose quoting its subject, or on prose existing at all. Scan code, with comments removed. |
| A reading is of one instant | F-121 | A composite a predicate is asked about is read from the browser in one evaluation. Two round trips compose one object out of two renders. |
| A correction replaces the claim it corrects | F-114 | It does not sit beneath it. Two accounts of one thing read as diligence and the stale one is met first. |
| One change, one green run | — | Two changes ride together only when their failure modes are distinguishable by name. |

---

### Group A — Contradictions between requirement sections (all ruled)

| Finding | What was wrong | Ruling / resolution | Where |
|---|---|---|---|
| **F-01** | §3.3 listed "password reset assistance" among counter duties while §4.5 made reset administrator-only | Reset capability is **administrator-only** | R§4.5 · S§3.5, S§3.7 |
| **F-02** | §6.3 named counter as the price-adjusting role; §6.5 granted "kitchen and counter" price edits | Composition edits (add/remove lines): kitchen + counter + administrator | R§6.4 · S§3.7, S§6, S§8 |
| **F-03** | The first registered user is auto-granted administrator, but admins must hold a passkey and TOTP *at grant time*… | `/setup` bootstrap wizard: create account → register passkey → enroll TOTP → grant administrator, in **one guarded… | R§4.4 · S§3.6 |
| **F-04** | §5.4 said "only counter can close and settle"; §4.3 gave administrators full authority over everything | Counter **or** administrator may close and settle | R§5.4 · S§3.7, S§5 |
| **F-05** | The §4.4 heading covered kitchen/counter gating but imposed a passkey only on kitchen — counter, which handles money… | Accepted **as literally written**: counter carries no grant-time credential mandate | S§3.7, S§17 |

### Group B — Gaps and ambiguities

| Finding | What was wrong | Ruling / resolution | Where |
|---|---|---|---|
| **F-06** | TLS / secure contexts never addressed; WebAuthn, Wake Lock, and reliable audio all need HTTPS, and quick tunnels get… | **Named Cloudflare tunnel on the owner's stable domain is the production origin.** Verified sharp edge… | R§2, R§10 · S§3.2, S§3.3, S§14, S§17 |
| **F-07** | "Their own individual order" (singular) didn't model multi-round dining | **Q1 ruling** (supersedes the draft order-per-submission interpretation): **one living order per guest per sitting.**… | R§6 · S§6, S§10 |
| **F-08** | "TOTP enabled" and "TOTP required" conflated — two independent facts treated as one | **Q2/Q3 ruling:** TOTP is challenged **on password sign-ins only**, never after a passkey (the authenticator is… | R§4.2, R§4.5 · S§3.4, S§3.5 |
| **F-09** | A literal reading forced a TOTP challenge even after a passkey sign-in — flagged as unusual UX pending confirmation | **Superseded by the Q2 ruling**, which lands where the finding pointed: the passkey path never receives a TOTP… | S§3.5 · ADR-0010 |
| **F-10** | Post-close edit window undefined (tamper-evident editing vs atomic settlement) | Orders are **read-only after close**, except administrators may append corrective events — each itself logged | R§6.6 · S§5, S§6.7 |
| **F-10b** | "Delete any user" would orphan the append-only history | Deletion is **deactivation** (`is_active = false`, sign-in blocked, sessions revoked via security stamp) | S§3.7 |
| **F-11** | Attribution granularity toward guests unstated — do guests see staff usernames? | Guests see the **role** ("kitchen removed Salmon — unavailable"); staff and administration views show full actor… | R§6.5 · S§6, S§11.1 |
| **F-12** | The static, never-rotated table QR was a permanent capability token — one photograph grants indefinite remote access… | **Q4/Q5 ruling:** printed static QR codes are **gone entirely** (not kept as a flagged fallback) | R§5.1 · S§4, S§11.5 |
| **F-13** | Redis had no version-1 consumer | Excluded from the v1 stack; documented as the future SignalR backplane/cache with explicit trigger conditions | R§2 · ADR-0006 |
| **F-14** | Aspire and Podman Compose named without a hierarchy | **Compose is canonical** for dev, CI, and prod; an Aspire AppHost may exist as optional developer convenience that… | R§2 · S§14.5 |
| **F-15** | `UPTRACE_DSN` is not a "standard OpenTelemetry environment variable" | The application reads **only `OTEL_*`**; `run.sh` performs a courtesy translation when `UPTRACE_DSN` is set | S§12, S§13, S§14.4 |
| **F-16** | Backup mechanics underspecified: client/server version match, "`.env.example` generates `.env`", timer rendering | `pg_dump -Fc` runs **inside the postgres container** via `podman exec` (version match guaranteed); `.env` is copied… | S§15 · O§6, O§8 |
| **F-17** | `run.sh` invoked in the quick start but never defined | Defined: ensure environment → translate `UPTRACE_DSN` if present → start the stack → health wait → developer… | S§14.4 |
| **F-18** | Admins were promised "price-change timelines" but nothing mandated recording them | Append-only `menu_item_event` written **in the same transaction** as every `menu_item` mutation, with typed old/new… | R§6.8 · S§7, S§8 |
| **F-19** | Currency, time zone, username policy, lockout, and anonymity all silent | `RESTAURANT_CURRENCY_CODE` (ISO 4217, display only); `RESTAURANT_TIME_ZONE`; case-insensitive `citext` usernames 3–64… | R§4.1, R§8 · S§3, S§13 |
| **F-20** | Moq-exclusion rationale factually off: Moq is free (BSD) — the community concern was the 2023 SponsorLink telemetry… | Bans stand; the stated *reason* corrected | R§2 · S§16.1 |

### Group C — Editorial issues (applied in `REQUIREMENTS.md` rev 2)

| Finding | What was wrong | Ruling / resolution | Where |
|---|---|---|---|
| **F-21** | "Three physical roles" vs four applications read as a counting error | Reworded: three physical stations (table, kitchen, counter) plus administration — a role, not a place — plus the… | R§1, R§3 |
| **F-22** | The no-abbreviations rule collided with mandated initialisms (`TOTP`, `QR`, `OTEL_*`, …) | Explicit carve-out for industry-standard initialisms more recognizable than their expansions; `id` remains an… | R§8 |
| **F-23** | A hardcoded personal path in the §1 example contradicted §8's "nothing hardcoded" | Example genericized to repository-relative form | R§1 |
| **F-24** | A "Resolved:" bullet sat inside the "not yet decided" list, falsifying the list's contract | §10 retitled **"Resolved design directives"**; every entry there is now genuinely resolved and points at its… | R§10 |

### Group D — `dump.txt` / `export.sh` defects (all remediated)

| Finding | What was wrong | Ruling / resolution | Where |
|---|---|---|---|
| **F-25** | The script emitted itself twice (self-documentation section *and* the tracked-file loop) | The loop excludes the script **by whatever name it currently has** (`EXCLUDED_FILES=("$SCRIPT_NAME")`), so a rename… |  |
| **F-26** | `REQUIREMENTS.md` was absent from the dump — untracked or hidden under the excluded `docs/llm/` path | Requirements tracked at `docs/REQUIREMENTS.md`; `docs/llm/` is reserved for *generated* output only |  |
| **F-27** | `exec > >(tee …)` could reach the rename and exit while `tee` was still draining — a reader could observe a truncated… | Plain redirection into a temp file, atomic `mv`, and only then a `cat` of the final file; stderr never enters the… |  |
| **F-28** | Doubled root line in the FILE TREE section | The heredoc header no longer prints its own `.`; the tree renderer prints exactly one |  |
| **F-29** | Redundant `&>/dev/null 2>&1` | Trailing `2>&1` dropped; `&>` already covers both streams |  |
| **F-30** | Unchecked `bc` dependency killed the entire dump under `set -e` on machines without it | `human_size` uses `awk`, which `file_sha256` already required |  |
| **F-31** | Fallback tree renderer used `└──`/`├──` by node kind instead of by position | Correct connectors and `│` continuation lines rendered by position |  |
| **F-32** | `yarn.lock` leftover in a .NET repository's exclusion list | Removed |  |
| **F-33** | "all 1 included files" | Singular/plural noun selected from the count |  |

### Group E — Implementation findings (deviations discovered while building)

| Finding | What was wrong | Ruling / resolution | Where |
|---|---|---|---|
| **F-34** | §8.2's `passkey_credential` was specified before ASP.NET Core Identity's .NET 10 passkey API was verified against… | Additive migration `0002_passkey_credential_webauthn_state.sql` adds `is_user_verified` / `is_backup_eligible` /… | S§8.2 (schema-evolution note), S§3.3 |
| **F-35** | The profile page is specified twice — R§4.6 ("every person has a profile page") and S§11.1 (in the `/table` surface… | The profile page ships as an M2 close-out slice before M4 opens: `/account` (display name, email, phone, plus the… | R§4.6 · S§11.1, S§11.6, S§19 |
| **F-36** | Every surface rendered instants with `DateTimeOffset.ToLocalTime()`, which is the **server process's** zone — not… | **Closed in the M4 close-out slice**, on the schedule the original row recorded — deliberately not folded into the… | S§8.1, S§11.7 (new), S§13, S§19 · R§8 |
| **F-38** | **The restore path had never been executed, and it could not have completed.** `scripts/restore.sh` ran `pg_restore… | Both scripts rewritten and `scripts/restore_drill.sh` added: a non-destructive rehearsal against a scratch container… | S§15, S§16.4 · O§6, O§8, O§14 |
| **F-39** | **The program could not say what it was, and it offered nobody its source.** Two gaps, found while preparing the… | Shipped as the M6 close-out, before the tag rather than after it, because the first tag is the version people cite | R§8 (rev 3) · S§11.9 (new), S§12, S§13, S§16.4, S§19 |
| **F-37** | There was no registration page | The surface ships in M6 as its own slice: `/register`, anonymous static SSR, two steps over a… | R§4.3 · S§11.1, S§11.8 (new), S§17, S§19 |
| **F-40** | **The tree stopped being machine-readable, and only one of the twenty-one damaged files said so.** A `dotnet build`… | `scripts/check_tree.sh` added and run as the **first** gate in both CI (its own `tree` job) and `scripts/ci_local.sh` | S§16.4, S Appendix A · O§14 |
| **F-42** | **The repository invited strangers to read the source and offered them nowhere to say what they found — and the one… | Shipped as M6 Slice 20, before the tag rather than after it, because a disclosure channel is worth having before the… | R§8 (rev 4), R§10 · S§16.4, S§17, S§18 |
| **F-43** | **A script that was correct on one host, wrong on another, and named the wrong subsystem when it failed.**… | Three changes, in order of how a reader meets them | S§15, S§16.4 · O§6 |
| **F-44** | **A test barrier satisfied by markup that is present in every state.** §16.3 scenario 10 closes a sitting, returns to… | `CounterBoard.razor` publishes `data-live` (`RendererInfo.IsInteractive` — a circuit produced this markup) and… | S§11.3, S§16.3 |
| **F-45** | **The image build could see the whole working tree, and the file that was supposed to be protecting it was protecting… | `.dockerignore` as an **allow-list** — `.editorconfig`, the two `Directory.*.props`, `global.json`, `src`, minus… | S§14.1a, S§15 · O§12, O§14 |
| **F-46** | **The rule that made F-42 unrepeatable was written as a rule and enforced as a list of examples — and the example it… | The forbidden list gains a package-settings group, and — the part that matters more — is maintained as **part of the… | S§16.4, S§18 · O§14 |
| **F-47** | **The repair recorded as complete named the remaining work as a list, and the list was wrong — for the fourth time in… | §11.10 states the contract for **every** interactive surface, names `RenderModeForPage` as its subject rather than a… | S§11.10 (new), S§16.4 |
| **F-48** | **The specification's header said v1.6 while its own changelog said v1.7 — and this is the second time.** The v1.3… | The header is the version the changelog says it is, and `SpecificationVersionTests` asserts it on every `dotnet test` | S§16.4 |
| **F-49** | **The application has been emitting a Content Security Policy since M1, and this is the first document in the tree to… | §11.11 and ADR-0013: three headers on every response, from the application rather than from any of the three proxies… | R§8 (rev 5) · S§11.11, S§16.4, S§17 |
| **F-50** | **Four documents agreed about a variable, and the stack that deploys this program dropped it on the floor.**… | Two lines and a rule | S§13, S§16.4 · O§15 |
| **F-51** | **The canonical stack could not start on a stock Debian host, and every gate in this repository was green while it… | §14.1 states it normatively — every image reference in `compose.yaml` is fully qualified — together with the reason… | S§14.1 · O§1, O§10a |
| **F-52** | **Two documents explained why something was impossible, and it was a design choice — so for four milestones nobody… | New **§14.3a** and `scripts/dev_instance.sh` | S§14.3, S§14.3a · O§1, O§10, O§10a |
| **F-53** | **The documented command brought the whole stack up and then never returned, and the only thing it printed was two… | **§14.1 prohibits the condition rather than working around it**, and the prohibition is the ruling: `service_started`… | S§14.1, S§14.3a, S§16.4 · O§2, O§10a |
| **F-54** | **A step in the production runbook asserted behaviour no script has, and the citation it offered was this file.**… | **The document is wrong and the scripts are right; that clause of F-16's ruling is reversed rather than… | O§2, O§10a |
| **F-55** | **The command came back this time | Four rules in **§14.3a**, and the fourth is a new command | S§14.3a · O§10a |
| **F-56** | **Three things in this tree dial the same port; one of them named the address that exists.** `compose.yaml` publishes… | Both helpers default `TUNNEL_TARGET` to `http://127.0.0.1:8080`, with the reasoning written beside the assignment… | S§14.3a, S§16.4 |
| **F-57** | **The engine does not apply the defaults in `compose.yaml`, and that one fact killed both containers.**… | Verified in three places rather than assumed, and the remediation made complete | S§14.1, S§16.4 · O§2, O§10a |
| **F-58** | **The gate built to make a version header agree with its own history named one file, and the sibling document had… | The subject is **computed** (F-47's habit): every Markdown file in `docs/` with both a header version and a history… | S§16.4 |
| **F-59** | **The only affordance on an administration row sat off the right-hand edge of a phone screen, and nothing in this… | New **S§11.12**, normative for every surface | R§8 (rev 6), R§6.8 · S§11.12 (new), S§16.4, S§19 |
| **F-60** | **A rule was stated for the repository, applied to the two files that prompted it, and the four places it was missing… | §14.1 stops being about `compose.yaml` | S§14.1, S§16.4 |
| **F-61** | **The helper said twice that it was closing the tunnel, and neither line was wrong about what it did.**… | A first-entry guard, and `trap - INT TERM EXIT` inside the handler so the remaining registrations are disarmed rather… | S§14.3 |
| **F-62** | **A gap stayed open for a slice because of a fact about the test harness that the test harness contradicts — and by… | **The barrier, built first, and the stage order swapped to put it there.** §16.3 gains a sixteenth scenario: an… | S§11.12, S§16.4, S§16.3, S Appendix A |
| **F-63** | **The rule that this application has exactly one layout breakpoint was stated about the tree and asserted about one… | The fact is renamed to `TheTreeIsWrittenHandheldFirstThroughExactlyOneBreakpoint` — F-38's habit applied to a test… | S§11.12, S§16.4 |
| **F-64** | **Five CSS custom properties were read fifty-five times across eight components and declared nowhere, so eight… | Every reference now names the declared property the rule always wanted: `--rule` → `--hairline`, `--muted-foreground`… | S§11.12, S§16.4 |
| **F-65** | **§11.12 names four kinds of control that carry the 44px touch target, and `app.css` declared two of them at 36px… | Both rules read `var(--touch-target)` | S§11.12, S§16.4 |
| **F-66** | **The four detail surfaces were the fifth copy of F-59, one register down, and the copies contradicted `app.css`… | One `.manage-*` vocabulary in `app.css`, handheld-first as a column whose controls inherit `--touch-target` and the… | S§11.12, S§16.3, S§16.4 |
| **F-67** | **The gate that enforces "the shared vocabulary is declared once" could not tell a declaration from a sentence about… | The scan reads the **simple selectors a block declares**: CSS comments stripped, each rule's prelude taken as the… | S§11.12, S§16.4 |
| **F-68** | **The palette was written back into the tree as literals, and seven of the copies had already drifted.** Ninety-five… | `:root` gains ten properties for the values that had none, each declared at its **current** value and named for the… | S§11.12, S§16.4 |
| **F-69** | **Four documents stated a count of the tree, and the slice that cited it last had already made it wrong.** §11.12… | The *should* is **finished** rather than the number corrected | S§11.12, S§16.4 |
| **F-70** | **A blocking gate landed in this repository and not one document in it knew the gate existed — and the number that… | The gate is **adopted, not deleted**, and that ordering is the ruling: the rule is right, so what was missing is… | S§11.12, S§16.4, S§18 |
| **F-71** | **The web-layer suite did not build, and `dotnet test` reported a green summary line.** Slice 35's new helper in… | Third argument dropped at all three sites, behaviour-identical: the framework source has `IndexOf(char… | S§18 |
| **F-72** | **This ledger and Appendix A had both stopped rendering as tables, and each slice appended a row in the shape of the… | Both registers rebuilt as single four-column tables; F-65 restored to its own row; F-63 to F-70 moved inside Appendix… | S§16.4 |
| **F-73** | **The test that compares §16.4's counts to the files carried a count of its own that was stale when it shipped.**… | Both move to **ten**, which this slice's own §16.4 paragraph makes true, and the summary records that it said eight… | S§16.4 |
| **F-74** | **A high-severity advisory was riding in the dependency graph, printing on every restore, and the only gate that… | One `PackageVersion` line pinning 2026.0.0, which `CentralPackageTransitivePinningEnabled` has been able to promote… | S§16.4 |
| **F-75** | **The local gate script stated its one blind spot and had two.** Its header says *"The one gate this cannot reproduce… | The audit becomes gate 7 of `scripts/ci_local.sh`, the same command on the same advisory terms (`continue-on-error… | S§16.4 |
| **F-76** | **Tree hygiene's third gate printed `exactly one LF` and checked only that the last byte was one; eleven tracked… | A third half counting newlines in the last **two** bytes with the same `tail -c … \\|` `wc -l` trick the second half… | S§16.4 |
| **F-77** | **Three files told the reader how many event types the menu vocabulary had; the number was stale, one of them also… | The counts are **deleted rather than corrected.** A corrected count goes stale again in `0005`, and three slices of… | S§7, S§8.2, S§16.4, S Appendix A |
| **F-78** | **The migration this whole enhancement rests on could not apply on any host, and the paragraph inside it explaining… | One builder call | S§7, S§16.4 |
| **F-79** | **§7 carried one paragraph twice, consecutively, byte-identical, for a slice — and the three gates that read that… | The duplicate is deleted | S§7 |
| **F-80** | **A vocabulary written in two places, where one of them is a CHECK constraint and the other is a C# list, and the… | The list is corrected to eight and — the part that matters — **made derivable** (F-47) | S§7, S§16.4 |
| **F-81** | **Two loop variables were named after a Razor directive, and the four errors named the directive.** Slice 40 wrote… | Both variables become `menuSection`, and the rule is **made executable rather than remembered** (F-47) | S§16.4 |
| **F-82** | **The gate written against stale counts went stale, and reported nothing, because it never ran.**… | The four counts are corrected and the floor moves from sixteen to eighteen with the census, F-73's habit on its third… | S§16.4, S§18 |
| **F-83** | **The repair for F-80 named a class that has never existed, and the name came from F-80's own rows in this file and… | The rename, in the test and in all three documents, so that the four artefacts agree with the tree rather than with… | S§16.4 |
| **F-84** | **`MenuItemSummary` went from seven members to ten in `0005` and a positional stand-in in the unit suite stayed at… | Ten arguments, and a comment that says what a stand-in is for: every member `OrderStaging` does not read sits at its… | S§16.4 |
| **F-85** | **Six integration facts failed before any of them ran, on a two-character username.** `MenuSectionEventLogTests`… | `"moe"`, at the arrangement and at the assertion that reads the fallback back, and the rule written into this class's… | S§16.4 |
| **F-86** | **The suite's only menu-event writer could produce five of the eight admitted types, because its INSERT listed two… | All five columns in the statement, and the three new payloads as **optional trailing parameters** so the five… | S§16.4 |
| **F-87** | **Six assertions described a create one row smaller than the one this tree performs, and the two worst were reading… | The four counts move, and the two payload reads move to `CreatedEventScalarAsync` — the inline query above, hoisted… | S§16.4 |
| **F-88** | **An end-to-end scenario compared a stylesheet's output against a name a person typed.**… | `TextContentAsync`, with the distinction written into the harness beside the read | S§16.3, S§16.4 |
| **F-89** | **F-73 ruled that a census count in prose should be kept and moved by habit | **The ruling is reversed, and that is worth stating plainly rather than quietly doing.** F-77's habit wins over… | S§16.4 |
| **F-90** | **1149 was predicted and 1151 ran, and the difference is a sentence in §16.4 that the gate over §16.4 cannot see.**… | The count is **deleted**, not corrected (F-77): the rows are derivable from the tree, and this sentence has now been… | S§16.4, S§18 |
| **F-91** | **The handheld barrier's control census was itemised in a comment and had been wrong for four slices, and no run… | The itemisation is **deleted** and replaced by the rule for what is counted | S§16.4 |
| **F-92** | **The specification's opening sentence cited a revision of `REQUIREMENTS.md` that had been superseded for thirteen… | The parenthetical is **deleted** (F-77, third application in one slice): the sibling document states its revision in… | S§0 |
| **F-93** | **The 375px barrier decides what it measures from a list of class names, so a surface can keep being *visited* and… | Both selectors join the reach set in the slice that creates them, and the **rule** goes into §16.4 rather than… | S§16.4 |
| **F-94** | **The menu index counted something other than what its own sentence named, and the line above it described the… | The page reads `IMenuSectionDirectory.ListAsync` as well, so the count is of headings and the empty ones are rendered… | S§7, S§11.4 |
| **F-95** | **The tie-break nine reads and one projection depend on was a coin flip, and the suite reported it once as a single… | Monotonicity becomes a **contract of `IIdentifierFactory`**, kept by a 12-bit counter in `rand_a` (RFC 9562 §6.2… | ADR-0011 |
| **F-96** | **The context dump had become mostly history, and nothing was deciding that it should.** `export.sh` regenerates… | The log splits at `# M6 Slice 40`: `docs/progress/` takes M1 through Slice 39 byte-exact, `export.sh` withholds that… | S§2, S§16.4, S§18 |
| **F-97** | **A test project can support two runners at once, and for eight milestones these four did — so which one `dotnet… | The VSTest half is **deleted, not pinned back**, and the mode is opted into once in `global.json`: that is the .NET… | S§16, S§16.4 |
| **F-98** | **The gate that made F-42 unrepeatable was red on the tree, and what tripped it was the paragraph explaining why one… | **The claim is described rather than quoted.** Adding `docs/TECHNICAL_SPECIFICATION.md` to `RECORD_FILES` was… | S§16.4 |
| **F-99** | **A new integration fact asserted the right property with arithmetic borrowed from the fact forty lines above it, and… | The count becomes 3 and **the arithmetic is written into the fact's own summary** rather than left to be re-derived… | S§16.4 |
| **F-100** | **The grouping rule lived where no unit test could reach it, and the second surface that needed it was about to copy… | The walk becomes `MenuGrouping`, the fourth member of that set, and `MenuHeadingGroup` replaces the component-private… | S§11.2, §16.4 · |
| **F-101** | **A schema was about to be created out of a design document's sketch, and the sketch had three columns wrong.**… | All three columns are **dropped before `0006` was authored**, and each reason is written into both §7 and the script… | S§7, §8.2, §16.4 · ADR-0015 |
| **F-103** | **The document that motivated a column argued for it with a sentence that is false, and three gates read that… | The column is **kept**, for the narrower and true reason — a picture on a guest's card may carry something its name… | S§7, S§11.1, S§16.4 |
| **F-104** | **The archive that delivered F-103 did not compile, and one character is the whole defect.**… | The statement loses its transition, and the reason is written beside it rather than only here, because the next… | S§16.4, S§18 |
| **F-105** | **The specification enumerated a vocabulary and counted its constraints, and the migration one slice earlier had made… | The list is **corrected** on F-77's cheaper direction, as for F-100 and F-103, and the **count is deleted** in favour… | S§7, S§16.4 |
| **F-106** | **A `ValidationMessage` sat one line outside its `EditForm`, and the consequence was that every menu item with a… | The tag moves inside the form, where the other five editors on the page have always had theirs | S§7, S§16.3, S§16.4 |
| **F-107** | **The rule that §8.2's picture cap is stated in exactly one place was carried by four slices of prose and by nothing… | The number travels rather than being copied | S§7, S§16.4 |
| **F-108** | **A `stackalloc` inside a loop, and the build that treats it as an error is not the build anybody runs on a… | The declaration is hoisted above the loop, which is behaviour-identical because every pass overwrites all four bytes… | S§18 |
| **F-109** | **The upload surface trusted a string that is not a fact about the file, and the refusal it produced blamed the… | The surface asks `ImageFormat.IdentifyContentType` what the bytes are and passes that; bytes it cannot identify… | S§7, S§16.3, S§16.4 |
| **F-110** | **The media-type vocabulary had a fourth and a fifth declaration, both in English, both on the surface an operator… | Both render `MenuItemImageUpload.RecognisedTypesForOperators`, derived from the same census the `accept` hint is… | S§7, S§16.4 |
| **F-115** | **A wall was documented — correctly, in full, with its own fix named in the same paragraph — and stayed up for eleven… | **One `AddRateLimiter` for the application**, owned by `Security/RateLimitingServiceCollectionExtensions.cs` rather… | S§4.2, S§11.8, S§13, S§16.4, S§17, S§18 |
| **F-114** | **A documentation comment can describe a member other than the one it is attached to, and neither the language nor… | All eight repaired | S§16.4, S Appendix A |
| **F-118** | **A form control declared outside the arrangement a rule is declared against is invisible to every gate that reads… | **The repair is a selector and not a rule.** `.order-basket-quantity input` joins the `.form-field` list, and its… | R§1 · S§11.12, §16.3 scenario 21, §16.4 |
| **F-116** | **The gate shipped with the sentence explaining why it was safe, and that sentence was wrong about the one file the… | The pattern is untouched and the **input** changes | S§16.4, S§18 |
| **F-117** | **§16.4 counted the files in a directory, in prose, and the slice that added one to that directory did not move the… | The count is **deleted rather than corrected**, on F-89's ruling and the standing pattern for a derivable census | S§16.4 |
| **F-113** | **The harness read a `<dt>` that `app.css` upcases, keyed a dictionary on the result, and documented the keys in the… | The term goes through `ScreenText.DeclaredAsync` — the helper that already exists for this and that `ReadTotalsAsync`… | S§16.3, S§18 |
| **F-112** | **The §16.4 counted-class census was written three times in the one place a ruling had cleared, and two of the three… | The narrative is **deleted rather than corrected**, which is F-89's own remedy applied to the copy F-89 created, and… | S§16.4 |
| **F-111** | **The schema of record described `menu_item_event` as a table with five event types and two payload columns, twelve… | The counts are **deleted rather than corrected**, which is this project's standing pattern for a census that can be… | S§7, S§8.2, S§16.4 |
| **F-119** | **A gate's scan was terminated by a documentation comment.** `ConfigurationSurfaceTests` read every configured key out of `RestaurantOptions.cs` between `public static RestaurantOptions FromConfiguration` and the string `/// <summary>Returns a human-readable reason` — so the boundary of the configuration surface was a sentence somebody wrote, not a declaration | F-116 ruled that no gate may depend on prose declining to quote its subject; this is the inverse and the same error. The scan now ends at `ValidationMethodMarker`, the declaration that comment described, which is where the binding method actually ends. Two constants become one | S§13, S§16.4 · F-116 |
| **F-120** | **Comments were 42% of authored source and four documents were 21% of the tree, and nothing measured either.** 2,087,175 bytes of comment across 334 files, and 1,655,921 bytes in the specification, the findings register, the build log and the menu plan — enough that the context dump reached 96% of the budget a session has to read it in. Every word of it was already in git | All comments removed from `.cs`, `.razor`, `.sql`, `.css`, `.js` and `.sh`; the four documents archived verbatim to `docs/progress/` and rewritten as registers. `SourceCommentContractTests` holds the result: no authored C# or Razor file carries a comment, proven sensitive against composed fixtures. `DocumentationCommentContractTests` is deleted rather than weakened — its subject no longer exists, and a floor of 1,500 `///` blocks over a tree with none is the vacuous gate F-41 prohibits | S§16.4, S§18 · F-41, F-77, F-114, F-116 |
| **F-121** | **A reading of one surface was composed out of two instants, and it had been producing a flake nobody could reproduce.** `KitchenJourneys.ReadBoardAsync` took `data-unseen-alerts` and `data-unseen-reminders` in two `GetAttributeAsync` round trips and then the pending lines in several more. `KitchenBoard.razor` renders both counts from one `KitchenAlertState` on one element, so the DOM was always self-consistent and the reader was not: a reminder arriving between the two reads produced one alert beside one reminder, which is not a state the board was ever in. `WaitForBoardAsync`'s predicate asks only about reminders, so the torn reading satisfied it and the alert-count assertion beside it failed with `Expected: 2, Actual: 1` — the observed failure of §16.3 scenario 8, unreproducible because the window is one re-render wide. `TableOrderJourneys.ReadBasketAsync` had the same shape over three `CountAsync` calls | Both readings are taken in a single `EvaluateAsync`, which the browser runs on the thread that applies Blazor's own DOM patches and therefore cannot interleave with one. `HarnessSnapshotContractTests` holds the rule over a **computed** subject set — the composites a `Func<T, bool>` is evaluated against — so a new waiting verb brings its reader under the rule without anybody adding a name (**F-47**, **F-58**). Proven sensitive against three composed fixtures and against the pre-repair tree, where it reports both readings | S§16.4 · F-41, F-47, F-58 |
---

## Open residuals

These are stated rather than closed, because each is a limit of what text can decide.

| Residual | Finding | Why it stays open |
|---|---|---|
| `SourceCode.WithoutComments` reads a multi-line verbatim or raw string literal as code on its inner lines | F-116, F-120 | A `//` inside multi-line SQL would be reported as a comment. No such literal is in this tree; the failure direction is a loud false finding rather than a silent pass. |
| A gate walking `src/` for `*.cs` also reaches `obj/**/*.g.cs` | F-120 | Generated code is not authored and carries generated comments. `SourceCommentContractTests` excludes `bin` and `obj` by path segment; the older walks are unaffected because their assertions are floors on files, or absences of patterns generated code does not contain. |
| A predicate over a **collection** is not brought under the atomic-reading rule | F-121 | `Func<IReadOnlyList<T>, bool>` is excluded because a list read is a count followed by one read per row, and making it one evaluation is a larger change than this rule. The excluded readers poll a surface that has already stopped changing, which is why none of them has produced a flake. |
| `HarnessSnapshotContractTests` delimits a method body by matching braces, which a stray brace inside a string literal would truncate | F-121 | A truncated body contains no browser read and therefore passes. The floor on total body bytes is what reports it; the failure direction is a loud floor rather than a silent pass. |
| LAN ordering depends on WAN health | F-06 | One origin, hairpinned through Cloudflare. Accepted risk, recorded in S§17. |
| Counter carries no grant-time credential mandate | F-05 | Accepted as literally written. Recorded in S§3.7 and S§17. |
